//! Derive template-local prewindow and window-dependent stages from admitted reads.
use super::*;
use crate::bound_expression::Read;
fn intermediate_deferred(index: usize, deferred: &[bool], intermediates: &[Intermediate]) -> bool {
    let mut found = false;
    visit_output_dependencies(
        index,
        |index| intermediates.get(index),
        |column| {
            found |= deferred.get(column).copied().unwrap_or(false);
        },
    )
    .is_err()
        || found
}
fn read_deferred(read: Read, deferred: &[bool], intermediates: &[Intermediate]) -> bool {
    match read {
        Read::Column(column) => deferred[column],
        Read::Intermediate { index, .. } => intermediate_deferred(index, deferred, intermediates),
        Read::Source(_) => false,
        Read::Joined(read) => read.keys.iter().any(|key| deferred[key.output_column]),
    }
}
fn expression_deferred(
    expression: &Expression,
    deferred: &[bool],
    intermediates: &[Intermediate],
) -> bool {
    match expression {
        Expression::Window(_) | Expression::ContextWindow(_) => true,
        Expression::Joined(read) | Expression::JoinedSource { read, .. } => read.keys.iter().any(|key| deferred[key.output_column]),
        Expression::Aggregate(aggregate) => match aggregate.relation() {
            AggregateRelation::Output { group_by } => group_by.iter().any(|&column| deferred[column])
                || aggregate.bindings().iter().any(|binding| deferred[binding.column]),
            AggregateRelation::Matched { keys, .. } => keys.iter().any(|key| key.value.read().and_then(MatchRead::output_column).is_some_and(|column| deferred[column])),
            AggregateRelation::CurrentGroup => false,
        },
        Expression::Column(column) => deferred[*column],
        Expression::Compute(plan) => plan.bindings().iter().any(|binding| read_deferred(binding.read.clone(), deferred, intermediates)),
        Expression::Flag(plan) => plan.bindings().iter().any(|binding| matches!(&binding.read, FlagRead::Read(read) if read_deferred(read.clone(),deferred,intermediates))),
        Expression::Function(function) => function.arguments().iter().any(|argument| matches!(&argument.input, FunctionInput::Read(read) if read_deferred(read.clone(),deferred,intermediates))),
        Expression::ProjectFunction(function) => function.arguments().iter().any(|argument| matches!(&argument.input, FunctionInput::Read(read) if read_deferred(read.clone(),deferred,intermediates))),
        Expression::Case(branches) => branches.iter().any(|branch| branch.when.as_ref().is_some_and(|predicate| predicate.bindings().iter().any(|binding| read_deferred(binding.read.clone(),deferred,intermediates))) || expression_deferred(&branch.assignment.expression,deferred,intermediates)),
        Expression::Extreme {operands,..} | Expression::StrConcat {operands,..} | Expression::StrTemplate {operands,..} | Expression::Imputation {operands,..} | Expression::Temporal {operands,..} => operands.iter().any(|operand| expression_deferred(&operand.expression,deferred,intermediates)),
        Expression::StrContains {source,..} | Expression::StrExtract {source,..} | Expression::StrCase {source,..} | Expression::StrPad {source,..} | Expression::MappingCut {source,..} | Expression::Round {source,..} => expression_deferred(&source.expression,deferred,intermediates),
        Expression::SourceBinding { source, .. } => expression_deferred(&source.expression, deferred, intermediates),
        Expression::FirstAvailable(selection) => selection.sources().iter().any(|operand| match &operand.read {
            SelectionRead::Column(column) => deferred[*column],
            SelectionRead::Expression(source) => expression_deferred(&source.expression, deferred, intermediates),
            SelectionRead::Source(_) | SelectionRead::Collect { .. } => false,
        }),
        Expression::SourceLookup { lookup, .. } => lookup.keys.iter().any(|key| deferred[key.output_column]),
        Expression::Intermediate {index,..} => intermediate_deferred(*index, deferred, intermediates),
        Expression::Lookup(lookup) => lookup.keys.iter().any(|key| deferred[key.output_column]),
        Expression::Odm(_) | Expression::Literal(_) | Expression::Source(_) | Expression::Collect {..} | Expression::RowLookup(_) | Expression::Reduce {..} | Expression::Count {..} => false,
    }
}
/// Dependency order is already admitted; a window and every transitive reader
/// complete over all retained rows after the template's prewindow filter.
pub fn window_stages(
    assignments: &[Assignment],
    width: usize,
    intermediates: &[Intermediate],
) -> Vec<bool> {
    let mut deferred = vec![false; width];
    for assignment in assignments {
        deferred[assignment.column] =
            expression_deferred(&assignment.expression, &deferred, intermediates);
    }
    deferred
}
