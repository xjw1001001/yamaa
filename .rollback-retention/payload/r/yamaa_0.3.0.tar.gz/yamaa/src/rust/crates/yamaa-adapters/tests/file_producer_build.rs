#![cfg(any(unix, windows))]
use std::{
    fs,
    path::PathBuf,
    rc::Rc,
    sync::{
        atomic::{AtomicUsize, Ordering},
        Arc,
    },
};
use yamaa_adapters::{
    file_graph::FileGraph,
    file_producer_build::{Attempt, BoundaryFailure, CodecError, FileBuild, Limits},
    file_resources::{Error as ResourceError, Resources},
    project_source::{self, CapturePort, Kind, OwnedEnvironment, Reply, Request},
    shipped_schema,
    specification_source::Source,
};
use yamaa_core::{
    function_signature::{LogicalSignature, ProjectFunctionIdentity},
    producer_graph::Node,
    project_environment::{LockKind, LockReference},
    project_function::Language,
    specification::OutputFinding,
    table::{TableAccess, ValueRef},
    value::Value,
};
use yamaa_engine::{
    dataset::{Execution, ExecutionError},
    function_invocation::{Argument, FailureKind, HostError},
    producer_build::{CaptureError, Failure, ReportPort},
    project_activation::{ActivationPort, Failure as ActivationFailure},
    specification_output::{CompleteError, OutputReport},
    specification_run::PortError,
};

static NEXT: AtomicUsize = AtomicUsize::new(0);
struct Study(PathBuf);
impl Study {
    fn new() -> Self {
        let root = std::env::temp_dir().join(format!(
            "yamaa-producer-build-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&root).unwrap();
        Self(fs::canonicalize(root).unwrap())
    }
    fn path(&self, written: &str) -> String {
        let path = self.0.join(written).to_str().unwrap().to_owned();
        #[cfg(windows)]
        let path = path
            .strip_prefix(r"\\?\")
            .unwrap_or(&path)
            .replace('\\', "/");
        path
    }
    fn write(&self, written: &str, bytes: impl AsRef<[u8]>) {
        let path = self.0.join(written);
        fs::create_dir_all(path.parent().unwrap()).unwrap();
        fs::write(path, bytes).unwrap();
    }
    fn build(&self, language: Language) -> FileBuild {
        FileGraph::prepare(
            Resources::new(&self.path(""), &self.path(""), &[]).unwrap(),
            "consumer/root.yaml",
            environment(language),
            shipped_schema::capture().unwrap(),
            Default::default(),
        )
        .unwrap_or_else(|error| panic!("graph fixture: {:?}", error.error()))
        .into_build()
    }
    fn rounded(&self) {
        self.write("producer/layers/base.yaml", PRODUCER);
        self.write(
            "producer/p.yaml",
            "schema_version: '1.0'\nparents: [layers/base.yaml]\ndomain: PRODUCER\n",
        );
        self.write("consumer/root.yaml", CONSUMER);
        self.write("raw/raw.csv", b"ID,VALUE\n1,1.234\n2,2.345\n");
    }
}
impl Drop for Study {
    fn drop(&mut self) {
        if self.0.exists() {
            fs::remove_dir_all(&self.0).unwrap();
        }
    }
}
const PRODUCER: &str = "schema_version: '1.0'\ndomain: TEST\nbase: RAW\nkeys: [ID]\ninput: {RAW: {path: ../../raw/raw.csv, types: {ID: int, VALUE: float}}}\ncolumns:\n  - {name: ID, type: int, label: Identifier, derivation: RAW.ID}\n  - {name: VALUE, type: float, label: Reported value, derivation: {function: {name: id_float, args: {x: RAW.VALUE}}}}\noutput: {path: ../../generated/producer.csv, columns: [ID, VALUE], decimals: 2}\n";
const CONSUMER: &str = "schema_version: '1.0'\ndomain: TEST\nbase: FIRST\nkeys: [ID]\ninput:\n  FIRST: {path: ../generated/producer.csv, schema: ../producer/p.yaml}\n  SECOND: {path: ../generated/producer.csv, schema: ../producer/./p.yaml}\nintermediates: [{id: SECOND_REFERENCE, dataset: SECOND, key: [ID], no_match: null}]\ncolumns:\n  - {name: ID, type: int, label: Identifier, derivation: FIRST.ID}\n  - {name: FIRST_VALUE, type: float, label: First value, derivation: FIRST.VALUE}\n  - {name: SECOND_VALUE, type: float, label: Second value, derivation: SECOND_REFERENCE.VALUE}\n  - {name: VALUE, type: float, label: Reported value, derivation: {compute: {expr: 'FIRST_VALUE + SECOND_VALUE'}}}\noutput: {path: ../generated/root.csv, columns: [ID, VALUE], decimals: 2}\n";

#[test]
fn linked_producer_ordinal_is_local_to_consumers_and_keeps_the_stored_contract() {
    use yamaa_adapters::producer_result::prepare_owned_classified;
    let study = Study::new();
    study.rounded();
    study.write("consumer/root.yaml", CONSUMER.replace("schema: ../producer/p.yaml}", "schema: ../producer/p.yaml, ordinal: REC}").replace("output: {path:", "  - {name: POSITION, type: int, label: Position, derivation: FIRST.REC}\noutput: {path:").replace("columns: [ID, VALUE], decimals", "columns: [ID, VALUE, POSITION], decimals"));
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Pass);
    let owned = build.build_owned_reported(&mut activation, report_id(), Default::default());
    let mut result = prepare_owned_classified(&owned, report_id(), 16_777_216, &[]).unwrap();
    assert!(result.issues().is_empty(), "{:?}", result.issues());
    fs::create_dir(study.0.join("generated")).unwrap();
    assert!(result.save().unwrap());
    assert_eq!(
        fs::read(study.0.join("generated/root.csv")).unwrap(),
        b"ID,VALUE,POSITION\n1,2.46,1\n2,4.70,2\n"
    );

    for raw in [b"ID,VALUE\n1,1.234\n".as_slice(), b"ID,VALUE\n"] {
        study.write("raw/raw.csv", raw);
        study.write(
            "consumer/root.yaml",
            CONSUMER.replace(
                "schema: ../producer/p.yaml}",
                "schema: ../producer/p.yaml, ordinal: ID}",
            ),
        );
        let mut build = study.build(Language::Python);
        let mut activation = Activation::new(&study, Mode::Pass);
        let owned = build.build_owned_reported(&mut activation, report_id(), Default::default());
        let result = prepare_owned_classified(&owned, report_id(), 16_777_216, &[]).unwrap();
        assert!(result.output().is_none());
        assert_eq!(result.issues().len(), 1);
        let issue = &result.issues()[0];
        assert_eq!(
            (
                issue.phase.as_str(),
                issue.condition.as_str(),
                issue.requirement.as_deref()
            ),
            ("validation", "ordinal_field_collision", Some("REQ-1294"))
        );
        assert_eq!(issue.spec_paths, ["input.FIRST.ordinal"]);
        assert_eq!(
            serde_json::from_str::<serde_json::Value>(&issue.context).unwrap(),
            serde_json::json!({"dataset":"FIRST", "field":"ID"})
        );
    }
}

#[test]
fn sealed_native_save_keeps_original_held_bytes_after_sources_change_and_other_owners_drop() {
    use yamaa_adapters::producer_result::prepare_owned_classified;
    for language in [Language::Python, Language::R] {
        let study = Study::new();
        study.rounded();
        fs::create_dir(study.0.join("generated")).unwrap();
        let mut build = study.build(language);
        let mut activation = Activation::new(&study, Mode::Pass);
        let owned = build.build_owned_reported(&mut activation, report_id(), Limits::default());
        let mut result = prepare_owned_classified(&owned, report_id(), 16_777_216, &[]).unwrap();
        let before = result.observations().clone();
        let output = result.output().unwrap().to_vec();
        let events = activation.trace.clone();
        assert_eq!(fs::read_dir(study.0.join("generated")).unwrap().count(), 0);
        study.write("raw/raw.csv", b"ID,VALUE\n1,99.99\n");
        fs::remove_dir_all(study.0.join("producer")).unwrap();
        fs::remove_dir_all(study.0.join("consumer")).unwrap();
        fs::remove_dir_all(study.0.join("raw")).unwrap();
        drop(build);
        for _ in 0..2 {
            assert!(result.save().unwrap());
            assert_eq!(
                fs::read(study.0.join("generated/producer.csv")).unwrap(),
                b"ID,VALUE\n1,1.23\n2,2.35\n"
            );
            assert_eq!(
                fs::read(study.0.join("generated/root.csv")).unwrap(),
                b"ID,VALUE\n1,2.46\n2,4.70\n"
            );
            assert_eq!(
                result.observations()["publication"],
                serde_json::json!({"status":"success","entered":[{"node":1,"published":true},{"node":0,"published":true}],"error":null})
            );
            assert_eq!(result.output().unwrap(), output);
            assert!(result.issues().is_empty());
            let mut report = result.observations().clone();
            report.as_object_mut().unwrap().remove("publication");
            assert_eq!(report, before);
            assert_eq!(activation.trace, events);
        }
        assert!(owned.accepted());
        assert_eq!(owned.graph.nodes.len(), 2);
    }
}
#[test]
fn authored_public_success_evidence_and_failed_owned_graph_never_obtain_save_authority() {
    use yamaa_adapters::{
        producer_report::NativeAttempt,
        producer_result::{prepare_classified, prepare_owned_classified},
    };
    let study = Study::new();
    study.rounded();
    fs::create_dir(study.0.join("generated")).unwrap();
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Pass);
    let actual = build.build_reported(&mut activation, report_id(), Default::default());
    // Every field is deliberately public evidence: a caller can author this
    // success, but that construction cannot create the private OwnedAttempt.
    let authored = NativeAttempt {
        provenance: Arc::clone(&actual.provenance),
        boundary: Ok(()),
        graph: actual.graph,
        resources: actual.resources,
    };
    let mut result = prepare_classified(&authored, report_id(), 16_777_216, &[]).unwrap();
    assert!(result.output().is_some());
    assert!(result.save().is_err());
    let limits = Limits {
        evidence_aliases: 0,
        ..Default::default()
    };
    let failed = build.build_owned_reported(&mut activation, report_id(), limits);
    assert!(!failed.accepted());
    assert_eq!(fs::read_dir(study.0.join("generated")).unwrap().count(), 0);
    assert!(prepare_owned_classified(&failed, report_id(), 16_777_216, &[]).is_err());
}
#[test]
fn whole_set_invalid_target_and_duplicate_normalized_alias_refuse_every_write() {
    use yamaa_adapters::producer_result::prepare_owned_classified;
    for duplicate in [false, true] {
        let study = Study::new();
        study.rounded();
        fs::create_dir(study.0.join("generated")).unwrap();
        if duplicate {
            study.write(
                "consumer/root.yaml",
                CONSUMER.replace("../generated/root.csv", "../generated/dir/../producer.csv"),
            );
        } else {
            fs::create_dir(study.0.join("generated/root.csv")).unwrap();
        }
        let mut build = study.build(Language::Python);
        let mut activation = Activation::new(&study, Mode::Pass);
        let owned = build.build_owned_reported(&mut activation, report_id(), Default::default());
        assert!(owned.accepted());
        let mut result = prepare_owned_classified(&owned, report_id(), 16_777_216, &[]).unwrap();
        assert!(!result.save().unwrap());
        assert!(!study.0.join("generated/producer.csv").exists());
        assert!(result
            .publication_attempt()
            .unwrap()
            .entered
            .entered
            .is_empty());
        assert_eq!(result.observations()["outcome"], "success");
        assert!(result.output().is_some());
        assert_eq!(
            result.observations()["publication"]["entered"],
            serde_json::json!([])
        );
    }
}
#[test]
fn native_save_admits_cumulative_limits_and_whole_report_before_first_write() {
    use yamaa_adapters::producer_result::prepare_owned_classified;
    use yamaa_engine::producer_publication::{Failure as SaveFailure, Limits as SaveLimits};
    let study = Study::new();
    study.rounded();
    fs::create_dir(study.0.join("generated")).unwrap();
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Pass);
    let owned = build.build_owned_reported(&mut activation, report_id(), Default::default());
    let mut result = prepare_owned_classified(&owned, report_id(), 16_777_216, &[]).unwrap();
    let first = owned.graph.nodes[0]
        .output
        .as_ref()
        .unwrap()
        .as_ref()
        .unwrap()
        .artifact()
        .unwrap();
    for limits in [
        SaveLimits {
            nodes: 1,
            ..Default::default()
        },
        SaveLimits {
            artifact_bytes: first.bytes().len(),
            ..Default::default()
        },
        SaveLimits {
            path_bytes: first.path().len(),
            ..Default::default()
        },
        SaveLimits {
            work: 2,
            ..Default::default()
        },
    ] {
        assert!(!result.save_with_limits(limits, 16_777_216).unwrap());
        let saved = result.publication_attempt().unwrap();
        assert!(saved.entered.entered.is_empty());
        assert!(matches!(saved.entered.outcome, Err(SaveFailure::Limit(_))));
        assert_eq!(fs::read_dir(study.0.join("generated")).unwrap().count(), 0);
    }
    assert!(!result.save_with_limits(Default::default(), 1).unwrap());
    assert!(result.publication_attempt().is_none());
    assert_eq!(fs::read_dir(study.0.join("generated")).unwrap().count(), 0);
    assert!(result.save().unwrap());
    assert!(result.issues().is_empty());
}
#[test]
fn canonical_target_path_quota_refuses_before_target_ownership_and_every_write() {
    use yamaa_adapters::producer_result::prepare_owned_classified;
    let study = Study::new();
    study.rounded();
    fs::create_dir(study.0.join("generated")).unwrap();
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Pass);
    let mut limits = Limits::default();
    // Enough for the engine's two held authored paths, insufficient for the
    // adapter's complete authored+canonical target ownership admission.
    limits.engine.publication.path_bytes = 128;
    let owned = build.build_owned_reported(&mut activation, report_id(), limits);
    assert!(owned.accepted());
    let mut result = prepare_owned_classified(&owned, report_id(), 16_777_216, &[]).unwrap();
    assert!(!result.save().unwrap());
    assert_eq!(result.observations()["outcome"], "success");
    assert_eq!(
        result.observations()["publication"]["error"]["code"],
        "producer_publication_paths"
    );
    assert!(result
        .publication_attempt()
        .unwrap()
        .entered
        .entered
        .is_empty());
    assert_eq!(fs::read_dir(study.0.join("generated")).unwrap().count(), 0);
}
#[cfg(windows)]
#[test]
fn absent_windows_case_alias_targets_refuse_before_every_write() {
    use yamaa_adapters::producer_result::prepare_owned_classified;
    let study = Study::new();
    study.rounded();
    study.write(
        "consumer/root.yaml",
        CONSUMER.replace("../generated/root.csv", "../generated/PRODUCER.csv"),
    );
    fs::create_dir(study.0.join("generated")).unwrap();
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Pass);
    let owned = build.build_owned_reported(&mut activation, report_id(), Default::default());
    assert!(owned.accepted());
    let mut result = prepare_owned_classified(&owned, report_id(), 16_777_216, &[]).unwrap();
    assert!(!result.save().unwrap());
    assert_eq!(
        result.observations()["publication"]["error"]["code"],
        "target_admission"
    );
    assert!(result
        .publication_attempt()
        .unwrap()
        .entered
        .entered
        .is_empty());
    assert_eq!(fs::read_dir(study.0.join("generated")).unwrap().count(), 0);
    assert!(result.output().is_some());
}
#[cfg(target_os = "macos")]
#[test]
fn macos_absent_case_alias_and_unproven_unicode_targets_preflight_before_every_write() {
    use yamaa_adapters::producer_result::prepare_owned_classified;
    let study = Study::new();
    study.rounded();
    fs::create_dir(study.0.join("generated")).unwrap();
    study.write("generated/case-probe", b"native case witness");
    let sensitive = !study.0.join("generated/CASE-PROBE").exists();
    fs::remove_file(study.0.join("generated/case-probe")).unwrap();
    for name in ["PRODUCER.csv", r"\u00e9.csv"] {
        study.write(
            "consumer/root.yaml",
            CONSUMER.replace("../generated/root.csv", &format!("\"../generated/{name}\"")),
        );
        let mut build = study.build(Language::Python);
        let mut activation = Activation::new(&study, Mode::Pass);
        let owned = build.build_owned_reported(&mut activation, report_id(), Default::default());
        assert!(owned.accepted());
        let mut result = prepare_owned_classified(&owned, report_id(), 16_777_216, &[]).unwrap();
        if name == "PRODUCER.csv" && sensitive {
            assert!(result.save().unwrap());
            fs::remove_file(study.0.join("generated/producer.csv")).unwrap();
            fs::remove_file(study.0.join("generated/PRODUCER.csv")).unwrap();
        } else {
            assert!(!result.save().unwrap());
            assert!(result
                .publication_attempt()
                .unwrap()
                .entered
                .entered
                .is_empty());
            assert_eq!(
                result.observations()["publication"]["error"]["code"],
                "target_preflight"
            );
        }
        assert_eq!(fs::read_dir(study.0.join("generated")).unwrap().count(), 0);
        assert!(result.output().is_some());
    }
}
#[cfg(unix)]
#[test]
fn actual_late_consumer_publication_failure_keeps_producer_bytes_original_io_and_completed_build() {
    use rustix::fs::{self as unix, FlockOperation, Mode as OpenMode, OFlags};
    use yamaa_adapters::producer_result::prepare_owned_classified;
    use yamaa_engine::producer_publication::Failure as SaveFailure;
    let study = Study::new();
    study.rounded();
    study.write(
        "consumer/root.yaml",
        CONSUMER.replace("../generated/root.csv", "../published/root.csv"),
    );
    fs::create_dir(study.0.join("generated")).unwrap();
    study.write("published/root.csv", b"previous consumer bytes");
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Pass);
    let owned = build.build_owned_reported(&mut activation, report_id(), Default::default());
    let events = activation.trace.clone();
    let mut result = prepare_owned_classified(&owned, report_id(), 16_777_216, &[]).unwrap();
    let before = result.observations().clone();
    let lock = unix::open(
        study.0.join("published"),
        OFlags::RDONLY | OFlags::DIRECTORY,
        OpenMode::empty(),
    )
    .unwrap();
    unix::flock(&lock, FlockOperation::NonBlockingLockExclusive).unwrap();
    assert!(!result.save().unwrap());
    assert_eq!(
        fs::read(study.0.join("generated/producer.csv")).unwrap(),
        b"ID,VALUE\n1,1.23\n2,2.35\n"
    );
    assert_eq!(
        fs::read(study.0.join("published/root.csv")).unwrap(),
        b"previous consumer bytes"
    );
    let saved = result.publication_attempt().unwrap();
    assert_eq!(
        saved
            .entered
            .entered
            .iter()
            .map(|n| (n.node, n.published))
            .collect::<Vec<_>>(),
        [(1, true), (0, false)]
    );
    assert!(
        matches!(&saved.entered.outcome,Err(SaveFailure::Publish {node:0,error}) if matches!(&error.error,yamaa_adapters::file_publication::Error::Io(e) if e.kind()==std::io::ErrorKind::WouldBlock))
    );
    assert!(result.issues().iter().any(
        |i| i.condition == "publication_failed" && i.requirement.as_deref() == Some("REQ-0764")
    ));
    assert!(owned.accepted());
    assert_eq!(owned.graph.nodes.len(), 2);
    assert!(result.output().is_some());
    unix::flock(&lock, FlockOperation::Unlock).unwrap();
    assert!(result.save().unwrap());
    assert!(result.issues().is_empty());
    let mut report = result.observations().clone();
    report.as_object_mut().unwrap().remove("publication");
    assert_eq!(report, before);
    assert_eq!(activation.trace, events);
}

#[test]
fn whole_graph_report_views_keep_original_document_and_plan_together() {
    use yamaa_adapters::specification_run_view::RunView;
    let study = Study::new();
    study.rounded();
    let build = study.build(Language::Python);
    let provenance = Arc::clone(build.provenance());
    assert_eq!(provenance.metadata().order(), [1, 0]);
    drop(build);
    fs::remove_dir_all(&study.0).unwrap();

    let views = provenance.report_views().collect::<Vec<_>>();
    assert_eq!(views.len(), 2);
    for (index, view) in views.iter().enumerate() {
        assert!(std::ptr::eq(
            view.document(),
            provenance.documents()[index].as_ref()
        ));
        assert_eq!(view.document().source().identity, view.node().identity());
        assert!(view.check_diagnostics().is_empty());
        assert_eq!(view.compiled().output_decimals(), Some("2"));
    }
    assert!(views[0].node().identity().ends_with("/consumer/root.yaml"));
    assert!(views[1].node().identity().ends_with("/producer/p.yaml"));
    assert_eq!(views[0].compiled().source().name, "FIRST");
    assert_eq!(views[1].compiled().source().name, "RAW");
    assert_eq!(views[0].document().parents().len(), 0);
    assert_eq!(views[1].document().parents().len(), 1);
    assert_eq!(
        views[1].document().parents()[0].source().bytes,
        PRODUCER.as_bytes()
    );
}

struct LockCapture {
    language: Language,
}
impl CapturePort for LockCapture {
    type Error = ();
    fn capture(&mut self, request: Request<'_>) -> Result<Reply, ()> {
        assert_eq!(request.kind, Kind::Lock);
        Ok(Reply::Lock {
            source: Source {
                identity: "held/lock".into(),
                bytes: b"held original lock".to_vec(),
            },
            kind: if self.language == Language::Python {
                LockKind::Uv
            } else {
                LockKind::Renv
            },
        })
    }
}
fn environment(language: Language) -> OwnedEnvironment {
    let (name, call, lock) = if language == Language::Python {
        ("python", "program.id_float", "uv.lock")
    } else {
        ("r", "program::id_float", "renv.lock")
    };
    let text = format!("schema_version: '1.0'\nlanguage: {name}\nlock: {lock}\nfunctions:\n  id_float:\n    function: {call}\n    description: Float identity.\n    params: [{{name: x, type: float}}]\n    returns: float\n    tests:\n      - {{id: normal, covers: [normal, numeric-comparison], args: {{x: 7.0}}, result: 7.0}}\n      - {{id: boundary, covers: [boundary], args: {{x: 0.0}}, result: 0.0}}\n      - {{id: missing, covers: ['short-circuit-missing:x'], args: {{x: null}}, result: null}}\n");
    project_source::prepare(
        shipped_schema::capture_environment().unwrap(),
        Source {
            identity: "held/environment.yaml".into(),
            bytes: text.into_bytes(),
        },
        language,
        &mut LockCapture { language },
        Default::default(),
    )
    .unwrap_or_else(|error| match error {
        project_source::Failure::Rejected(error) => {
            panic!("environment fixture: {:?}", error.admission)
        }
        _ => panic!("environment fixture capture failed"),
    })
    .into_owned()
}
#[derive(Debug)]
struct Payload {
    original: Rc<()>,
    interrupt: bool,
}
#[derive(Clone, Copy)]
enum Mode {
    Pass,
    Lock,
    BindingFailure,
    CaseFailure,
    CaseMismatch,
    CaseInterrupt,
    LiveFailure,
    LiveInterrupt,
    Unwind,
    ChangeAfterActivation,
}
struct Activation {
    study: PathBuf,
    trace: Vec<String>,
    original: Rc<()>,
    unwind: Arc<()>,
    mode: Mode,
}
impl Activation {
    fn new(study: &Study, mode: Mode) -> Self {
        Self {
            study: study.0.clone(),
            trace: vec![],
            original: Rc::new(()),
            unwind: Arc::new(()),
            mode,
        }
    }
    fn payload(&self, interrupt: bool) -> Payload {
        Payload {
            original: Rc::clone(&self.original),
            interrupt,
        }
    }
}
impl ActivationPort for Activation {
    type Error = Payload;
    type Handle = ();
    fn verify_lock(
        &mut self,
        language: Language,
        lock: &LockReference,
        calls: &[ProjectFunctionIdentity],
    ) -> Result<(), Payload> {
        assert_eq!(calls.len(), 1);
        assert_eq!(calls[0].name, "id_float");
        assert_eq!(
            lock.kind,
            if language == Language::Python {
                LockKind::Uv
            } else {
                LockKind::Renv
            }
        );
        self.trace.push("lock".into());
        if matches!(self.mode, Mode::Lock) {
            Err(self.payload(false))
        } else {
            Ok(())
        }
    }
    fn bind(
        &mut self,
        call: &ProjectFunctionIdentity,
        _: &LogicalSignature,
    ) -> Result<(), Payload> {
        assert_eq!(call.name, "id_float");
        self.trace.push("bind".into());
        if matches!(self.mode, Mode::BindingFailure) {
            return Err(self.payload(false));
        }
        Ok(())
    }
    fn is_interrupt(&self, error: &Payload) -> bool {
        error.interrupt
    }
    fn invoke(&mut self, _: &(), args: &[Argument<'_>]) -> Result<Value, HostError<Payload>> {
        let [Argument {
            name: "x",
            value: ValueRef::Float(value),
        }] = args
        else {
            panic!("exact float argument")
        };
        self.trace.push(format!("invoke:{}", value.get()));
        if value.get() == 0.0 {
            if matches!(self.mode, Mode::CaseFailure) {
                return Err(HostError::Raised(self.payload(false)));
            }
            if matches!(self.mode, Mode::CaseMismatch) {
                return Ok(Value::Int(19));
            }
            if matches!(self.mode, Mode::CaseInterrupt) {
                return Err(HostError::Raised(self.payload(true)));
            }
            if matches!(self.mode, Mode::ChangeAfterActivation) {
                // Native study capture must happen after all conformance cases.
                fs::write(
                    self.study.join("raw/raw.csv"),
                    b"ID,VALUE\n1,1.234\n2,2.345\n",
                )
                .unwrap();
            }
        }
        if value.get() == 1.234 {
            match self.mode {
                Mode::LiveFailure => return Err(HostError::Raised(self.payload(false))),
                Mode::LiveInterrupt => return Err(HostError::Raised(self.payload(true))),
                Mode::Unwind => std::panic::panic_any(Arc::clone(&self.unwind)),
                _ => {}
            }
        }
        Ok(Value::Float(*value))
    }
}
#[derive(Default)]
struct Report {
    entered: Vec<String>,
    maximum: usize,
    fail: bool,
    final_failure: bool,
}
impl ReportPort for Report {
    fn select<C, D, T: TableAccess>(
        &mut self,
        node: &Node,
        _attempt: &yamaa_engine::specification_run::CapturedAttempt<C, D, T>,
        maximum: usize,
    ) -> Result<(), Self::Error> {
        self.entered.push(node.identity().into());
        self.maximum = maximum;
        if self.fail {
            Err("original report refusal")
        } else {
            Ok(())
        }
    }
}
impl OutputReport for Report {
    type Error = &'static str;
    type Report = String;
    fn failure(&mut self) -> Result<String, Self::Error> {
        Ok("failed".into())
    }
    fn begin(&mut self, _: &Execution) -> Result<(), Self::Error> {
        Ok(())
    }
    fn rejected(&mut self, _: &[OutputFinding]) -> Result<String, Self::Error> {
        Ok("rejected".into())
    }
    fn success(&mut self, _: &Execution, _: &[usize], _: &[u8]) -> Result<String, Self::Error> {
        if self.final_failure {
            Err("original report rendering refusal")
        } else if self.maximum < 8 {
            Err("original bounded report refusal")
        } else {
            Ok("accepted".into())
        }
    }
}
fn artifact<E, R, F: std::fmt::Debug>(attempt: &Attempt<E, R, F>, node: usize) -> &[u8] {
    attempt.graph.nodes[node]
        .output
        .as_ref()
        .ok()
        .unwrap()
        .as_ref()
        .unwrap()
        .artifact()
        .unwrap()
        .bytes()
}

fn passthrough(input: &str, base: &str, output: &str, kind: &str) -> String {
    format!("schema_version: '1.0'\ndomain: TEST\nkeys: [ID]\nbase: {base}\ninput: {input}\ncolumns:\n  - {{name: ID, type: int, label: Identifier, derivation: {base}.ID}}\n  - {{name: VALUE, type: {kind}, label: Value, derivation: {base}.VALUE}}\noutput: {{path: {output}, columns: [ID, VALUE]}}\n")
}

#[test]
fn native_parquet_round_trip_uses_held_artifact_and_a_functionless_graph_grants_no_activation() {
    let study = Study::new();
    study.write("raw/raw.csv", b"ID,VALUE\n1,13\n2,17\n");
    study.write(
        "producer/p.yaml",
        passthrough(
            "{RAW: {path: ../raw/raw.csv, types: {ID: int, VALUE: int}}}",
            "RAW",
            "../generated/producer.parquet",
            "int",
        ),
    );
    study.write("consumer/root.yaml", passthrough("{FIRST: {path: ../generated/producer.parquet, schema: ../producer/p.yaml}, SECOND: {path: ../generated/producer.parquet, schema: ../producer/./p.yaml}}", "FIRST", "../generated/root.csv", "int"));
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Lock);
    let mut report = Report::default();
    let attempt = build.build(&mut activation, &mut report, Limits::default());
    assert!(attempt.accepted());
    assert!(activation.trace.is_empty());
    assert_eq!(attempt.graph.activation, Default::default());
    assert_eq!(artifact(&attempt, 1), b"ID,VALUE\n1,13\n2,17\n");
    let produced = artifact(&attempt, 0);
    assert!(produced.starts_with(b"PAR1") && produced.ends_with(b"PAR1"));
    for source in &attempt.graph.nodes[1].dataset.sources {
        assert_eq!(
            source.snapshot.as_ref().unwrap().as_ptr(),
            produced.as_ptr()
        );
        let table = source.table.as_ref().unwrap();
        assert_eq!(table.row_count(), 2);
        assert_eq!(table.cell(0, 1).unwrap(), ValueRef::Int(13));
        assert_eq!(table.cell(1, 1).unwrap(), ValueRef::Int(17));
    }
    assert!(!study.0.join("generated").exists());
    let complete = build.build_reported(&mut activation, report_id(), Limits::default());
    assert!(complete.accepted());
    let value = yamaa_adapters::producer_report::attempt_report(&complete, report_id(), 16_777_216)
        .unwrap();
    assert_eq!(value["outcome"], "success");
    assert_eq!(
        value["activation"],
        serde_json::json!({"lock":"not_requested","bindings":[],"tests":[]})
    );
    assert_eq!(value["artifacts"][0]["profile"], "parquet");
    assert_eq!(
        value["artifacts"][0]["records"],
        serde_json::json!(["[\"ID\", \"VALUE\"]", "[1, 13]", "[2, 17]"])
    );
    assert_eq!(value["artifacts"][1]["content"], "ID,VALUE\n1,13\n2,17\n");
    let mut limits = Limits::default();
    limits.engine.source_storage_bytes = 1;
    let refused = build.build(&mut activation, &mut report, limits);
    assert!(!refused.accepted());
    assert!(refused.graph.nodes[0].dataset.sources[0].table.is_none());
}

#[test]
fn native_diamond_executes_each_canonical_node_once_and_keeps_shared_leaf_bytes() {
    let study = Study::new();
    study.rounded();
    for branch in ["left", "right"] {
        study.write(
            &format!("{branch}.yaml"),
            passthrough(
                "{LEAF: {path: generated/producer.csv, schema: producer/p.yaml}}",
                "LEAF",
                &format!("generated/{branch}.csv"),
                "float",
            ),
        );
    }
    let root = CONSUMER
        .replace(
            "../generated/producer.csv, schema: ../producer/p.yaml",
            "../generated/left.csv, schema: ../left.yaml",
        )
        .replace(
            "../generated/producer.csv, schema: ../producer/./p.yaml",
            "../generated/right.csv, schema: ../right.yaml",
        )
        .replace(
            "intermediates:",
            "  AGAIN: {path: ../generated/left.csv, schema: .././left.yaml}\nintermediates:",
        );
    study.write("consumer/root.yaml", root);
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Pass);
    let mut report = Report::default();
    let attempt = build.build(&mut activation, &mut report, Limits::default());
    assert!(attempt.accepted());
    assert_eq!(
        attempt
            .graph
            .nodes
            .iter()
            .map(|n| n.node)
            .collect::<Vec<_>>(),
        [3, 1, 2, 0]
    );
    assert_eq!(
        activation.trace,
        [
            "lock",
            "bind",
            "invoke:7",
            "invoke:0",
            "invoke:1.234",
            "invoke:2.345"
        ]
    );
    assert_eq!(
        report.entered,
        [
            study.path("producer/p.yaml"),
            study.path("left.yaml"),
            study.path("right.yaml"),
            study.path("consumer/root.yaml")
        ]
    );
    let left = attempt.graph.nodes[1].dataset.sources[0]
        .snapshot
        .as_ref()
        .unwrap();
    let right = attempt.graph.nodes[2].dataset.sources[0]
        .snapshot
        .as_ref()
        .unwrap();
    assert!(Arc::ptr_eq(left, right));
    assert_eq!(left.as_ptr(), artifact(&attempt, 0).as_ptr());
    assert_eq!(artifact(&attempt, 3), b"ID,VALUE\n1,2.46\n2,4.70\n");
    assert!(!study.0.join("generated").exists());
}

#[test]
fn native_rounded_bytes_are_reingested_twice_after_producer_only_activation_with_original_origins()
{
    for language in [Language::Python, Language::R] {
        let study = Study::new();
        study.rounded();
        let mut build = study.build(language);
        let mut activation = Activation::new(&study, Mode::ChangeAfterActivation);
        // A capture before the final activation case would observe the wrong data.
        study.write("raw/raw.csv", b"ID,VALUE\n1,99.99\n");
        let mut report = Report::default();
        let attempt = build.build(&mut activation, &mut report, Limits::default());
        assert!(attempt.accepted(), "{:?}", attempt.graph.outcome);
        assert_eq!(
            activation.trace,
            [
                "lock",
                "bind",
                "invoke:7",
                "invoke:0",
                "invoke:1.234",
                "invoke:2.345"
            ]
        );
        assert_eq!(
            attempt
                .graph
                .nodes
                .iter()
                .map(|n| n.node)
                .collect::<Vec<_>>(),
            [1, 0]
        );
        assert_eq!(artifact(&attempt, 0), b"ID,VALUE\n1,1.23\n2,2.35\n");
        assert_eq!(artifact(&attempt, 1), b"ID,VALUE\n1,2.46\n2,4.70\n");
        let execution = attempt.graph.nodes[0]
            .dataset
            .result
            .as_ref()
            .unwrap()
            .result
            .as_ref()
            .unwrap();
        for (row, expected) in [1.234, 2.345].into_iter().enumerate() {
            let ValueRef::Float(value) = execution.dataset.cell(row, 1).unwrap() else {
                panic!("held unrounded producer float")
            };
            assert_eq!(value.get(), expected);
        }
        let consumer = &attempt.graph.nodes[1].dataset;
        assert_eq!(
            consumer
                .sources
                .iter()
                .map(|r| r.read.snapshots_created)
                .collect::<Vec<_>>(),
            [Some(0), Some(0)]
        );
        assert_eq!(consumer.sources.len(), 2);
        assert!(Arc::ptr_eq(
            consumer.sources[0].snapshot.as_ref().unwrap(),
            consumer.sources[1].snapshot.as_ref().unwrap()
        ));
        assert_eq!(
            &**consumer.sources[0].snapshot.as_ref().unwrap(),
            b"ID,VALUE\n1,1.23\n2,2.35\n"
        );
        assert_eq!(
            report.entered,
            [
                study.path("producer/p.yaml"),
                study.path("consumer/root.yaml")
            ]
        );
        let metadata = attempt.provenance.metadata();
        assert!(metadata.nodes()[0].activation_slots().is_empty());
        assert_eq!(metadata.nodes()[1].activation_slots(), [0]);
        assert_eq!(
            metadata.nodes()[0].producers()[0]
                .output_origin()
                .declaring_source(),
            study.path("producer/layers/base.yaml")
        );
        assert!(!study.0.join("generated").exists());
        drop(build);
        fs::remove_dir_all(&study.0).unwrap();
        assert_eq!(artifact(&attempt, 1), b"ID,VALUE\n1,2.46\n2,4.70\n");
        assert_eq!(
            attempt.provenance.documents()[1].source().bytes,
            b"schema_version: '1.0'\nparents: [layers/base.yaml]\ndomain: PRODUCER\n"
        );
        assert!(attempt
            .resources
            .as_ref()
            .unwrap()
            .iter()
            .any(|(p, b)| p.ends_with("/raw/raw.csv") && &**b == b"ID,VALUE\n1,1.234\n2,2.345\n"));
    }
}

#[test]
fn fresh_builds_repeat_activation_and_detect_changed_study_after_activation_with_original_snapshot()
{
    let study = Study::new();
    study.rounded();
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Pass);
    let mut report = Report::default();
    let first = build.build(&mut activation, &mut report, Limits::default());
    let second = build.build(&mut activation, &mut report, Limits::default());
    assert!(first.accepted() && second.accepted());
    assert_eq!(
        first.graph.nodes[0].dataset.sources[0]
            .read
            .snapshots_created,
        Some(1)
    );
    assert_eq!(
        second.graph.nodes[0].dataset.sources[0]
            .read
            .snapshots_created,
        Some(0)
    );
    assert_eq!(activation.trace.len(), 12);
    study.write("raw/raw.csv", b"ID,VALUE\n1,9.99\n");
    activation.trace.clear();
    let changed = build.build(&mut activation, &mut report, Limits::default());
    assert!(!changed.accepted());
    assert!(changed.boundary.is_ok());
    assert_eq!(activation.trace, ["lock", "bind", "invoke:7", "invoke:0"]);
    assert_eq!(changed.graph.nodes.len(), 1);
    assert!(matches!(
        changed.graph.nodes[0].dataset.result,
        Err(PortError::Capture(CaptureError::External(
            ResourceError::Changed
        )))
    ));
    assert!(changed
        .resources
        .as_ref()
        .unwrap()
        .iter()
        .any(|(p, b)| p.ends_with("/raw/raw.csv") && &**b == b"ID,VALUE\n1,1.234\n2,2.345\n"));
    assert_eq!(artifact(&first, 1), b"ID,VALUE\n1,2.46\n2,4.70\n");
}

#[test]
fn native_changed_metadata_and_metadata_quota_refuse_before_host_or_study_authority() {
    let study = Study::new();
    study.rounded();
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Pass);
    let mut report = Report::default();
    let limits = Limits {
        resource_bytes: 0,
        ..Default::default()
    };
    let bounded = build.build(&mut activation, &mut report, limits);
    assert!(matches!(
        bounded.boundary,
        Err(BoundaryFailure::Resource { identity: None, .. })
    ));
    assert!(activation.trace.is_empty() && bounded.graph.nodes.is_empty());
    study.write("producer/layers/base.yaml", b"changed metadata");
    let changed = build.build(&mut activation, &mut report, Limits::default());
    assert!(
        matches!(&changed.boundary, Err(BoundaryFailure::Resource { identity: Some(p), error: ResourceError::Changed }) if p == &study.path("producer/layers/base.yaml"))
    );
    assert!(activation.trace.is_empty() && changed.graph.nodes.is_empty());
    assert!(changed
        .resources
        .as_ref()
        .unwrap()
        .iter()
        .any(|(p, b)| p.ends_with("/producer/layers/base.yaml") && &**b == PRODUCER.as_bytes()));
    assert!(!changed
        .resources
        .as_ref()
        .unwrap()
        .iter()
        .any(|(p, _)| p.ends_with(".csv")));
}

#[test]
fn native_activation_failures_interrupts_and_unwind_retain_owned_original_prefix_and_stop_dependents(
) {
    for mode in [
        Mode::Lock,
        Mode::CaseInterrupt,
        Mode::LiveFailure,
        Mode::LiveInterrupt,
        Mode::Unwind,
    ] {
        let study = Study::new();
        study.rounded();
        let mut build = study.build(Language::Python);
        let mut activation = Activation::new(&study, mode);
        let mut report = Report::default();
        let attempt = build.build(&mut activation, &mut report, Limits::default());
        assert!(!attempt.accepted());
        assert!(report.entered.is_empty());
        match mode {
            Mode::Lock => {
                assert!(attempt.graph.nodes.is_empty());
                assert!(
                    matches!(&attempt.graph.outcome, Err(Failure::Activation(ActivationFailure::Lock(e))) if Rc::ptr_eq(&e.original, &activation.original))
                );
            }
            Mode::CaseInterrupt => {
                assert!(attempt.graph.nodes.is_empty());
                assert_eq!(activation.trace.len(), 4);
            }
            Mode::Unwind => {
                let Err(BoundaryFailure::Unwind(payload)) = &attempt.boundary else {
                    panic!("original unwind")
                };
                assert!(Arc::ptr_eq(
                    payload.downcast_ref::<Arc<()>>().unwrap(),
                    &activation.unwind
                ));
                assert_eq!(attempt.graph.nodes.len(), 1);
                assert!(matches!(attempt.graph.outcome, Err(Failure::Incomplete)));
                assert_eq!(
                    attempt.graph.nodes[0]
                        .dataset
                        .sources
                        .iter()
                        .filter(|s| s.snapshot.is_some())
                        .count(),
                    1
                );
            }
            _ => {
                assert_eq!(attempt.graph.nodes.len(), 1);
                let execution = attempt.graph.nodes[0].dataset.result.as_ref().unwrap();
                let error = execution.result.as_ref().unwrap_err();
                let ExecutionError::ProjectFunction { error: failure, .. } = &**error else {
                    panic!("original live failure: {error:?}")
                };
                let FailureKind::CallFailed(payload) = &failure.kind else {
                    panic!("opaque original failure")
                };
                assert!(Rc::ptr_eq(&payload.original, &activation.original));
                assert_eq!(payload.interrupt, matches!(mode, Mode::LiveInterrupt));
            }
        }
        assert!(!study.0.join("generated").exists());
    }
}

#[test]
fn original_graph_host_failure_visits_keep_stage_identity_after_other_owners_drop() {
    for (mode, stage) in [
        (Mode::Lock, "lock"),
        (Mode::CaseInterrupt, "conformance"),
        (Mode::LiveFailure, "derivation"),
        (Mode::LiveInterrupt, "derivation"),
    ] {
        let study = Study::new();
        study.rounded();
        let mut build = study.build(Language::Python);
        let mut activation = Activation::new(&study, mode);
        let original = Rc::clone(&activation.original);
        let attempt = build.build(&mut activation, &mut Report::default(), Limits::default());
        let entered = attempt.graph.nodes.len();
        drop(activation);
        drop(build);
        fs::remove_dir_all(&study.0).unwrap();
        for _ in 0..2 {
            let mut observed = Vec::new();
            yamaa_adapters::producer_attempt::visit_host_failures(&attempt, |stage, error| {
                observed.push((stage, error));
            });
            assert_eq!(observed.len(), 1);
            assert_eq!(observed[0].0, stage);
            assert!(Rc::ptr_eq(&observed[0].1.original, &original));
            assert_eq!(
                observed[0].1.interrupt,
                matches!(mode, Mode::CaseInterrupt | Mode::LiveInterrupt)
            );
        }
        assert_eq!(attempt.graph.nodes.len(), entered);
    }
}

#[test]
fn graph_failure_visits_leave_native_unwind_and_success_as_original_boundaries() {
    for mode in [Mode::Pass, Mode::Unwind] {
        let study = Study::new();
        study.rounded();
        let mut build = study.build(Language::Python);
        let mut activation = Activation::new(&study, mode);
        let unwind = Arc::clone(&activation.unwind);
        let attempt = build.build(&mut activation, &mut Report::default(), Limits::default());
        let mut count = 0;
        yamaa_adapters::producer_attempt::visit_host_failures(&attempt, |_, _| count += 1);
        assert_eq!(count, 0);
        if matches!(mode, Mode::Unwind) {
            let Err(BoundaryFailure::Unwind(payload)) = &attempt.boundary else {
                panic!("original unwind remains held")
            };
            assert!(Arc::ptr_eq(
                payload.downcast_ref::<Arc<()>>().unwrap(),
                &unwind
            ));
            assert_eq!(attempt.graph.nodes.len(), 1);
        } else {
            assert!(attempt.accepted());
            assert_eq!(attempt.graph.nodes.len(), 2);
        }
    }
}

#[test]
fn native_ingestion_verification_codec_report_and_retention_gates_keep_distinct_prefixes() {
    for mode in 0..6 {
        let study = Study::new();
        study.rounded();
        match mode {
            0 => study.write("raw/raw.csv", b"ID,VALUE\n1,not-a-float\n"),
            1 => study.write(
                "producer/layers/base.yaml",
                format!("{PRODUCER}verifications:\n  - row_count: {{min: 99}}\n"),
            ),
            _ => {}
        }
        let mut build = study.build(Language::Python);
        let mut activation = Activation::new(&study, Mode::Pass);
        let mut report = Report {
            fail: mode == 3,
            ..Default::default()
        };
        let mut limits = Limits::default();
        if mode == 2 {
            limits.engine.output_bytes = 5;
        }
        if mode == 4 {
            limits.evidence_aliases = 1;
            activation.mode = Mode::LiveFailure;
        }
        if mode == 5 {
            limits.engine.source_cells = 7;
        }
        let attempt = build.build(&mut activation, &mut report, limits);
        assert!(!attempt.accepted());
        assert!(!study.0.join("generated").exists());
        if mode == 5 {
            assert_eq!(attempt.graph.nodes.len(), 2);
            assert!(matches!(
                attempt.graph.nodes[1].dataset.result,
                Err(PortError::Run(_))
            ));
            assert_eq!(artifact(&attempt, 0), b"ID,VALUE\n1,1.23\n2,2.35\n");
        } else {
            assert_eq!(attempt.graph.nodes.len(), 1);
        }
        match mode {
            0 | 1 => {
                assert!(attempt.graph.nodes[0]
                    .dataset
                    .result
                    .as_ref()
                    .map_or(true, |e| e.result.is_err()));
                assert!(report.entered.is_empty());
            }
            2 => assert!(matches!(
                attempt.graph.nodes[0].output,
                Err(CompleteError::Encode(CodecError::Csv(_)))
            )),
            3 => assert!(matches!(
                attempt.graph.nodes[0].output,
                Err(CompleteError::Report("original report refusal"))
            )),
            4 => {
                let failure = attempt.resources.as_ref().unwrap_err();
                assert_eq!(failure.retained.len(), 1);
                assert!(attempt.graph.nodes[0]
                    .dataset
                    .result
                    .as_ref()
                    .unwrap()
                    .result
                    .is_err());
            }
            _ => {}
        }
    }
}

#[cfg(unix)]
#[test]
fn native_build_preserves_canonical_unix_root_with_literal_backslashes() {
    let outer = Study::new();
    let path = outer.0.join(r"native\root");
    fs::create_dir(&path).unwrap();
    let study = Study(fs::canonicalize(path).unwrap());
    study.rounded();
    let mut build = study.build(Language::Python);
    let attempt = build.build(
        &mut Activation::new(&study, Mode::Pass),
        &mut Report::default(),
        Limits::default(),
    );
    assert!(attempt.accepted());
    assert!(attempt
        .provenance
        .metadata()
        .nodes()
        .iter()
        .all(|n| n.identity().starts_with(&study.path(""))));
    assert_eq!(artifact(&attempt, 1), b"ID,VALUE\n1,2.46\n2,4.70\n");
    assert!(!study.0.join("generated").exists());
}
#[test]
fn final_report_rendering_refusal_prevents_retaining_or_consuming_producer_bytes() {
    let study = Study::new();
    study.rounded();
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Pass);
    let mut report = Report {
        final_failure: true,
        ..Default::default()
    };
    let attempt = build.build(&mut activation, &mut report, Limits::default());
    assert!(!attempt.accepted());
    assert_eq!(attempt.graph.nodes.len(), 1);
    assert!(attempt.graph.nodes[0]
        .dataset
        .result
        .as_ref()
        .unwrap()
        .result
        .is_ok());
    assert!(matches!(
        attempt.graph.nodes[0].output,
        Err(CompleteError::Report("original report rendering refusal"))
    ));
    assert_eq!(report.entered.len(), 1);
    assert!(!study.0.join("generated").exists());
}

fn report_id() -> yamaa_adapters::specification_report::Identity<'static> {
    yamaa_adapters::specification_report::Identity {
        runtime: "python",
        runtime_version: "fixture-host",
        engine_version: "fixture-engine",
        example: "independent-rounded-producer",
        specification: "unused-entry-alias",
        base_directory: "unused-caller-base",
    }
}

#[test]
fn public_root_result_keeps_independent_unrounded_truth_after_all_other_owners_and_files_drop() {
    use yamaa_adapters::{producer_result, public_table::Values};
    let study = Study::new();
    study.rounded();
    // Independent root precision witness: consumer references retain the
    // established 2.46/4.70 truth; this separate root column is not rounded.
    study.write("consumer/root.yaml", CONSUMER.replace(
        "output: {path:",
        "  - {name: ROOT_UNROUNDED, type: float, label: Root precision, derivation: {compute: {expr: 'VALUE + 0.004'}}}\noutput: {path:",
    ).replace("columns: [ID, VALUE], decimals: 2", "columns: [ROOT_UNROUNDED, ID, VALUE], decimals: 2"));
    let mut build = study.build(Language::Python);
    let mut host = Activation::new(&study, Mode::Pass);
    let first = build.build_reported(&mut host, report_id(), Limits::default());
    let second = build.build_reported(&mut host, report_id(), Limits::default());
    assert_eq!(host.trace.len(), 12);
    assert_eq!(artifact(&first, 0), b"ID,VALUE\n1,1.23\n2,2.35\n");
    assert_eq!(
        artifact(&first, 1),
        b"ROOT_UNROUNDED,ID,VALUE\n2.46,1,2.46\n4.70,2,4.70\n"
    );
    drop(build);
    drop(host);
    fs::remove_dir_all(&study.0).unwrap();
    for attempt in [&first, &second] {
        let result =
            producer_result::prepare_classified(attempt, report_id(), 16777216, &[]).unwrap();
        assert!(result.issues().is_empty());
        assert_eq!(result.observations()["outcome"], "success");
        let columns = result.output_table().unwrap().columns();
        assert_eq!(
            columns
                .iter()
                .map(|(name, _)| name.as_str())
                .collect::<Vec<_>>(),
            ["ROOT_UNROUNDED", "ID", "VALUE"]
        );
        assert!(
            matches!(&columns[0].1, Values::Float(values) if values == &[Some(2.464), Some(4.704)])
        );
        assert!(matches!(&columns[1].1, Values::Int(values) if values == &[Some(1), Some(2)]));
        assert!(
            matches!(&columns[2].1, Values::Float(values) if values == &[Some(2.46), Some(4.70)])
        );
        let copied =
            yamaa_adapters::public_table::PublicTable::decode(result.output().unwrap()).unwrap();
        assert!(
            matches!(&copied.columns()[0].1, Values::Float(values) if values == &[Some(2.464), Some(4.704)])
        );
        assert_eq!(artifact(attempt, 0), b"ID,VALUE\n1,1.23\n2,2.35\n");
    }
}

#[test]
fn public_failed_graph_retains_prior_artifacts_as_evidence_without_root_output() {
    use yamaa_adapters::producer_result;
    let study = Study::new();
    study.rounded();
    study.write(
        "consumer/root.yaml",
        format!("{CONSUMER}verifications:\n  - row_count: {{min: 99}}\n"),
    );
    let mut build = study.build(Language::Python);
    let mut host = Activation::new(&study, Mode::Pass);
    let attempt = build.build_reported(&mut host, report_id(), Limits::default());
    assert!(!attempt.accepted());
    assert_eq!(artifact(&attempt, 0), b"ID,VALUE\n1,1.23\n2,2.35\n");
    let before = host.trace.clone();
    let result = producer_result::prepare_classified(&attempt, report_id(), 16777216, &[]).unwrap();
    assert!(result.output().is_none() && result.output_table().is_none());
    assert_eq!(result.issues().len(), 1);
    assert_eq!(result.observations()["outcome"], "failure");
    assert_eq!(host.trace, before);
    drop(build);
    drop(host);
    fs::remove_dir_all(&study.0).unwrap();
    assert!(
        producer_result::prepare_classified(&attempt, report_id(), 16777216, &[])
            .unwrap()
            .output()
            .is_none()
    );
}

#[test]
fn public_root_projection_requires_complete_classification_and_preserves_original_host_failure() {
    use yamaa_adapters::{
        producer_report::ProjectionError, producer_result,
        project_function_diagnostics::HostDetails, project_report::Classified,
    };
    let study = Study::new();
    study.rounded();
    let mut build = study.build(Language::Python);
    let mut host = Activation::new(&study, Mode::LiveFailure);
    let original = Rc::clone(&host.original);
    let attempt = build.build_reported(&mut host, report_id(), Limits::default());
    drop(build);
    drop(host);
    fs::remove_dir_all(&study.0).unwrap();
    let mut failures = vec![];
    yamaa_adapters::producer_attempt::visit_host_failures(&attempt, |_, error| {
        failures.push(error)
    });
    assert_eq!(failures.len(), 1);
    assert!(Rc::ptr_eq(&original, &failures[0].original));
    match producer_result::prepare_classified(&attempt, report_id(), 16777216, &[]) {
        Err(producer_result::Error::Report(ProjectionError::Original {
            attempt: held,
            observations,
        })) => {
            assert!(std::ptr::eq(&attempt, held));
            assert_eq!(observations["outcome"], "failure");
        }
        _ => panic!("opaque original attempt must remain beside refusal"),
    }
    let facts = [Classified::Host {
        failure: failures[0],
        details: HostDetails::Exception {
            class: "OriginalError",
            message: "held failure",
            truncated: false,
        },
    }];
    let result =
        producer_result::prepare_classified(&attempt, report_id(), 16777216, &facts).unwrap();
    assert!(result.output().is_none());
    assert_eq!(result.issues().len(), 1);
    assert_eq!(result.issues()[0].condition, "function_call_failed");
    assert!(Rc::ptr_eq(&original, &failures[0].original));
}

#[test]
fn public_root_result_refuses_limited_or_contradictory_whole_attempts_before_output_copy() {
    use yamaa_adapters::{
        producer_report::ProjectionError, producer_result, specification_report::Error,
    };
    let study = Study::new();
    study.rounded();
    let mut build = study.build(Language::Python);
    let mut host = Activation::new(&study, Mode::Pass);
    let mut attempt = build.build_reported(&mut host, report_id(), Limits::default());
    let before = host.trace.clone();
    assert!(matches!(
        producer_result::prepare_classified(&attempt, report_id(), 1, &[]),
        Err(producer_result::Error::Report(ProjectionError::Report(
            Error::OutputLimit
        )))
    ));
    attempt.graph.nodes.swap(0, 1);
    assert!(matches!(
        producer_result::prepare_classified(&attempt, report_id(), 16777216, &[]),
        Err(producer_result::Error::Report(ProjectionError::Report(
            Error::InvalidObservation
        )))
    ));
    assert_eq!(host.trace, before);
    assert!(!study.0.join("generated").exists());
}

#[test]
fn public_root_copy_quota_keeps_the_complete_accepted_graph_and_original_typed_refusal() {
    use yamaa_adapters::{producer_result, table_transport::TableTransportError};
    let study = Study::new();
    study.rounded();
    let declarations = (0..59).map(|index| format!("  - {{name: EXTRA{index}, type: float, label: Extra value, derivation: {{literal: 1.234}}}}\n")).collect::<String>();
    let names = std::iter::once("ID".to_owned())
        .chain(std::iter::once("VALUE".to_owned()))
        .chain((0..59).map(|index| format!("EXTRA{index}")))
        .collect::<Vec<_>>()
        .join(", ");
    study.write(
        "consumer/root.yaml",
        CONSUMER
            .replace("output: {path:", &format!("{declarations}output: {{path:"))
            .replace(
                "columns: [ID, VALUE], decimals: 2",
                &format!("columns: [{names}], decimals: 2"),
            ),
    );
    study.write(
        "raw/raw.csv",
        format!(
            "ID,VALUE\n{}",
            (1..=100)
                .map(|index| format!("{index},1.234\n"))
                .collect::<String>()
        ),
    );
    let mut build = study.build(Language::Python);
    let mut host = Activation::new(&study, Mode::Pass);
    let attempt = build.build_reported(&mut host, report_id(), Limits::default());
    assert!(attempt.accepted());
    let before = host.trace.clone();
    match producer_result::prepare_classified(&attempt, report_id(), 16777216, &[]) {
        Err(producer_result::Error::Output {
            attempt: held,
            observations,
            error: TableTransportError::OutputLimit,
        }) => {
            assert!(std::ptr::eq(&attempt, held));
            assert_eq!(observations["outcome"], "success");
            assert_eq!(observations["nodes"].as_array().unwrap().len(), 2);
            assert_eq!(observations["artifacts"].as_array().unwrap().len(), 2);
        }
        other => panic!(
            "original output quota owner expected: {}",
            match other {
                Ok(_) => "unexpected success",
                Err(_) => "wrong refusal",
            }
        ),
    }
    assert_eq!(host.trace, before);
    assert!(!study.0.join("generated").exists());
    drop(build);
    drop(host);
    fs::remove_dir_all(&study.0).unwrap();
    assert!(attempt.accepted());
    assert!(matches!(
        producer_result::prepare_classified(&attempt, report_id(), 16777216, &[]),
        Err(producer_result::Error::Output {
            error: TableTransportError::OutputLimit,
            ..
        })
    ));
}

#[test]
fn classified_graph_reports_keep_actual_host_causes_and_authored_origins_without_replay() {
    use yamaa_adapters::{
        producer_report::{attempt_report_classified, ProjectionError},
        project_function_diagnostics::HostDetails,
        project_lock::{Finding, Reason},
        project_report::Classified,
    };
    for (mode, condition) in [
        (Mode::Lock, "runtime_artifact_mismatch"),
        (Mode::BindingFailure, "project_environment_invalid"),
        (Mode::CaseFailure, "function_conformance_failed"),
        (Mode::CaseMismatch, "function_conformance_failed"),
        (Mode::LiveFailure, "function_call_failed"),
    ] {
        let study = Study::new();
        study.rounded();
        let mut build = study.build(Language::Python);
        let mut host = Activation::new(&study, mode);
        let original = Rc::clone(&host.original);
        let attempt = build.build_reported(&mut host, report_id(), Limits::default());
        let trace = host.trace.clone();
        drop(host);
        drop(build);
        fs::remove_dir_all(&study.0).unwrap();
        let mut held = vec![];
        yamaa_adapters::producer_attempt::visit_host_failures(&attempt, |stage, error| {
            held.push((stage, error))
        });
        let lock = [Finding {
            package: "yamaa".into(),
            reason: Reason::VersionMismatch,
            expected: vec!["0.2.0".into()],
            actual: Some("0.3.0".into()),
        }];
        let facts = held
            .iter()
            .map(|(stage, error)| {
                assert!(Rc::ptr_eq(&original, &error.original));
                if *stage == "lock" {
                    Classified::Lock {
                        failure: *error,
                        findings: &lock,
                    }
                } else {
                    Classified::Host {
                        failure: *error,
                        details: HostDetails::Exception {
                            class: "ActualHostError",
                            message: "original quoted \"cause\"",
                            truncated: false,
                        },
                    }
                }
            })
            .collect::<Vec<_>>();
        let report = attempt_report_classified(&attempt, report_id(), 16_777_216, &facts).unwrap();
        assert_eq!(report["outcome"], "failure");
        assert_eq!(report["diagnostics"].as_array().unwrap().len(), 1);
        assert_eq!(report["diagnostics"][0]["condition"], condition);
        assert_eq!(report["artifacts"], serde_json::json!([]));
        if !matches!(mode, Mode::LiveFailure) {
            assert!(attempt.graph.nodes.is_empty());
            assert_eq!(report["source_reads"], serde_json::json!([]));
            assert_eq!(
                report["diagnostics"][0]["context"]["source"],
                "held/environment.yaml"
            );
            assert_eq!(
                report["diagnostics"][0]["context"]["entry"],
                "held/environment.yaml"
            );
        } else {
            assert_eq!(attempt.graph.nodes.len(), 1);
            assert_eq!(
                report["diagnostics"][0]["spec_paths"],
                serde_json::json!(["columns.VALUE.derivation.function"])
            );
            assert_eq!(
                report["diagnostics"][0]["context"]["keys"],
                serde_json::json!([{"ID":1}])
            );
        }
        assert_eq!(
            attempt_report_classified(&attempt, report_id(), 16_777_216, &facts).unwrap(),
            report
        );
        assert_eq!(
            trace
                .iter()
                .filter(|entry| entry.starts_with("invoke:"))
                .count(),
            if matches!(mode, Mode::LiveFailure) {
                3
            } else if matches!(mode, Mode::Lock | Mode::BindingFailure) {
                0
            } else {
                2
            }
        );
        assert!(matches!(
            attempt_report_classified(&attempt, report_id(), 1, &facts),
            Err(ProjectionError::Report(
                yamaa_adapters::specification_report::Error::OutputLimit
            ))
        ));
    }
}

#[test]
fn graph_classification_refuses_unrelated_duplicate_wrong_stage_and_oversized_facts() {
    use yamaa_adapters::{
        producer_report::{attempt_report_classified, ProjectionError},
        project_function_diagnostics::HostDetails,
        project_report::Classified,
        specification_report::Error,
    };
    let study = Study::new();
    study.rounded();
    let mut build = study.build(Language::Python);
    let mut host = Activation::new(&study, Mode::LiveFailure);
    let attempt = build.build_reported(&mut host, report_id(), Limits::default());
    let mut held = vec![];
    yamaa_adapters::producer_attempt::visit_host_failures(&attempt, |_, error| held.push(error));
    let error = held[0];
    let ordinary = |failure| Classified::Host {
        failure,
        details: HostDetails::Exception {
            class: "ActualHostError",
            message: "original",
            truncated: false,
        },
    };
    let unrelated = host.payload(false);
    for facts in [
        vec![ordinary(&unrelated)],
        vec![ordinary(error), ordinary(error)],
        vec![Classified::Lock {
            failure: error,
            findings: &[],
        }],
    ] {
        assert!(matches!(
            attempt_report_classified(&attempt, report_id(), 16_777_216, &facts),
            Err(ProjectionError::Report(Error::InvalidObservation))
        ));
    }
    let message = "\\\"".repeat(131072);
    let facts = [Classified::Host {
        failure: error,
        details: HostDetails::Exception {
            class: "ActualHostError",
            message: &message,
            truncated: false,
        },
    }];
    assert!(matches!(
        attempt_report_classified(&attempt, report_id(), 16_777_216, &facts),
        Err(ProjectionError::Report(Error::OutputLimit))
    ));
    assert_eq!(attempt.graph.nodes.len(), 1);
    assert!(Rc::ptr_eq(&host.original, &error.original));
}

#[test]
fn graph_host_classification_cannot_authorize_distinct_zero_sized_payloads_by_address() {
    use yamaa_adapters::{
        producer_report::{attempt_report_classified, ProjectionError},
        project_report::Classified,
        specification_report::Error,
    };
    struct Host;
    impl ActivationPort for Host {
        type Error = ();
        type Handle = ();
        fn verify_lock(
            &mut self,
            _: Language,
            _: &LockReference,
            _: &[ProjectFunctionIdentity],
        ) -> Result<(), ()> {
            Err(())
        }
        fn bind(&mut self, _: &ProjectFunctionIdentity, _: &LogicalSignature) -> Result<(), ()> {
            unreachable!()
        }
        fn is_interrupt(&self, _: &()) -> bool {
            false
        }
        fn invoke(&mut self, _: &(), _: &[Argument<'_>]) -> Result<Value, HostError<()>> {
            unreachable!()
        }
    }
    let study = Study::new();
    study.rounded();
    let mut build = study.build(Language::Python);
    let attempt = build.build_reported(&mut Host, report_id(), Limits::default());
    let mut held = vec![];
    yamaa_adapters::producer_attempt::visit_host_failures(&attempt, |_, error| held.push(error));
    assert_eq!(held.len(), 1);
    let facts = [Classified::Lock {
        failure: held[0],
        findings: &[],
    }];
    assert!(matches!(
        attempt_report_classified(&attempt, report_id(), 16777216, &facts),
        Err(ProjectionError::Report(Error::InvalidObservation))
    ));
    assert!(matches!(
        attempt_report_classified(&attempt, report_id(), 16777216, &[]),
        Err(ProjectionError::Original { .. })
    ));
    assert!(attempt.graph.nodes.is_empty());
}
fn truth_table(
    specification: &str,
    stage: &str,
    name: &str,
    columns: &[&str],
    rows: &[&[&str]],
) -> serde_json::Value {
    use serde_json::json;
    let kinds = columns
        .iter()
        .map(|&column| if column == "ID" { "int" } else { "float" })
        .collect::<Vec<_>>();
    json!({"specification":specification,"stage":stage,"name":name,"columns":columns,"types":kinds,
        "rows":rows.iter().map(|row| row.iter().zip(&kinds).map(|(value, kind)| json!({"type":kind,"value":value})).collect::<Vec<_>>()).collect::<Vec<_>>()})
}
#[test]
fn native_complete_reports_pin_independent_rounded_truth_and_union_after_all_owners_drop() {
    use serde_json::json;
    use yamaa_adapters::producer_report::attempt_report;
    let study = Study::new();
    study.rounded();
    let mut build = study.build(Language::Python);
    let mut host = Activation::new(&study, Mode::Pass);
    let first = build.build_reported(&mut host, report_id(), Limits::default());
    let second = build.build_reported(&mut host, report_id(), Limits::default());
    assert!(first.accepted() && second.accepted());
    assert_eq!(host.trace.len(), 12);
    let producer = study.path("producer/p.yaml");
    let consumer = study.path("consumer/root.yaml");
    let raw_rows: &[&[&str]] = &[&["1", "3ff3be76c8b43958"], &["2", "4002c28f5c28f5c3"]];
    let rounded_rows: &[&[&str]] = &[&["1", "3ff3ae147ae147ae"], &["2", "4002cccccccccccd"]];
    let derived_rows: &[&[&str]] = &[
        &[
            "1",
            "3ff3ae147ae147ae",
            "3ff3ae147ae147ae",
            "4003ae147ae147ae",
        ],
        &[
            "2",
            "4002cccccccccccd",
            "4002cccccccccccd",
            "4012cccccccccccd",
        ],
    ];
    let tables = json!([
        truth_table(&producer, "source", "RAW", &["ID", "VALUE"], raw_rows),
        truth_table(&producer, "derived", "output", &["ID", "VALUE"], raw_rows),
        truth_table(&consumer, "source", "FIRST", &["ID", "VALUE"], rounded_rows),
        truth_table(
            &consumer,
            "source",
            "SECOND",
            &["ID", "VALUE"],
            rounded_rows
        ),
        truth_table(
            &consumer,
            "derived",
            "output",
            &["ID", "FIRST_VALUE", "SECOND_VALUE", "VALUE"],
            derived_rows
        ),
    ]);
    let activation = json!({"lock":"verified","bindings":[{"function":"id_float","call":"program.id_float","source":"held/environment.yaml","outcome":"bound"}],
    "tests":[
        {"function":"id_float","call":"program.id_float","source":"held/environment.yaml","case":"normal","args":{"x":{"float":"401c000000000000"}},"expected":{"float":"401c000000000000"},"comparison_decimals":4,"outcome":"passed","invoked":true,"actual_retained":true,"actual":{"float":"401c000000000000"}},
        {"function":"id_float","call":"program.id_float","source":"held/environment.yaml","case":"boundary","args":{"x":{"float":"0000000000000000"}},"expected":{"float":"0000000000000000"},"comparison_decimals":4,"outcome":"passed","invoked":true,"actual_retained":true,"actual":{"float":"0000000000000000"}},
        {"function":"id_float","call":"program.id_float","source":"held/environment.yaml","case":"missing","args":{"x":{"missing":null}},"expected":{"missing":null},"comparison_decimals":4,"outcome":"passed","invoked":false,"actual_retained":true,"actual":{"missing":null}}
    ]});
    drop(build);
    drop(host);
    fs::remove_dir_all(&study.0).unwrap();
    for (attempt, created) in [(&first, 1), (&second, 0)] {
        let observed = attempt_report(attempt, report_id(), 16_777_216).unwrap();
        let expected = json!({"report_version":"0.3.0-draft","runtime":"python","backend":"rust","runtime_version":"fixture-host","engine_version":"fixture-engine","example":"independent-rounded-producer","entry":"consumer/root.yaml","outcome":"success","activation":activation,"environment":{"source":"held/environment.yaml","lock_source":"held/lock"},
            "nodes":[{"specification":producer,"outcome":"success","diagnostics":[],"unsupported":[],"handler_counts":[]},{"specification":consumer,"outcome":"success","diagnostics":[],"unsupported":[],"handler_counts":[]}],
            "artifacts":[
                {"name":"producer","profile":"csv","columns":["ID","VALUE"],"types":["int","float"],"row_count":2,"records":["ID,VALUE","1,1.23","2,2.35"],"byte_length":23,"content":"ID,VALUE\n1,1.23\n2,2.35\n","specification":producer},
                {"name":"root","profile":"csv","columns":["ID","VALUE"],"types":["int","float"],"row_count":2,"records":["ID,VALUE","1,2.46","2,4.70"],"byte_length":23,"content":"ID,VALUE\n1,2.46\n2,4.70\n","specification":consumer}],
            "tables":tables,"diagnostics":[],"unsupported":[],"handler_counts":[],"verifications":[],"callbacks":[],"error":null,
            "source_reads":[{"base_directory":study.path("producer"),"path":"../raw/raw.csv","outcome":"captured","condition":null,"snapshots_created":created,"specification":producer}]});
        assert_eq!(observed, expected);
        assert_eq!(
            attempt_report(attempt, report_id(), 16_777_216).unwrap(),
            expected
        );
        let bytes = attempt.graph.nodes[1]
            .output
            .as_ref()
            .unwrap()
            .as_ref()
            .unwrap()
            .artifact()
            .unwrap()
            .bytes();
        assert_eq!(bytes, b"ID,VALUE\n1,2.46\n2,4.70\n");
    }
}

#[test]
fn complete_failed_reports_keep_entered_producer_and_consumer_check_and_source_prefixes() {
    use serde_json::json;
    use yamaa_adapters::producer_report::attempt_report;
    for mode in 0..4 {
        let study = Study::new();
        study.rounded();
        match mode {
            0 => study.write(
                "producer/layers/base.yaml",
                format!("{PRODUCER}verifications:\n  - row_count: {{min: 99}}\n"),
            ),
            1 => study.write(
                "consumer/root.yaml",
                format!("{CONSUMER}verifications:\n  - row_count: {{min: 99}}\n"),
            ),
            2 => fs::remove_file(study.0.join("raw/raw.csv")).unwrap(),
            3 => study.write("raw/raw.csv", b"ID,VALUE\n1,bad\n"),
            _ => unreachable!(),
        }
        let mut build = study.build(Language::Python);
        let mut activation = Activation::new(&study, Mode::Pass);
        let attempt = build.build_reported(&mut activation, report_id(), Limits::default());
        assert!(!attempt.accepted());
        let before = activation.trace.clone();
        drop(build);
        fs::remove_dir_all(&study.0).unwrap();
        let value = attempt_report(&attempt, report_id(), 16_777_216).unwrap();
        assert_eq!(activation.trace, before);
        assert_eq!(value["outcome"], "failure");
        assert_eq!(
            value["nodes"].as_array().unwrap().len(),
            if mode == 1 { 2 } else { 1 }
        );
        assert_eq!(
            value["artifacts"].as_array().unwrap().len(),
            if mode == 1 { 1 } else { 0 }
        );
        assert_eq!(value["diagnostics"].as_array().unwrap().len(), 1);
        let finding = &value["diagnostics"][0];
        match mode {
            0 | 1 => {
                assert_eq!(finding["condition"], "row_count_failed");
                assert_eq!(finding["spec_paths"], json!(["verifications[0].row_count"]));
                assert_eq!(finding["context"]["count"], 2);
                assert_eq!(value["verifications"].as_array().unwrap().len(), 1);
            }
            2 => {
                assert_eq!(finding["condition"], "resource_path_missing");
                assert_eq!(finding["requirement"], "REQ-0785");
                assert_eq!(finding["context"]["path"], "../../raw/raw.csv");
                assert!(value["source_reads"].as_array().unwrap().is_empty());
            }
            3 => {
                assert_eq!(finding["condition"], "field_parse_failed");
                assert_eq!(finding["requirement"], "REQ-0536");
                assert_eq!(finding["context"]["value"], "bad");
                assert_eq!(value["source_reads"][0]["outcome"], "captured");
            }
            _ => unreachable!(),
        }
        assert_eq!(
            attempt_report(&attempt, report_id(), 16_777_216).unwrap(),
            value
        );
    }
}

#[test]
fn complete_projection_refusal_keeps_original_opaque_interrupt_unwind_and_actual_prefix() {
    use yamaa_adapters::producer_report::{attempt_report, ProjectionError};
    for mode in [
        Mode::Lock,
        Mode::CaseInterrupt,
        Mode::LiveFailure,
        Mode::LiveInterrupt,
        Mode::Unwind,
    ] {
        let study = Study::new();
        study.rounded();
        let mut build = study.build(Language::Python);
        let mut activation = Activation::new(&study, mode);
        let attempt = build.build_reported(&mut activation, report_id(), Limits::default());
        let original = Rc::clone(&activation.original);
        let unwind = Arc::clone(&activation.unwind);
        let before = activation.trace.clone();
        drop(build);
        fs::remove_dir_all(&study.0).unwrap();
        let Err(ProjectionError::Original {
            attempt: held,
            observations,
        }) = attempt_report(&attempt, report_id(), 16_777_216)
        else {
            panic!("original failure must accompany projection refusal");
        };
        assert!(std::ptr::eq(held, &attempt));
        assert_eq!(activation.trace, before);
        assert_eq!(observations["outcome"], "failure");
        assert!(observations["artifacts"].as_array().unwrap().is_empty());
        assert_eq!(
            observations["nodes"].as_array().unwrap().len(),
            attempt.graph.nodes.len()
        );
        match mode {
            Mode::Lock => assert!(
                matches!(&held.graph.outcome, Err(Failure::Activation(ActivationFailure::Lock(e))) if Rc::ptr_eq(&original, &e.original))
            ),
            Mode::Unwind => assert!(
                matches!(&held.boundary, Err(BoundaryFailure::Unwind(payload)) if Arc::ptr_eq(payload.downcast_ref::<Arc<()>>().unwrap(), &unwind))
            ),
            Mode::CaseInterrupt => {
                assert_eq!(
                    observations["activation"]["tests"]
                        .as_array()
                        .unwrap()
                        .len(),
                    2
                );
                assert_eq!(
                    observations["activation"]["tests"][1]["outcome"],
                    "interrupted"
                );
            }
            _ => {
                let error = held.graph.nodes[0]
                    .dataset
                    .result
                    .as_ref()
                    .unwrap()
                    .result
                    .as_ref()
                    .unwrap_err();
                assert!(
                    matches!(error.as_ref(), ExecutionError::ProjectFunction { error, .. } if matches!(&error.kind, FailureKind::CallFailed(e) if Rc::ptr_eq(&original, &e.original)))
                );
                assert_eq!(observations["source_reads"].as_array().unwrap().len(), 1);
                assert_eq!(observations["tables"].as_array().unwrap().len(), 1);
            }
        }
    }
}

#[test]
fn native_report_admission_stops_dependents_and_whole_report_limits_keep_earlier_artifacts() {
    use yamaa_adapters::{
        producer_report::{attempt_report, ProjectionError},
        specification_report::Error,
    };
    let study = Study::new();
    study.rounded();
    study.write(
        "consumer/root.yaml",
        format!("{CONSUMER}verifications:\n  - row_count: {{min: 1}}\n"),
    );
    let mut build = study.build(Language::Python);
    let mut activation = Activation::new(&study, Mode::Pass);
    let mut limits = Limits::default();
    limits.engine.report_bytes = 1;
    let first = build.build_reported(&mut activation, report_id(), limits);
    assert!(!first.accepted());
    assert_eq!(first.graph.nodes.len(), 1);
    assert!(matches!(
        first.graph.nodes[0].output,
        Err(CompleteError::Report(Error::OutputLimit))
    ));
    assert_eq!(activation.trace.len(), 6);
    assert_eq!(
        attempt_report(&first, report_id(), 16_777_216).unwrap()["error"]["code"],
        "output_limit"
    );
    limits.engine.report_bytes = 65536;
    let later = build.build_reported(&mut activation, report_id(), limits);
    assert!(!later.accepted());
    assert_eq!(later.graph.nodes.len(), 2);
    assert!(later.graph.nodes[0]
        .output
        .as_ref()
        .unwrap()
        .as_ref()
        .unwrap()
        .artifact()
        .is_some());
    assert!(matches!(
        later.graph.nodes[1].output,
        Err(CompleteError::Report(Error::OutputLimit))
    ));
    let value = attempt_report(&later, report_id(), 16_777_216).unwrap();
    assert_eq!(value["outcome"], "failure");
    assert_eq!(value["artifacts"].as_array().unwrap().len(), 1);
    let original = later.graph.nodes[0]
        .output
        .as_ref()
        .unwrap()
        .as_ref()
        .unwrap()
        .artifact()
        .unwrap();
    assert_eq!(original.bytes(), b"ID,VALUE\n1,1.23\n2,2.35\n");
    assert!(matches!(
        attempt_report(&later, report_id(), 1),
        Err(ProjectionError::Report(Error::OutputLimit))
    ));
    assert_eq!(original.bytes(), b"ID,VALUE\n1,1.23\n2,2.35\n");
    assert!(!study.0.join("generated").exists());
}

#[test]
fn report_context_pointer_and_table_count_admission_precede_table_authority_and_clear_old_selection(
) {
    use yamaa_adapters::{producer_report::NativeReport, specification_report::Error};
    use yamaa_engine::specification_run::{CapturedAttempt, CapturedSource};
    struct Bomb {
        schema: yamaa_core::table::TableSchema,
        reads: Rc<std::cell::Cell<usize>>,
    }
    impl TableAccess for Bomb {
        type Error = Payload;
        fn schema(&self) -> &yamaa_core::table::TableSchema {
            &self.schema
        }
        fn row_count(&self) -> usize {
            usize::MAX
        }
        fn cell(
            &self,
            _: usize,
            _: usize,
        ) -> Result<ValueRef<'_>, yamaa_core::table::CellError<Payload>> {
            self.reads.set(self.reads.get() + 1);
            panic!("count admission must precede cell authority")
        }
    }
    let study = Study::new();
    study.rounded();
    let mut build = study.build(Language::Python);
    let unrelated = study.build(Language::Python);
    let mut attempt = build.build_reported(
        &mut Activation::new(&study, Mode::Pass),
        report_id(),
        Limits::default(),
    );
    assert!(attempt.accepted());
    let mut report = NativeReport::new(build.provenance(), report_id());
    let node = &build.provenance().metadata().nodes()[1];
    report
        .select(node, &attempt.graph.nodes[0].dataset, 16_777_216)
        .unwrap();
    assert!(matches!(
        report.select(
            &unrelated.provenance().metadata().nodes()[1],
            &attempt.graph.nodes[0].dataset,
            16_777_216
        ),
        Err(Error::InvalidObservation)
    ));
    assert!(matches!(report.failure(), Err(Error::InvalidObservation)));
    let mut entered = attempt.graph.nodes.remove(0);
    let source = entered.dataset.sources.remove(0);
    let reads = Rc::new(std::cell::Cell::new(0));
    let fake = CapturedAttempt::<(), (), Bomb> {
        sources: vec![CapturedSource {
            read: source.read,
            snapshot: source.snapshot,
            table: Some(Bomb {
                schema: source.table.unwrap().schema().clone(),
                reads: Rc::clone(&reads),
            }),
        }],
        result: Ok(entered.dataset.result.map_err(|_| ()).unwrap()),
    };
    assert!(matches!(
        report.select(node, &fake, 16_777_216),
        Err(Error::OutputLimit)
    ));
    assert_eq!(reads.get(), 0);
    assert!(matches!(report.failure(), Err(Error::InvalidObservation)));
}

#[test]
fn whole_report_rejects_contradictory_actual_activation_and_node_order_without_replay() {
    use yamaa_adapters::{
        producer_report::{attempt_report, ProjectionError},
        specification_report::Error,
    };
    let study = Study::new();
    study.rounded();
    let mut build = study.build(Language::Python);
    let mut host = Activation::new(&study, Mode::Pass);
    let mut attempt = build.build_reported(&mut host, report_id(), Limits::default());
    let before = host.trace.clone();
    attempt.graph.activation.tests[0].actual = Some(Value::float(99.0));
    assert!(matches!(
        attempt_report(&attempt, report_id(), 16_777_216),
        Err(ProjectionError::Report(Error::InvalidObservation))
    ));
    attempt.graph.activation.tests[0].actual = Some(Value::float(7.0));
    attempt.graph.nodes.swap(0, 1);
    assert!(matches!(
        attempt_report(&attempt, report_id(), 16_777_216),
        Err(ProjectionError::Report(Error::InvalidObservation))
    ));
    assert_eq!(host.trace, before);
}

#[test]
fn a_larger_caller_report_budget_cannot_defer_the_fixed_formatter_ceiling_until_after_copy() {
    let study = Study::new();
    study.write(
        "producer/p.yaml",
        passthrough(
            "{RAW: {path: ../raw/raw.csv, types: {ID: int, VALUE: str}}}",
            "RAW",
            "../generated/producer.csv",
            "str",
        ),
    );
    study.write(
        "consumer/root.yaml",
        passthrough(
            "{FIRST: {path: ../generated/producer.csv, schema: ../producer/p.yaml}}",
            "FIRST",
            "../generated/root.csv",
            "str",
        ),
    );
    let text = "x".repeat(1_400_000);
    study.write("raw/raw.csv", format!("ID,VALUE\n1,{text}\n"));
    let mut build = study.build(Language::Python);
    let mut host = Activation::new(&study, Mode::Lock);
    let mut limits = Limits::default();
    limits.engine.report_bytes = usize::MAX;
    let attempt = build.build_reported(&mut host, report_id(), limits);
    assert!(!attempt.accepted());
    assert!(host.trace.is_empty());
    assert_eq!(attempt.graph.nodes.len(), 1);
    assert!(attempt.graph.nodes[0]
        .dataset
        .result
        .as_ref()
        .unwrap()
        .result
        .is_ok());
    assert!(matches!(
        attempt.graph.nodes[0].output,
        Err(CompleteError::Report(
            yamaa_adapters::specification_report::Error::OutputLimit
        ))
    ));
    assert_eq!(
        attempt.graph.nodes[0].dataset.sources[0]
            .table
            .as_ref()
            .unwrap()
            .cell(0, 1)
            .unwrap(),
        ValueRef::Str(&text)
    );
    assert!(matches!(
        yamaa_adapters::producer_report::attempt_report(&attempt, report_id(), usize::MAX),
        Err(yamaa_adapters::producer_report::ProjectionError::Report(
            yamaa_adapters::specification_report::Error::OutputLimit
        ))
    ));
    assert!(!study.0.join("generated").exists());
}

#[test]
fn original_native_selection_builds_the_retained_rounded_alias_workflow_without_recapture() {
    use yamaa_adapters::file_workflow::{self, Selected};
    let study = Study::new();
    study.rounded();
    // This preparation fixture independently supplies the real original native
    // environment/lock closure rather than the supplied in-memory test owner.
    study.write("environment.yaml", "schema_version: '1.0'\nlanguage: python\nlock: uv.lock\nfunctions:\n  id_float:\n    function: program.id_float\n    description: Float identity.\n    params: [{name: x, type: float}]\n    returns: float\n    tests:\n      - {id: normal, covers: [normal, numeric-comparison], args: {x: 7.0}, result: 7.0}\n      - {id: boundary, covers: [boundary], args: {x: 0.0}, result: 0.0}\n      - {id: missing, covers: ['short-circuit-missing:x'], args: {x: null}, result: null}\n");
    study.write("uv.lock", "version = 1\npackage = []\n");
    let Selected::Producer(graph) = file_workflow::select_with_resources(
        Resources::new(&study.path(""), &study.path(""), &[]).unwrap(),
        "consumer/root.yaml",
        "environment.yaml",
        Language::Python,
        shipped_schema::capture().unwrap(),
        shipped_schema::capture_environment().unwrap(),
        Default::default(),
    )
    .unwrap() else {
        panic!("producer capability");
    };
    assert_eq!(graph.capture_reads(), 5); // environment, lock, entry, producer, parent
    let root = Arc::clone(&graph.graph().nodes()[0].document);
    let producer = Arc::clone(&graph.graph().nodes()[1].document);
    assert!(Arc::ptr_eq(
        &graph.graph().nodes()[0].producers[0].document,
        &graph.graph().nodes()[0].producers[1].document
    ));
    let mut build = (*graph).into_build();
    assert!(Arc::ptr_eq(&root, &build.provenance().documents()[0]));
    assert!(Arc::ptr_eq(&producer, &build.provenance().documents()[1]));
    let mut activation = Activation::new(&study, Mode::Pass);
    let attempt = build.build_reported(&mut activation, report_id(), Limits::default());
    let execution = attempt.graph.nodes[0]
        .dataset
        .result
        .as_ref()
        .unwrap()
        .result
        .as_ref()
        .unwrap();
    for (row, expected) in [1.234, 2.345].into_iter().enumerate() {
        let ValueRef::Float(value) = execution.dataset.cell(row, 1).unwrap() else {
            panic!("separate unrounded producer truth");
        };
        assert_eq!(value.get(), expected);
    }
    assert_eq!(artifact(&attempt, 0), b"ID,VALUE\n1,1.23\n2,2.35\n");
    assert_eq!(artifact(&attempt, 1), b"ID,VALUE\n1,2.46\n2,4.70\n");
    assert_eq!(attempt.graph.nodes.len(), 2);
    assert_eq!(attempt.graph.nodes[0].dataset.sources.len(), 1);
    assert_eq!(attempt.graph.nodes[1].dataset.sources.len(), 2);
    assert!(!study.0.join("generated/producer.csv").exists());
    assert!(!study.0.join("generated/root.csv").exists());
    drop(build);
    drop(root);
    drop(producer);
    fs::remove_dir_all(&study.0).unwrap();
    assert_eq!(artifact(&attempt, 0), b"ID,VALUE\n1,1.23\n2,2.35\n");
    assert_eq!(artifact(&attempt, 1), b"ID,VALUE\n1,2.46\n2,4.70\n");
}
