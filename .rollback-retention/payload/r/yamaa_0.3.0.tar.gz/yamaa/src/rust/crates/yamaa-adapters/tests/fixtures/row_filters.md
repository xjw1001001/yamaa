# Candidate row filters

The 27 complete reports in `row_filters.tsv` were enumerated independently and compared with actual Python reference execution while native imports were forbidden, before native replay. Twenty-one successful reports retain exact CSV and six grammar, source-reference or phase failures retain complete source observations and failed-save gates. Candidate observations never write expected truth. Existing goldens and the assisted inventory remain unchanged.

The compiler admits filters on converted row columns and direct driver fields for ungrouped rows. Group-reference findings precede filter and derivation findings, including a combined failure with both invalid group and filter. Grouped filters read completed candidate columns, including admitted row-local defaults, and reject source-record reads. Grouped filter reads promote admitted defaults into each template's row scope (REQ-1260). Typed phase findings preserve authored paths, identifiers, row IDs and available/required phases, including the reference vocabulary's absent requirement identifier. Executable predicates, conversion order, three-valued truth and filtering remain existing engine services. All row-filter text is charged before compiling any expression.

Truth covers comparisons, boolean composition, missing/unknown values, empty input, Unicode expressed with valid ASCII YAML escapes, post-conversion reads versus original source values, template declaration order, checks after filtering, grouped MEAN/COUNT and inherited defaults. An initial independently authored template-order expectation was corrected to declaration-order construction before native replay. Grammar and unknown driver-field reports retain existing canonical causes.

Qualified lookup state, broader row derivations and default dependencies remain unsupported. Ungrouped filter promotion of a column default not already selected by a template remains explicitly unsupported pending reconciliation: REQ-1260 names grouped filters as the promoting context, while the reference also promotes ungrouped filter reads. This slice retains that gap without fabricating a phase failure for those forms. Public frontend and warning-severity gates remain open.

`row_filter_admission.tsv` now retains two independently authored complete
failure reports for integer literals behind constant boolean branches. The
approved REQ-0014 predicate carrier rule requires `integer_overflow` during
parsing, with the complete predicate and character position. The findings remain
deferred until source ingestion, preserve the source table and failed-save gate,
and cannot be hidden by boolean short circuiting. The historical reference
reports derivation overflow with an absent requirement; that reference remains
unqualified for this family. Benchmark expected files are unchanged. Parser and
executable-plan resource refusals remain implementation policies.
