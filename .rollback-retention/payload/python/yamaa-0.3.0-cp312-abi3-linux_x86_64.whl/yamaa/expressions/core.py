"""Source resolution and the leaf expressions every dispatch starts from."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Literal, Protocol, TypeAlias

from pydantic import BaseModel, ConfigDict, Field, JsonValue

from yamaa.expressions.text import ascii_upper
from yamaa.models.values import (
    MISSING,
    ConditionPhase,
    ConditionResult,
    EvaluationResult,
    HandlerName,
    HandlerObservation,
    RuntimeCondition,
    ValueResult,
    normalize_runtime_value,
    runtime_type_name,
)
from yamaa.specification.models import Expression


class _FrozenModel(BaseModel):
    model_config = ConfigDict(
        strict=True,
        extra="forbid",
        frozen=True,
        arbitrary_types_allowed=True,
    )


class ResolvedValue(_FrozenModel):
    """A variable exists in the current context and carries this raw value."""

    status: Literal["value"] = "value"
    value: object
    handled_by: HandlerName | None = None


class AbsentValue(_FrozenModel):
    """A variable or ODM item is absent from the current context."""

    status: Literal["absent"] = "absent"
    variable: str = Field(min_length=1)


class FailedResolution(_FrozenModel):
    """Source resolution failed for a reason other than contextual absence."""

    status: Literal["condition"] = "condition"
    condition: RuntimeCondition


Resolution: TypeAlias = ResolvedValue | AbsentValue | FailedResolution


class Resolver(Protocol):
    """Resolve one name without coupling evaluation to a table or join engine."""

    def resolve(self, variable: str) -> Resolution: ...


class SelectedSourceResolver(Protocol):
    """Optional resolver extension for a source that states how it selects.

    REQ-0131 lets a structured source narrow the right-side records it may
    read, and REQ-0353 lets it choose among the survivors. Both reach the
    records through the same call, because the filter decides what the
    selection is applied to.
    """

    def resolve_selected(
        self,
        variable: str,
        *,
        selector: str | None,
        multiple_matches: Mapping[str, object] | None,
    ) -> Resolution: ...


class MappingResolver:
    """Small in-memory resolver useful for scalar execution and tests."""

    def __init__(self, values: Mapping[str, object]) -> None:
        self._values = dict(values)

    def resolve(self, variable: str) -> Resolution:
        if variable not in self._values:
            return AbsentValue(variable=variable)
        return ResolvedValue(value=self._values[variable])

    def resolve_selected(
        self,
        variable: str,
        *,
        selector: str | None,
        multiple_matches: Mapping[str, object] | None,
    ) -> Resolution:
        del selector, multiple_matches
        return self.resolve(variable)


class CallableResolver:
    """Adapt a ``Callable[[str], Resolution]`` to the Resolver protocol.

    REQ-1259 evaluates expression match values through the caller's own
    resolution (the derivation resolver for aggregates, the lookup's
    resolve callable for inline intermediates), so a reference reads
    exactly what the surrounding derivation would read.
    """

    def __init__(self, resolve: Callable[[str], Resolution]) -> None:
        self._resolve = resolve

    def resolve(self, variable: str) -> Resolution:
        return self._resolve(variable)


ExpressionHandler: TypeAlias = Callable[[object, Resolver], EvaluationResult]
ExpressionInput: TypeAlias = Expression | Mapping[str, object]


def expression_condition(
    phase: ConditionPhase,
    condition: str,
    context: dict[str, JsonValue],
    applicable_handler: HandlerName | None = None,
    requirement: str | None = None,
    field: str | None = None,
) -> ConditionResult:
    """Build one structured condition an expression returns rather than raises."""
    return ConditionResult(
        condition=RuntimeCondition(
            phase=phase,
            condition=condition,
            context=context,
            applicable_handler=applicable_handler,
            requirement=requirement,
            path_suffix=field,
        )
    )


def handler_value(
    payload: Mapping[object, object],
    name: HandlerName,
) -> EvaluationResult:
    """Substitute one declared R008 literal and record which handler fired."""
    normalized = normalize_runtime_value(payload[name])
    if isinstance(normalized, ValueResult):
        return ValueResult(value=normalized.value, handled_by=name)
    return normalized


def source_operand(value: object) -> tuple[str, str | None] | None:
    """Split an operand naming a source into its variable and its filter.

    REQ-1052/REQ-1053 type the operand of every operation that names a source
    as a variable or a variable with the `filter` selecting the records it reads.
    The binding handlers stay on the `source` expression, so nothing else is
    accepted here.
    """
    if isinstance(value, str):
        return value, None
    if not isinstance(value, Mapping) or set(value) != {"variable", "filter"}:
        return None
    variable = value.get("variable")
    selector = value.get("filter")
    if not isinstance(variable, str) or not isinstance(selector, str):
        return None
    return variable, selector


def resolve_operand(
    resolver: Resolver,
    variable: str,
    selector: str | None,
) -> Resolution | ConditionResult:
    """Resolve one named source, applying the records filter it declares."""
    if selector is None:
        return resolver.resolve(variable)
    resolve_selected = getattr(resolver, "resolve_selected", None)
    if not callable(resolve_selected):
        return expression_condition(
            "validation",
            "invalid_field_type",
            {"field": "filter", "reason": "resolver unsupported"},
        )
    return resolve_selected(variable, selector=selector, multiple_matches=None)


def _source(payload: object, resolver: Resolver) -> EvaluationResult:
    if isinstance(payload, str):
        variable = payload
        options: Mapping[object, object] = {}
    elif isinstance(payload, Mapping):
        variable = payload.get("variable")
        options = payload
        if not isinstance(variable, str):
            return expression_condition(
                "validation",
                "invalid_field_type",
                {"field": "variable", "expected": "str"},
            )
    else:
        return expression_condition(
            "validation",
            "invalid_field_type",
            {"operation": "source", "expected": "str or mapping"},
        )

    order_by = options.get("order_by")
    keep = options.get("keep")
    if (order_by is None) != (keep is None):
        # REQ-0119: the ordered choice is declared as a pair, like the
        # named intermediate's.
        return expression_condition(
            "validation",
            "unpaired_fields",
            {
                "operation": "source",
                "declared": ["order_by"] if order_by is not None else ["keep"],
                "missing": ["keep"] if order_by is not None else ["order_by"],
            },
            requirement="REQ-0119",
        )
    multiple: Mapping[str, object] | None = None
    if order_by is not None:
        multiple = {"order_by": order_by, "keep": keep}
    selector = options.get("filter")
    if selector is not None and not isinstance(selector, str):
        return expression_condition(
            "validation",
            "invalid_field_type",
            {"field": "filter", "expected": "str"},
        )
    if selector is None and multiple is None:
        resolved = resolver.resolve(variable)
    else:
        resolve_selected = getattr(resolver, "resolve_selected", None)
        if not callable(resolve_selected):
            return expression_condition(
                "validation",
                "invalid_field_type",
                {"field": "filter", "reason": "resolver unsupported"},
            )
        resolved = resolve_selected(
            variable, selector=selector, multiple_matches=multiple
        )
    if isinstance(resolved, ResolvedValue):
        normalized = normalize_runtime_value(resolved.value)
        if isinstance(normalized, ValueResult) and resolved.handled_by is not None:
            return ValueResult(
                value=normalized.value,
                handled_by=resolved.handled_by,
            )
        return normalized
    if isinstance(resolved, FailedResolution):
        return ConditionResult(condition=resolved.condition)
    # REQ-0345: `absent` answers a variable or ODM item that does not exist.
    if "absent" in options:
        return handler_value(options, "absent")
    return expression_condition(
        "mapping",
        "missing_input",
        {"variable": variable},
        "absent",
        requirement="REQ-0334",
    )


def _literal(payload: object, resolver: Resolver) -> EvaluationResult:
    del resolver
    return normalize_runtime_value(payload)


def _mapping(payload: object, resolver: Resolver) -> EvaluationResult:
    if not isinstance(payload, Mapping):
        return expression_condition(
            "validation",
            "invalid_field_type",
            {"operation": "mapping", "expected": "mapping"},
        )
    operand = source_operand(payload.get("source"))
    dictionary = payload.get("dict")
    if isinstance(dictionary, str):
        return expression_condition(
            "validation",
            "invalid_field_type",
            {
                "operation": "mapping",
                "expected": "dict (a dict path is expanded during workflow planning)",
            },
        )
    case_sensitive = payload.get("case_sensitive", True)
    if (
        operand is None
        or not isinstance(dictionary, Mapping)
        or type(case_sensitive) is not bool
    ):
        return expression_condition(
            "validation",
            "invalid_field_type",
            {"operation": "mapping", "expected": "source and dict"},
        )
    variable, selector = operand

    keys = list(dictionary)
    if not all(isinstance(key, str) for key in keys):
        invalid_key = next(key for key in keys if not isinstance(key, str))
        return expression_condition(
            "validation",
            "incompatible_input_type",
            {"expected": "str", "actual": type(invalid_key).__name__},
        )

    folded: dict[str, str] = {}
    if not case_sensitive:
        originals: dict[str, list[str]] = {}
        for key in keys:
            folded_key = ascii_upper(key)
            originals.setdefault(folded_key, []).append(key)
            folded[folded_key] = key
        collisions = {
            key: entries for key, entries in originals.items() if len(entries) > 1
        }
        if collisions:
            folded_key = min(collisions)
            return expression_condition(
                "validation",
                "ambiguous_dictionary",
                {"folded_key": folded_key, "entries": collisions[folded_key]},
                requirement="REQ-0714",
                field="dict",
            )

    resolved = resolve_operand(resolver, variable, selector)
    if isinstance(resolved, ConditionResult):
        return resolved
    if isinstance(resolved, FailedResolution):
        return ConditionResult(condition=resolved.condition)
    if isinstance(resolved, AbsentValue):
        return expression_condition(
            "validation",
            "unknown_field",
            {"identifier": variable},
        )
    normalized = normalize_runtime_value(resolved.value)
    if not isinstance(normalized, ValueResult):
        return normalized
    value = normalized.value
    # REQ-0344 and REQ-1110: each condition has its own handler, and an
    # omitted handler makes its condition fatal.
    if value is MISSING:
        if "missing" in payload:
            return handler_value(payload, "missing")
        return expression_condition(
            "mapping",
            "missing_input",
            {"variable": variable},
            "missing",
            requirement="REQ-0334",
        )
    if not isinstance(value, str):
        return expression_condition(
            "validation",
            "incompatible_input_type",
            {"expected": "str", "actual": runtime_type_name(value)},
        )

    if case_sensitive:
        matched = value if value in dictionary else None
    else:
        matched = folded.get(ascii_upper(value))

    if matched is not None:
        return normalize_runtime_value(dictionary[matched])
    if "unmapped" in payload:
        return handler_value(payload, "unmapped")
    return expression_condition(
        "mapping",
        "unmapped_value",
        {"source": variable, "value": value},
        "unmapped",
        requirement="REQ-0334",
    )


CORE_EXPRESSION_HANDLERS: dict[str, ExpressionHandler] = {
    "source": _source,
    "literal": _literal,
    "mapping": _mapping,
}


class NestedDispatcher(Protocol):
    """The dispatch an operation needs to evaluate an expression it nests."""

    def evaluate(
        self,
        expression: ExpressionInput,
        resolver: Resolver,
    ) -> EvaluationResult: ...


def evaluate_nested(
    dispatcher: NestedDispatcher,
    expression: object,
    resolver: Resolver,
    prefix: str,
) -> tuple[EvaluationResult, tuple[HandlerObservation, ...]]:
    """Evaluate one expression REQ-0290 permits an operation to nest.

    The handler paths a nested expression fires are rebased under `prefix`,
    so the caller that knows the specification path can report every REQ-0361
    count without the nested operation knowing where it sits.
    """
    if not isinstance(expression, Mapping) or len(expression) != 1:
        return (
            expression_condition(
                "validation",
                "invalid_field_type",
                {"field": prefix, "expected": "one expression operation"},
                requirement="REQ-0321",
            ),
            (),
        )
    operation = next(iter(expression))
    result = dispatcher.evaluate(expression, resolver)
    if not isinstance(result, ValueResult):
        return result, ()
    observations: list[HandlerObservation] = []
    if result.handled_by is not None:
        observations.append(
            HandlerObservation(
                path=f"{prefix}.{operation}",
                handler=result.handled_by,
            )
        )
    observations.extend(
        HandlerObservation(
            path=f"{prefix}.{operation}.{observation.path}",
            handler=observation.handler,
        )
        for observation in result.observations
    )
    return result, tuple(observations)


class RelationalResolver(Protocol):
    """Resolver extension for the operations that read a whole relation.

    R003's join and R013's reduction reach records scalar resolution cannot
    see, so the runtime that owns the relation answers for them here rather
    than every expression widening its contract to carry a join engine.
    """

    def resolve_relation(
        self,
        operation: str,
        payload: Mapping[str, object],
    ) -> EvaluationResult: ...


def relational_handler(operation: str) -> ExpressionHandler:
    def handler(payload: object, resolver: Resolver) -> EvaluationResult:
        if isinstance(payload, str):
            payload = {"expr": payload}
        if not isinstance(payload, Mapping):
            return expression_condition(
                "validation",
                "invalid_field_type",
                {"operation": operation, "expected": "a mapping"},
                requirement="REQ-0321",
            )
        resolve_relation = getattr(resolver, "resolve_relation", None)
        if not callable(resolve_relation):
            return expression_condition(
                "validation",
                "invalid_field_type",
                {"operation": operation, "reason": "resolver unsupported"},
            )
        return resolve_relation(operation, dict(payload))

    return handler
