"""Conditional and scalar selection expressions registered under R007.

`first_available`, `greatest`, `least`, and `case` select one already-computed value
rather than compute a new one, so each retains the selected value's type
(REQ-0316). `flag` is the one-predicate shorthand for the common
`case` that returns a flag value (REQ-1256). `cut` is the one operation
here that produces a new string.
"""

from __future__ import annotations

import math
from bisect import bisect_left, bisect_right
from collections.abc import Mapping, Sequence
from itertools import pairwise
from typing import TypeAlias

from yamaa.expressions.core import (
    AbsentValue,
    ExpressionHandler,
    FailedResolution,
    NestedDispatcher,
    ResolvedValue,
    Resolver,
    evaluate_nested,
    expression_condition,
    handler_value,
    resolve_operand,
    source_operand,
)
from yamaa.expressions.predicates import (
    PredicateError,
    PredicateValue,
    TruthValue,
    evaluate_predicate,
    parse_predicate_cached,
)
from yamaa.models import (
    MISSING,
    ConditionResult,
    DateTimeValue,
    DateValue,
    EvaluationResult,
    HandlerObservation,
    RuntimeValue,
    UnsupportedResult,
    ValueResult,
    normalize_runtime_value,
    runtime_type_name,
    values_comparable,
)

OrderKey: TypeAlias = object


def _invalid_payload(operation: str, expected: str) -> ConditionResult:
    return expression_condition(
        "validation",
        "invalid_field_type",
        {"operation": operation, "expected": expected},
        requirement="REQ-0321",
    )


def _resolve(
    variable: object,
    resolver: Resolver,
    operation: str,
    field: str = "source",
    *,
    filtered: bool = False,
) -> ValueResult | ConditionResult:
    """Read an operand REQ-1052/REQ-1053 let `first_available` filter."""
    operand = source_operand(variable) if filtered else None
    if operand is None:
        if not isinstance(variable, str):
            return _invalid_payload(operation, "a variable name")
        operand = (variable, None)
    variable, selector = operand
    resolved = resolve_operand(resolver, variable, selector)
    if isinstance(resolved, ConditionResult):
        return resolved
    if isinstance(resolved, FailedResolution):
        return ConditionResult(condition=resolved.condition)
    if isinstance(resolved, AbsentValue):
        return expression_condition(
            "validation",
            "unknown_field",
            {"identifier": variable},
            requirement="REQ-0103",
            field=field,
        )
    assert isinstance(resolved, ResolvedValue)
    normalized = normalize_runtime_value(resolved.value)
    if isinstance(normalized, ValueResult):
        return normalized
    assert isinstance(normalized, ConditionResult)
    return normalized


def _variables(payload: object, operation: str) -> Sequence[object] | ConditionResult:
    if not isinstance(payload, Mapping):
        return _invalid_payload(operation, "a mapping")
    sources = payload.get("sources")
    if not isinstance(sources, Sequence) or isinstance(sources, (str, bytes)):
        return _invalid_payload(operation, "a list of variables")
    return sources


def _first_available(payload: object, resolver: Resolver) -> EvaluationResult:
    sources = _variables(payload, "first_available")
    if isinstance(sources, ConditionResult):
        return sources
    assert isinstance(payload, Mapping)
    for variable in sources:
        resolved = _resolve(
            variable, resolver, "first_available", "sources", filtered=True
        )
        if not isinstance(resolved, ValueResult):
            return resolved
        if resolved.value is not MISSING:
            return ValueResult(value=resolved.value)
    if "missing" in payload:
        # `missing` is not an R008 handler, so it is counted by no path.
        return normalize_runtime_value(payload["missing"])
    return ValueResult(value=MISSING)


def _order_key(value: RuntimeValue) -> OrderKey:
    if isinstance(value, (DateValue, DateTimeValue)):
        return value.ordering_key
    return value


def _extreme(operation: str, *, largest: bool) -> ExpressionHandler:
    def handler(payload: object, resolver: Resolver) -> EvaluationResult:
        sources = _variables(payload, operation)
        if isinstance(sources, ConditionResult):
            return sources
        values: list[RuntimeValue] = []
        for variable in sources:
            resolved = _resolve(variable, resolver, operation, "sources")
            if not isinstance(resolved, ValueResult):
                return resolved
            values.append(resolved.value)

        present = [value for value in values if value is not MISSING]
        # REQ-0310 and REQ-0324: a mixed `sources` list fails rather than
        # coercing one operand into the other's type.
        for other in present[1:]:
            if not values_comparable(present[0], other):
                return expression_condition(
                    "validation",
                    "incomparable_sources",
                    {
                        "sources": [str(name) for name in sources],
                        "types": [runtime_type_name(value) for value in values],
                    },
                    requirement="REQ-0324",
                )
        if not present:
            return ValueResult(value=MISSING)
        chooser = max if largest else min
        return ValueResult(value=chooser(present, key=_order_key))

    return handler


def _case(dispatcher: NestedDispatcher) -> ExpressionHandler:
    def handler(payload: object, resolver: Resolver) -> EvaluationResult:
        # REQ-0339: a non-empty list of when/then items with an optional
        # single trailing otherwise item. A case with no when/then item
        # fails, even when the lone otherwise item is well-formed.
        if not isinstance(payload, Sequence) or isinstance(payload, (str, bytes)):
            return _invalid_payload("case", "a list of when/then items")
        if not payload:
            return _invalid_payload("case", "at least one when/then item")
        otherwise = None
        has_otherwise = False
        has_branch = False
        for index, item in enumerate(payload):
            if not isinstance(item, Mapping):
                return _invalid_payload("case", "a when/then or otherwise item")
            if "otherwise" in item:
                if has_otherwise or index != len(payload) - 1:
                    return _invalid_payload("case", "a single trailing otherwise item")
                has_otherwise = True
                otherwise = item["otherwise"]
                continue
            has_branch = True
            when = item.get("when")
            if not isinstance(when, str):
                return _invalid_payload("case", "a branch predicate")
            if "then" not in item:
                return _invalid_payload("case", "a when/then item")
            try:
                ast = parse_predicate_cached(when)
            except PredicateError as error:
                return expression_condition(
                    "validation",
                    "invalid_predicate",
                    {"predicate": when, "position": error.position},
                    requirement=error.requirement,
                    field=f"[{index}].when",
                )
            decided = evaluate_predicate(ast, resolver)
            if isinstance(decided, ConditionResult):
                path_suffix = f"[{index}].when"
                if decided.condition.path_suffix is not None:
                    path_suffix = f"{path_suffix}.{decided.condition.path_suffix}"
                return ConditionResult(
                    condition=decided.condition.model_copy(
                        update={"path_suffix": path_suffix}
                    )
                )
            assert isinstance(decided, PredicateValue)
            # R004 three-valued logic: only TRUE selects the branch.
            if decided.value is not TruthValue.TRUE:
                continue
            result, observations = evaluate_nested(
                dispatcher,
                item.get("then"),
                resolver,
                f"[{index}].then",
            )
            return _selected(result, observations)

        if not has_branch:
            return _invalid_payload("case", "at least one when/then item")

        if has_otherwise:
            result, observations = evaluate_nested(
                dispatcher, otherwise, resolver, "otherwise"
            )
            return _selected(result, observations)
        return ValueResult(value=MISSING)

    return handler


def _selected(
    result: EvaluationResult,
    observations: tuple[HandlerObservation, ...],
) -> EvaluationResult:
    """Return the selected value, carrying what its branch handled."""
    if isinstance(result, (ConditionResult, UnsupportedResult)):
        return result
    return ValueResult(value=result.value, observations=observations)


def _flag(payload: object, resolver: Resolver) -> EvaluationResult:
    def handler_value_or_missing(value: object) -> EvaluationResult:
        # R008: branch values are literals, so a dict or list becomes a
        # structured validation condition instead of a raw pydantic crash.
        return normalize_runtime_value(value)

    # REQ-1256: the one-predicate flag shorthand. A bare predicate string is
    # the condition with the default values; a mapping names condition and
    # any of true_value, false_value, missing. REQ-1257 gives the
    # three-valued semantics: only TRUE takes true_value; FALSE takes
    # false_value when present; UNKNOWN takes missing when present.
    # Either absent value is missing, which is exactly the one-branch
    # `case` the shorthand replaces; REQ-1258 lets missing be absent
    # only when false_value is absent too.
    if isinstance(payload, str):
        payload = {"condition": payload}
    if not isinstance(payload, Mapping):
        return _invalid_payload(
            "flag", "a predicate string or a mapping with a condition"
        )
    condition = payload.get("condition")
    if not isinstance(condition, str):
        return _invalid_payload("flag", "a branch predicate in condition")
    try:
        ast = parse_predicate_cached(condition)
    except PredicateError as error:
        return expression_condition(
            "validation",
            "invalid_predicate",
            {"predicate": condition, "position": error.position},
            requirement=error.requirement,
            field="condition",
        )
    if "false_value" in payload and "missing" not in payload:
        return expression_condition(
            "validation",
            "missing_value_required",
            {"false_value": payload["false_value"]},
            requirement="REQ-1258",
            field="missing",
        )
    decided = evaluate_predicate(ast, resolver)
    if isinstance(decided, ConditionResult):
        path_suffix = "condition"
        if decided.condition.path_suffix is not None:
            path_suffix = f"{path_suffix}.{decided.condition.path_suffix}"
        return ConditionResult(
            condition=decided.condition.model_copy(update={"path_suffix": path_suffix})
        )
    assert isinstance(decided, PredicateValue)
    # R004 three-valued logic: only TRUE selects the true value; unlike
    # `case` with `otherwise`, UNKNOWN does not fall through to false_value.
    if decided.value is TruthValue.TRUE:
        return handler_value_or_missing(payload.get("true_value", "Y"))
    if decided.value is TruthValue.FALSE:
        return handler_value_or_missing(payload.get("false_value"))
    return handler_value_or_missing(payload.get("missing"))


def _cut(payload: object, resolver: Resolver) -> EvaluationResult:
    if not isinstance(payload, Mapping):
        return _invalid_payload("cut", "a mapping")
    variable = payload.get("source")
    breaks = payload.get("breaks")
    labels = payload.get("labels")
    right = payload.get("right", False)
    if (
        not isinstance(breaks, Sequence)
        or isinstance(breaks, (str, bytes))
        or not isinstance(labels, Sequence)
        or isinstance(labels, (str, bytes))
        or type(right) is not bool
    ):
        return _invalid_payload("cut", "breaks, labels, and right")
    if len(labels) != len(breaks) + 1 or not all(
        isinstance(label, str) for label in labels
    ):
        return _invalid_payload("cut", "one label more than breaks")
    if any(
        type(value) is bool or not isinstance(value, (int, float)) for value in breaks
    ):
        return _invalid_payload("cut", "numeric breaks")
    try:
        thresholds = [float(value) for value in breaks]
    except OverflowError:
        # An integer beyond binary64 range is numeric and ordered, but the
        # cut runs on binary64 thresholds; rejecting it here keeps the
        # failure a structured validation condition like the NaN rejection
        # below instead of an unhandled host OverflowError.
        return _invalid_payload("cut", "breaks representable as binary64")
    if any(math.isnan(threshold) for threshold in thresholds):
        # NaN is unordered: it defeats the ascending check below and makes
        # bisect return an implementation-defined label. Infinite breaks are
        # legitimate cut boundaries and keep their ordering semantics.
        return _invalid_payload("cut", "breaks without NaN")
    if any(later <= earlier for earlier, later in pairwise(thresholds)):
        return _invalid_payload("cut", "ascending breaks")

    resolved = _resolve(variable, resolver, "cut")
    if not isinstance(resolved, ValueResult):
        return resolved
    value = resolved.value
    if value is MISSING:
        if "missing" in payload:
            return handler_value(payload, "missing")
        return expression_condition(
            "cut",
            "missing_input",
            {"variable": str(variable)},
            applicable_handler="missing",
            requirement="REQ-0334",
        )
    actual = runtime_type_name(value)
    if actual not in {"int", "float"}:
        return expression_condition(
            "validation",
            "incompatible_input_type",
            {"source": str(variable), "expected": "numeric", "actual": actual},
            requirement="REQ-0306",
            field="source",
        )

    number = float(value)  # type: ignore[arg-type]
    # `right` false is left-closed and right-open; true is its mirror.
    index = (
        bisect_left(thresholds, number) if right else bisect_right(thresholds, number)
    )
    return ValueResult(value=labels[index])


def scalar_handlers(dispatcher: NestedDispatcher) -> dict[str, ExpressionHandler]:
    """Return the R007 selection operations this component registers."""
    return {
        "first_available": _first_available,
        "greatest": _extreme("greatest", largest=True),
        "least": _extreme("least", largest=False),
        "case": _case(dispatcher),
        "flag": _flag,
        "cut": _cut,
    }
