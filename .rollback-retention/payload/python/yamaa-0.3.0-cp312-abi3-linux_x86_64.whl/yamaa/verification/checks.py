"""Key validation and verifications over one completed table.

Each check reads values that have already finished their R005 lifecycle and
reports failures rather than raising, so an executor can run one at the
stage R005 gives it: a column check after that column's conversion, key
validation once every column is complete, and the dataset checks last.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from typing import Literal

from pydantic import JsonValue

from yamaa.expressions import (
    MappingResolver,
    PredicateAst,
    PredicateError,
    TruthValue,
    evaluate_predicate,
    parse_predicate,
)
from yamaa.io.polars import runtime_rows, runtime_value
from yamaa.models import (
    MISSING,
    ConditionResult,
    DateTimeValue,
    DateValue,
    RuntimeValue,
    TypedColumn,
    TypedTable,
    ValueResult,
    convert_value,
    normalize_runtime_value,
    runtime_type_name,
)
from yamaa.regex import Regex, RegexError, compile_pattern
from yamaa.specification.models import Column, ColumnType, Expression
from yamaa.verification.diagnostics import (
    REPORTED_KEYS,
    DeclarationError,
    VerificationError,
    VerificationFailure,
    VerificationRecord,
    VerificationSeverity,
)

_NUMERIC: frozenset[ColumnType] = frozenset({"int", "float"})

_COLUMN_REQUIREMENTS = {
    "not_missing": ("not_missing_failed", "REQ-0375"),
    "allowed_values": ("allowed_values_failed", "REQ-0376"),
    "range": ("range_failed", "REQ-0377"),
    "max_length": ("length_failed", "REQ-0378"),
    "matches": ("matches_failed", "REQ-0379"),
}
_DATASET_REQUIREMENTS = {
    "unique": ("unique_failed", "REQ-0381"),
    "all_or_none": ("all_or_none_failed", "REQ-0382"),
    "assert": ("assert_failed", "REQ-0384"),
    "row_count": ("row_count_failed", "REQ-0385"),
}
KeyMap = dict[str, JsonValue]


def _json(value: RuntimeValue) -> JsonValue:
    if value is MISSING:
        return None
    if isinstance(value, (DateValue, DateTimeValue)):
        return value.to_text()
    return value


def _operation(
    expression: Expression, spec_path: str
) -> tuple[str, Mapping[str, JsonValue], VerificationSeverity]:
    keyword = expression.operation
    arguments = expression.root[keyword]
    if arguments is None:
        arguments = {}
    if keyword == "unique" and isinstance(arguments, list):
        arguments = {"columns": arguments}
    if not isinstance(arguments, Mapping):
        raise DeclarationError(
            f"{spec_path}.{keyword}",
            "REQ-0397",
            "a verification takes named arguments",
        )
    severity = arguments.get("severity", "error")
    if severity not in {"error", "warning"}:
        raise DeclarationError(
            f"{spec_path}.{keyword}.severity",
            "REQ-0389",
            "verification severity is error or warning",
            condition="value_not_permitted",
            context={"value": severity, "permitted": ["error", "warning"]},
        )
    return keyword, arguments, severity


def _values(table: TypedTable, name: str) -> list[RuntimeValue]:
    return [runtime_value(value) for value in table.frame.get_column(name).to_list()]


def _key_maps(table: TypedTable, keys: Sequence[str]) -> list[KeyMap]:
    columns = {name: _values(table, name) for name in keys}
    return [
        {name: _json(columns[name][index]) for name in keys}
        for index in range(table.frame.height)
    ]


def _require_columns(
    table: TypedTable, names: Iterable[str], spec_path: str, requirement: str
) -> None:
    declared = {column.name for column in table.columns}
    for name in names:
        if name not in declared:
            raise DeclarationError(
                spec_path,
                requirement,
                f"unknown column {name!r}",
                condition="unknown_field",
            )


def _failure(
    condition: str,
    spec_path: str,
    requirement: str,
    context: dict[str, JsonValue],
    offending: Sequence[KeyMap],
    *,
    count: int | None = None,
    count_name: str = "failure_count",
    phase: Literal["output", "verification"] = "verification",
    extra: dict[str, JsonValue] | None = None,
    log_extra: dict[str, JsonValue] | None = None,
    severity: VerificationSeverity = "error",
) -> VerificationFailure:
    all_context = {
        **context,
        count_name: len(offending) if count is None else count,
        "keys": list(offending),
        **(log_extra if log_extra is not None else (extra or {})),
    }
    return VerificationFailure(
        phase=phase,
        condition=condition,
        spec_paths=(spec_path,),
        requirement=requirement,
        context={
            **context,
            count_name: len(offending) if count is None else count,
            "keys": list(offending[:REPORTED_KEYS]),
            **(extra or {}),
        },
        severity=severity,
        offending_keys=tuple(offending),
        log_context=all_context,
    )


def _groups(
    values: Sequence[tuple[RuntimeValue, ...]],
) -> dict[tuple[object, ...], list[int]]:
    """Partition row positions by a comparable form of their values."""
    partitions: dict[tuple[object, ...], list[int]] = {}
    for index, combined in enumerate(values):
        partitions.setdefault(tuple(_json(value) for value in combined), []).append(
            index
        )
    return partitions


def _declared(table: TypedTable) -> dict[str, ColumnType]:
    """The names and types a predicate may read on a completed row."""
    return {column.name: column.type for column in table.columns}


def _identifiers(node: object) -> set[str]:
    """Collect every variable one parsed predicate reads."""
    if isinstance(node, Mapping):
        names = {node["name"]} if node.get("kind") == "identifier" else set()
        for value in node.values():
            names |= _identifiers(value)
        return names
    if isinstance(node, list):
        return set().union(*(_identifiers(value) for value in node)) if node else set()
    return set()


def _predicate(
    text: JsonValue,
    spec_path: str,
    requirement: str,
    available: Mapping[str, ColumnType],
) -> PredicateAst:
    if not isinstance(text, str):
        raise DeclarationError(spec_path, requirement, "a predicate must be text")
    try:
        parsed = parse_predicate(text)
    except PredicateError as error:
        raise DeclarationError(
            spec_path,
            error.requirement,
            str(error),
            condition="invalid_predicate",
        ) from error
    # A name is resolved against the declared columns rather than against a
    # row, so a predicate naming a column the artifact does not have is
    # refused even when no row exists to read it on.
    unknown = sorted(_identifiers(parsed) - available.keys())
    if unknown:
        raise DeclarationError(
            spec_path,
            "REQ-0405",
            f"predicate names unknown column {unknown[0]!r}",
            condition="unknown_field",
            context={"identifier": unknown[0]},
        )
    # Operand compatibility is a property of the declaration and its field
    # schema, not of whichever values happen to occur in a row. Evaluate the
    # parsed predicate once with a representative non-missing value of every
    # declared type so an empty table, or a row a `when` exempts, cannot
    # hide an invalid comparison.
    samples: dict[str, RuntimeValue] = {
        name: _PREDICATE_SAMPLES[column_type] for name, column_type in available.items()
    }
    result = evaluate_predicate(parsed, MappingResolver(samples))
    if isinstance(result, ConditionResult):
        _raise_predicate_condition(result, spec_path)
    return parsed


_PREDICATE_SAMPLES: dict[ColumnType, RuntimeValue] = {
    "str": "sample",
    "int": 0,
    "float": 0.0,
    "date": DateValue(year=2000, month=1, day=1),
    "datetime": DateTimeValue(
        year=2000,
        month=1,
        day=1,
        hour=0,
        minute=0,
        second=0,
    ),
}


def _raise_predicate_condition(result: ConditionResult, spec_path: str) -> None:
    condition = result.condition
    requirement = {
        "unknown_field": "REQ-0189",
        "unresolvable_name": "REQ-0189",
        "incompatible_input_type": "REQ-0190",
        "invalid_predicate": "REQ-0191",
    }.get(condition.condition, "REQ-0397")
    raise DeclarationError(
        spec_path,
        requirement,
        f"predicate cannot be evaluated: {condition.condition}",
        condition=condition.condition,
        context=dict(condition.context),
    )


def _truth(
    ast: PredicateAst, row: Mapping[str, RuntimeValue], spec_path: str
) -> TruthValue:
    """Evaluate one predicate, failing rather than reading a condition as UNKNOWN.

    R004 decides an operand incompatibility and an unknown field before any
    row is read, so neither may be folded into three-valued logic: doing so
    would let an unevaluable `when` silently exempt a row from an `assert`.
    """
    result = evaluate_predicate(ast, MappingResolver(dict(row)))
    if isinstance(result, ConditionResult):
        _raise_predicate_condition(result, spec_path)
    return result.value


def _lookup_bindings(
    table: TypedTable,
    columns: Sequence[TypedColumn],
    rows: Sequence[Mapping[str, object]] | None,
) -> tuple[dict[str, ColumnType], list[dict[str, RuntimeValue]]]:
    """Validate and normalize one lookup binding aligned to every output row."""
    lookup_types = {column.name: column.type for column in columns}
    if len(lookup_types) != len(columns):
        raise ValueError("lookup column names must be unique")
    if any(
        name.count(".") != 1 or not all(part for part in name.split("."))
        for name in lookup_types
    ):
        raise ValueError("record lookup column names must be qualified")
    output_names = {column.name for column in table.columns}
    if output_names.intersection(lookup_types):
        raise ValueError("record lookup columns must not shadow output columns")

    bindings = [{} for _ in range(table.frame.height)] if rows is None else list(rows)
    if len(bindings) != table.frame.height:
        raise ValueError("record lookup rows must align with output rows")
    expected = set(lookup_types)
    normalized_rows: list[dict[str, RuntimeValue]] = []
    for index, binding in enumerate(bindings):
        if not isinstance(binding, Mapping) or set(binding) != expected:
            raise ValueError("record lookup row fields must match their schema")
        normalized: dict[str, RuntimeValue] = {}
        for name, value in binding.items():
            result = normalize_runtime_value(runtime_value(value))
            if not isinstance(result, ValueResult):
                raise TypeError(
                    f"record lookup row {index} field {name!r} is not a runtime value"
                )
            actual = runtime_type_name(result.value)
            if result.value is not MISSING and actual != lookup_types[name]:
                raise ValueError(
                    f"record lookup row {index} field {name!r} must be "
                    f"{lookup_types[name]}, not {actual}"
                )
            normalized[name] = result.value
        normalized_rows.append(normalized)
    return lookup_types, normalized_rows


def check_column(
    table: TypedTable,
    column: Column,
    keys: Sequence[str],
    *,
    records: list[VerificationRecord] | None = None,
) -> tuple[VerificationFailure, ...]:
    """Run one column's verifications over its completed values (R005 stage 5).

    Returns one failure per violated check; a check that holds contributes
    no failure. When ``records`` is given, one :class:`VerificationRecord`
    is appended per evaluated check, held or violated, in declaration order,
    so the verification log can report what ran (REQ-1173).
    """
    declarations = column.verifications or ()
    if not declarations:
        return ()
    _require_columns(table, [column.name, *keys], f"columns.{column.name}", "REQ-0405")
    values = _values(table, column.name)
    key_maps = _key_maps(table, keys)
    failures: list[VerificationFailure] = []
    identifiers: dict[str, str] = {}
    for index, declaration in enumerate(declarations):
        path = f"columns.{column.name}.verifications[{index}]"
        keyword, arguments, severity = _operation(declaration, path)
        if keyword not in _COLUMN_REQUIREMENTS:
            raise DeclarationError(
                f"{path}.{keyword}",
                "REQ-0397",
                "unknown column verification",
            )
        condition, requirement = _COLUMN_REQUIREMENTS[keyword]
        spec_path = f"{path}.{keyword}"
        identifier = _identifier(arguments, spec_path)
        if identifier is not None:
            if identifier in identifiers:
                raise DeclarationError(
                    spec_path,
                    "REQ-0398",
                    f"verification id {identifier!r} repeats {identifiers[identifier]}",
                    condition="duplicate_identifier",
                )
            identifiers[identifier] = spec_path
        offending = _column_offenders(
            keyword, arguments, column, values, key_maps, spec_path
        )
        failure: VerificationFailure | None = None
        if offending:
            context: dict[str, JsonValue] = {"column": column.name}
            if identifier is not None:
                context["verification_id"] = identifier
            if keyword == "max_length":
                context["max"] = arguments["max"]
            failure = _failure(
                condition,
                spec_path,
                requirement,
                context,
                offending,
                severity=severity,
            )
            failures.append(failure)
        if records is not None:
            records.append(
                VerificationRecord(
                    spec_path=spec_path,
                    check=keyword,
                    target=column.name,
                    requirement=requirement,
                    verification_id=identifier,
                    severity=severity,
                    evaluated_count=len(values),
                    failure=failure,
                )
            )
    return tuple(failures)


def _column_offenders(
    keyword: str,
    arguments: Mapping[str, JsonValue],
    column: Column,
    values: Sequence[RuntimeValue],
    key_maps: Sequence[KeyMap],
    spec_path: str,
) -> list[KeyMap]:
    present = [
        (index, value) for index, value in enumerate(values) if value is not MISSING
    ]
    if keyword == "not_missing":
        return [
            key_maps[index] for index, value in enumerate(values) if value is MISSING
        ]
    if keyword == "allowed_values":
        accepted = _allowed_values(arguments, column, spec_path)
        return [key_maps[index] for index, value in present if value not in accepted]
    if keyword == "range":
        minimum, maximum = _range_bounds(arguments, column, spec_path)
        return [
            key_maps[index]
            for index, value in present
            if (minimum is not None and value < minimum)
            or (maximum is not None and value > maximum)
        ]
    if keyword == "max_length":
        maximum = _max_length(arguments, column, spec_path)
        return [key_maps[index] for index, value in present if len(value) > maximum]
    pattern = _pattern(arguments, column, spec_path)
    return [
        key_maps[index] for index, value in present if pattern.search(value) is None
    ]


def _require_type(
    column: Column, admitted: frozenset[ColumnType], spec_path: str
) -> None:
    if column.type not in admitted:
        raise DeclarationError(
            spec_path,
            "REQ-0404",
            f"a {column.type} column does not admit this verification",
        )


def _allowed_values(
    arguments: Mapping[str, JsonValue], column: Column, spec_path: str
) -> list[RuntimeValue]:
    listed = arguments.get("values")
    if not isinstance(listed, list) or not listed:
        raise DeclarationError(spec_path, "REQ-0397", "allowed_values requires values")
    accepted: list[RuntimeValue] = []
    for value in listed:
        converted = convert_value(value, column.type)
        if not isinstance(converted, ValueResult) or converted.value is MISSING:
            raise DeclarationError(
                spec_path,
                "REQ-0404",
                f"listed value {value!r} is not a {column.type} value",
            )
        accepted.append(converted.value)
    return accepted


def _range_bounds(
    arguments: Mapping[str, JsonValue], column: Column, spec_path: str
) -> tuple[float | int | None, float | int | None]:
    _require_type(column, _NUMERIC, spec_path)
    minimum = arguments.get("min")
    maximum = arguments.get("max")
    for bound in (minimum, maximum):
        if bound is not None and (
            isinstance(bound, bool) or not isinstance(bound, (int, float))
        ):
            raise DeclarationError(spec_path, "REQ-0397", "a range bound is numeric")
    if minimum is None and maximum is None:
        raise DeclarationError(spec_path, "REQ-0399", "range requires one bound")
    if minimum is not None and maximum is not None and minimum > maximum:
        raise DeclarationError(spec_path, "REQ-0399", "range min exceeds max")
    return minimum, maximum


def _max_length(
    arguments: Mapping[str, JsonValue], column: Column, spec_path: str
) -> int:
    _require_type(column, frozenset({"str"}), spec_path)
    maximum = arguments.get("max")
    if isinstance(maximum, bool) or not isinstance(maximum, int):
        raise DeclarationError(spec_path, "REQ-0397", "max_length requires a max")
    if maximum < 1:
        raise DeclarationError(spec_path, "REQ-0400", "max_length max is at least one")
    return maximum


def _pattern(
    arguments: Mapping[str, JsonValue], column: Column, spec_path: str
) -> Regex:
    _require_type(column, frozenset({"str"}), spec_path)
    pattern = arguments.get("pattern")
    if not isinstance(pattern, str):
        raise DeclarationError(spec_path, "REQ-0397", "matches requires a pattern")
    try:
        # `matches` is a search, so the pattern source is compiled as written
        # and is not anchored.
        return compile_pattern(pattern)
    except RegexError as error:
        raise DeclarationError(
            f"{spec_path}.pattern",
            "REQ-0827",
            error.reason,
            condition="invalid_regex",
            context={"pattern": pattern},
        ) from error


def check_keys(
    table: TypedTable, keys: Sequence[str]
) -> tuple[VerificationFailure, ...]:
    """Validate output identity once every column's lifecycle is complete."""
    if not keys:
        raise DeclarationError("keys", "REQ-0220", "keys names at least one column")
    if len(set(keys)) != len(keys):
        raise DeclarationError("keys", "REQ-0220", "a key column is repeated")
    _require_columns(table, keys, "keys", "REQ-0220")

    columns = {name: _values(table, name) for name in keys}
    key_maps = _key_maps(table, keys)
    failures: list[VerificationFailure] = []
    for position, name in enumerate(keys):
        offending = [
            key_maps[index]
            for index, value in enumerate(columns[name])
            if value is MISSING
        ]
        if offending:
            failures.append(
                _failure(
                    "missing_key",
                    f"keys[{position}]",
                    "REQ-0240",
                    {"column": name},
                    offending,
                    count_name="missing_count",
                    phase="output",
                )
            )

    combined = [
        tuple(columns[name][index] for name in keys)
        for index in range(table.frame.height)
    ]
    duplicated = [
        key_maps[positions[0]]
        for positions in _groups(combined).values()
        if len(positions) > 1
    ]
    if duplicated:
        failures.append(
            _failure(
                "duplicate_key",
                "keys",
                "REQ-0240",
                {},
                duplicated,
                count_name="duplicate_count",
                phase="output",
            )
        )
    return tuple(failures)


def check_dataset(
    table: TypedTable,
    verifications: Sequence[Expression],
    keys: Sequence[str],
    *,
    lookup_columns: Sequence[TypedColumn] = (),
    lookup_rows: Sequence[Mapping[str, object]] | None = None,
    records: list[VerificationRecord] | None = None,
) -> tuple[VerificationFailure, ...]:
    """Run dataset verifications with resolved per-row lookup bindings.

    Returns one failure per violated check; a check that holds contributes
    no failure. When ``records`` is given, one :class:`VerificationRecord`
    is appended per evaluated check, held or violated, in declaration order,
    so the verification log can report what ran (REQ-1173).
    """
    if not verifications:
        if lookup_columns or lookup_rows is not None:
            _lookup_bindings(table, lookup_columns, lookup_rows)
        return ()
    _require_columns(table, keys, "keys", "REQ-0220")
    lookup_types, lookup_rows = _lookup_bindings(table, lookup_columns, lookup_rows)
    identifiers: dict[str, str] = {}
    failures: list[VerificationFailure] = []
    key_maps = _key_maps(table, keys)
    rows = runtime_rows(table)
    predicate_types = {**_declared(table), **lookup_types}
    predicate_rows = [
        {**row, **lookup_row} for row, lookup_row in zip(rows, lookup_rows, strict=True)
    ]
    for index, declaration in enumerate(verifications):
        path = f"verifications[{index}]"
        keyword, arguments, severity = _operation(declaration, path)
        if keyword not in _DATASET_REQUIREMENTS:
            raise DeclarationError(
                f"{path}.{keyword}", "REQ-0397", "unknown dataset verification"
            )
        spec_path = f"{path}.{keyword}"
        identifier = _identifier(arguments, spec_path)
        if identifier is not None:
            if identifier in identifiers:
                raise DeclarationError(
                    spec_path,
                    "REQ-0398",
                    f"verification id {identifier!r} repeats {identifiers[identifier]}",
                    condition="duplicate_identifier",
                )
            identifiers[identifier] = spec_path
        failure, evaluated_count = _dataset_failure(
            keyword,
            arguments,
            table,
            rows,
            predicate_rows,
            predicate_types,
            key_maps,
            identifier,
            spec_path,
            severity,
        )
        if failure is not None:
            failures.append(failure)
        if records is not None:
            records.append(
                VerificationRecord(
                    spec_path=spec_path,
                    check=keyword,
                    target=None,
                    requirement=_DATASET_REQUIREMENTS[keyword][1],
                    verification_id=identifier,
                    severity=severity,
                    evaluated_count=evaluated_count,
                    failure=failure,
                )
            )
    return tuple(failures)


def _identifier(arguments: Mapping[str, JsonValue], spec_path: str) -> str | None:
    if "id" not in arguments:
        return None
    identifier = arguments["id"]
    if not isinstance(identifier, str) or not identifier:
        raise DeclarationError(spec_path, "REQ-0374", "a verification id is text")
    return identifier


def _assertion_fails(
    when: PredicateAst | None,
    require: PredicateAst,
    row: Mapping[str, RuntimeValue],
    when_path: str,
    require_path: str,
) -> bool:
    """Evaluate both predicates before applying the REQ-0383 guard.

    A row fails when `require` is not TRUE and `when`, if declared, is TRUE.
    Both predicates are evaluated on every row, so a condition raised by
    `require` is reported even on a row its `when` exempts.
    """
    when_truth = TruthValue.TRUE if when is None else _truth(when, row, when_path)
    require_truth = _truth(require, row, require_path)
    return when_truth is TruthValue.TRUE and require_truth is not TruthValue.TRUE


def _dataset_failure(
    keyword: str,
    arguments: Mapping[str, JsonValue],
    table: TypedTable,
    rows: Sequence[Mapping[str, RuntimeValue]],
    predicate_rows: Sequence[Mapping[str, RuntimeValue]],
    predicate_types: Mapping[str, ColumnType],
    key_maps: Sequence[KeyMap],
    identifier: str | None,
    spec_path: str,
    severity: VerificationSeverity,
) -> tuple[VerificationFailure | None, int]:
    """Evaluate one dataset check, returning the failure and evaluated count.

    The count is what REQ-1176 reports as ``EVALUATED_COUNT``: the distinct
    combinations for ``unique``, the partition groups for ``row_count``, and
    the artifact's rows for the checks evaluated row-wise.
    """
    condition, requirement = _DATASET_REQUIREMENTS[keyword]
    context: dict[str, JsonValue] = {}
    if identifier is not None:
        context["verification_id"] = identifier

    if keyword == "row_count":
        return _row_count_failure(
            arguments,
            table,
            rows,
            predicate_rows,
            predicate_types,
            condition,
            requirement,
            context,
            spec_path,
            severity,
        )

    if keyword == "unique":
        names = _column_list(arguments, "columns", table, spec_path)
        combined = [tuple(row[name] for name in names) for row in rows]
        partitions = _groups(combined)
        # Each distinct combination is one evaluated unit; a repeated
        # combination is one failure, and every row carrying it is reported,
        # because the offending rows differ in their own keys.
        evaluated = len(partitions)
        repeated = [
            positions for positions in partitions.values() if len(positions) > 1
        ]
        if not repeated:
            return None, evaluated
        context["columns"] = list(names)
        return (
            _failure(
                condition,
                spec_path,
                requirement,
                context,
                [
                    key_maps[position]
                    for positions in repeated
                    for position in positions
                ],
                count=len(repeated),
                severity=severity,
            ),
            evaluated,
        )

    if keyword == "all_or_none":
        names = _column_list(arguments, "columns", table, spec_path)
        if len(set(names)) < 2:
            raise DeclarationError(
                spec_path, "REQ-0401", "all_or_none names two distinct columns"
            )
        offending = [
            key_maps[index]
            for index, row in enumerate(rows)
            if len({row[name] is MISSING for name in names}) > 1
        ]
    else:
        when_path = f"{spec_path}.when"
        require_path = f"{spec_path}.require"
        when = (
            _predicate(arguments["when"], when_path, "REQ-0397", predicate_types)
            if arguments.get("when") is not None
            else None
        )
        require = _predicate(
            arguments.get("require"), require_path, "REQ-0397", predicate_types
        )
        offending = [
            key_maps[index]
            for index, row in enumerate(predicate_rows)
            if _assertion_fails(when, require, row, when_path, require_path)
        ]

    if not offending:
        return None, len(rows)
    return (
        _failure(
            condition,
            spec_path,
            requirement,
            context,
            offending,
            severity=severity,
        ),
        len(rows),
    )


def _column_list(
    arguments: Mapping[str, JsonValue],
    field: str,
    table: TypedTable,
    spec_path: str,
) -> list[str]:
    names = arguments.get(field)
    if not isinstance(names, list) or not names:
        raise DeclarationError(
            spec_path, "REQ-0397", f"{field} names at least one column"
        )
    if any(not isinstance(name, str) for name in names):
        raise DeclarationError(spec_path, "REQ-0397", f"{field} names are text")
    _require_columns(table, names, f"{spec_path}.{field}", "REQ-0405")
    return names


def _row_count_failure(
    arguments: Mapping[str, JsonValue],
    table: TypedTable,
    rows: Sequence[Mapping[str, RuntimeValue]],
    predicate_rows: Sequence[Mapping[str, RuntimeValue]],
    predicate_types: Mapping[str, ColumnType],
    condition: str,
    requirement: str,
    context: dict[str, JsonValue],
    spec_path: str,
    severity: VerificationSeverity,
) -> tuple[VerificationFailure | None, int]:
    minimum = arguments.get("min")
    maximum = arguments.get("max")
    min_fraction = arguments.get("min_fraction")
    max_fraction = arguments.get("max_fraction")
    for bound in (minimum, maximum):
        if bound is not None and (
            isinstance(bound, bool) or not isinstance(bound, int)
        ):
            raise DeclarationError(spec_path, "REQ-0397", "a row_count bound is an int")
    for field, bound in (
        ("min_fraction", min_fraction),
        ("max_fraction", max_fraction),
    ):
        if bound is not None and (
            isinstance(bound, bool)
            or not isinstance(bound, (int, float))
            or not 0 <= bound <= 1
        ):
            raise DeclarationError(
                f"{spec_path}.{field}",
                "REQ-0397",
                "a row_count fraction is between 0 and 1",
            )
    if all(bound is None for bound in (minimum, maximum, min_fraction, max_fraction)):
        raise DeclarationError(spec_path, "REQ-0399", "row_count requires one bound")
    if minimum is not None and maximum is not None and minimum > maximum:
        raise DeclarationError(spec_path, "REQ-0399", "row_count min exceeds max")
    if (
        min_fraction is not None
        and max_fraction is not None
        and min_fraction > max_fraction
    ):
        raise DeclarationError(
            spec_path, "REQ-0399", "row_count min_fraction exceeds max_fraction"
        )

    grouped = arguments.get("group_by") is not None
    if grouped:
        names = _column_list(arguments, "group_by", table, spec_path)
        if len(set(names)) != len(names):
            raise DeclarationError(
                spec_path, "REQ-0403", "row_count group_by repeats a column"
            )
        partitions = _groups([tuple(row[name] for name in names) for row in rows])
    else:
        names = []
        # REQ-0385 bounds the whole output, so the ungrouped count exists even
        # when no row does: an empty artifact must still meet a `min`.
        partitions = {(): list(range(len(rows)))}

    admitted = set(range(len(rows)))
    if arguments.get("filter") is not None:
        filter_path = f"{spec_path}.filter"
        predicate = _predicate(
            arguments["filter"], filter_path, "REQ-0397", predicate_types
        )
        admitted = {
            index
            for index, row in enumerate(predicate_rows)
            if _truth(predicate, row, filter_path) is TruthValue.TRUE
        }

    bound_groups = set(range(len(rows)))
    if arguments.get("when") is not None:
        when_path = f"{spec_path}.when"
        predicate = _predicate(
            arguments["when"], when_path, "REQ-0397", predicate_types
        )
        bound_groups = {
            index
            for index, row in enumerate(predicate_rows)
            if _truth(predicate, row, when_path) is TruthValue.TRUE
        }

    # REQ-0386 partitions the artifact rather than the counted rows, so a
    # group whose filter admits nothing still exists and still fails a `min`.
    offending: list[tuple[KeyMap, int, int]] = []
    for combined, positions in partitions.items():
        if arguments.get("when") is not None and not any(
            position in bound_groups for position in positions
        ):
            continue
        count = sum(1 for position in positions if position in admitted)
        denominator = len(positions)
        fraction = count / denominator if denominator else 0.0
        if (
            (minimum is not None and count < minimum)
            or (maximum is not None and count > maximum)
            or (min_fraction is not None and fraction < min_fraction)
            or (max_fraction is not None and fraction > max_fraction)
        ):
            offending.append(
                (
                    {name: combined[order] for order, name in enumerate(names)},
                    count,
                    denominator,
                )
            )
    if not offending:
        return None, len(partitions)
    shown = offending[:REPORTED_KEYS]
    counts: dict[str, JsonValue]
    if len(offending) == 1:
        counts = {"count": offending[0][1]}
        log_counts = counts
    else:
        # Each count is aligned to the group at the same position in `keys`.
        # Keeping only the first count would make every later group ambiguous.
        counts = {"counts": [count for _, count, _ in shown]}
        log_counts = {"counts": [count for _, count, _ in offending]}
    if min_fraction is not None or max_fraction is not None:
        if len(offending) == 1:
            counts = {**counts, "denominator": offending[0][2]}
            log_counts = counts
        else:
            counts = {**counts, "denominators": [total for _, _, total in shown]}
            log_counts = {
                **log_counts,
                "denominators": [total for _, _, total in offending],
            }
    return (
        _failure(
            condition,
            spec_path,
            requirement,
            context,
            [group for group, _, _ in offending],
            extra=counts,
            log_extra=log_counts,
            severity=severity,
        ),
        len(partitions),
    )


def verify_completed_table(
    table: TypedTable,
    columns: Sequence[Column],
    keys: Sequence[str],
    verifications: Sequence[Expression] = (),
    *,
    lookup_columns: Sequence[TypedColumn] = (),
    lookup_rows: Sequence[Mapping[str, object]] | None = None,
    records: list[VerificationRecord] | None = None,
) -> TypedTable:
    """Run every stage in R005 order and raise at the first that fails.

    Column verifications run first, then output-key validation, then the
    dataset verifications R009 runs last. A stage that fails stops the run
    with every failure it found, because a later stage asserts over values
    an earlier one has already refused. When ``records`` is given, one
    :class:`VerificationRecord` is appended per evaluated check, held or
    violated, in execution order (REQ-1173).
    """
    failures = [
        failure
        for column in columns
        for failure in check_column(table, column, keys, records=records)
    ]
    errors = [failure for failure in failures if failure.severity == "error"]
    if errors:
        raise VerificationError(errors)

    failures = list(check_keys(table, keys))
    errors = [failure for failure in failures if failure.severity == "error"]
    if errors:
        raise VerificationError(errors)

    failures = list(
        check_dataset(
            table,
            verifications,
            keys,
            lookup_columns=lookup_columns,
            lookup_rows=lookup_rows,
            records=records,
        )
    )
    errors = [failure for failure in failures if failure.severity == "error"]
    if errors:
        raise VerificationError(errors)
    return table
