"""Run one committed example through the engine and report what it observed.

#101 owns the conformance runner's invocation, report, and comparison
protocol, and #200 owns the R engine. This module owns the Python side of
that boundary: it runs an example through the same engine `yamaa_domain`
exposes, records what the run actually produced, and separately compares
those observations with the artifacts the example committed.

The two halves stay apart on purpose. `execute_example` opens a
specification, the sources it declares, and nothing else, so a run cannot
answer with the value it was supposed to produce. `compare_example` is the
only half that reads `expected/`, and it reads a finished report rather
than a live engine.

Reports identify host language separately from engine backend. Version 0.3 adds
study resource capture traces, including failed and cached captures, to the
existing source/prepublication tables, checks, workflow and callback observations.
Older report envelopes must be regenerated explicitly.
"""

from __future__ import annotations

import argparse
import datetime
import itertools
import json
import platform
import sys
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Literal, TypeAlias

import polars as pl
from pydantic import BaseModel, ConfigDict, Field, JsonValue

from yamaa import __version__
from yamaa.adapters.observations import (
    CallbackObservation,
    ObservedResources,
    RunObservations,
    SourceReadObservation,
    TableObservation,
    VerificationObservation,
)
from yamaa.application import prepare_workflow
from yamaa.io import (
    Artifact,
    ArtifactTarget,
    publish_artifact,
    render_artifact,
)
from yamaa.io.parquet import parse_parquet
from yamaa.planning import ExecutionDiagnostic, execute_workflow
from yamaa.runtime import (
    ExecutionFailure,
    ExecutionSuccess,
    ExecutionUnsupported,
)
from yamaa.specification import SpecificationError, ValidationDiagnostic
from yamaa.specification._yaml import read_yaml_document
from yamaa.specification.models import Output

# The envelope changed incompatibly: old reports cannot imply empty new observations.
REPORT_VERSION = "0.3.0-draft"

RUNTIME: Literal["python"] = "python"
BACKEND: Literal["python"] = "python"

Outcome: TypeAlias = Literal["success", "failure", "unsupported", "error"]

SPEC_NAME = "spec.yaml"
EXPECTED_DIR = "expected"
ERROR_CONTRACT = "error.yaml"


class _FrozenModel(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid", frozen=True)


class ArtifactObservation(_FrozenModel):
    """One published artifact exactly as the run rendered it."""

    name: str = Field(min_length=1)
    profile: Literal["csv", "parquet"]
    columns: tuple[str, ...]
    types: tuple[str, ...]
    row_count: int = Field(ge=0)
    # The CSV profile contract's complete bytes split on the U+000A terminator
    # REQ-0723 writes. A missing value and a quoted empty string render
    # differently and are kept apart here; `content` below decides equality
    # so that a newline inside a quoted field cannot make this split the
    # deciding view. A parquet artifact carries one JSON document per
    # record instead: REQ-0742 denies parquet a byte guarantee, so its
    # comparison runs over what the bytes read back as (REQ-0740), and JSON
    # keeps a missing value null rather than the empty string.
    records: tuple[str, ...]
    byte_length: int = Field(ge=0)
    # The rendered text of a CSV artifact, which is what a comparison
    # decides on: carrying it is what lets equality be the bytes themselves
    # rather than two identities that are only believed to stand for them.
    # A parquet artifact carries the empty string: its comparison is the
    # logical one `records` above encodes, never the bytes.
    content: str = ""


class DiagnosticObservation(_FrozenModel):
    """One structured failure in the shape the committed contracts use."""

    phase: str = Field(min_length=1)
    condition: str = Field(min_length=1)
    spec_paths: tuple[str, ...] = Field(min_length=1)
    requirement: str | None
    context: dict[str, JsonValue]


class UnsupportedObservation(_FrozenModel):
    """One valid declaration this engine does not execute yet."""

    operation: str = Field(min_length=1)
    spec_path: str = Field(min_length=1)


class HandlerObservation(_FrozenModel):
    """How often one declared handler path fired, zero included (REQ-0361)."""

    spec_path: str = Field(min_length=1)
    handler: str = Field(min_length=1)
    count: int = Field(ge=0)


class NodeObservation(_FrozenModel):
    specification: str
    outcome: Literal["success", "failure", "unsupported"]
    diagnostics: tuple[DiagnosticObservation, ...] = ()
    unsupported: tuple[UnsupportedObservation, ...] = ()
    handler_counts: tuple[HandlerObservation, ...] = ()


class ExampleReport(_FrozenModel):
    """What one runtime observed running one example, and nothing more."""

    report_version: Literal["0.3.0-draft"] = REPORT_VERSION
    runtime: Literal["python", "r"] = RUNTIME
    backend: Literal["python", "rust"] = BACKEND
    runtime_version: str
    engine_version: str
    example: str = Field(min_length=1)
    outcome: Outcome
    artifacts: tuple[ArtifactObservation, ...] = ()
    diagnostics: tuple[DiagnosticObservation, ...] = ()
    unsupported: tuple[UnsupportedObservation, ...] = ()
    handler_counts: tuple[HandlerObservation, ...] = ()
    nodes: tuple[NodeObservation, ...]
    tables: tuple[TableObservation, ...]
    verifications: tuple[VerificationObservation, ...]
    callbacks: tuple[CallbackObservation, ...]
    source_reads: tuple[SourceReadObservation, ...]
    # Held for whoever reads a broken run. #101 keeps implementation error
    # text out of the portable comparison, so `compare_example` reads the
    # `error` outcome and never this string.
    error: str | None = None


class ComparisonFinding(_FrozenModel):
    """One difference between what an example committed and what ran."""

    kind: str = Field(min_length=1)
    detail: str = Field(min_length=1)
    expected: JsonValue = None
    actual: JsonValue = None


class ComparisonVerdict(_FrozenModel):
    """Whether one report satisfies the artifacts its example committed."""

    example: str = Field(min_length=1)
    runtime: Literal["python", "r"] = RUNTIME
    backend: Literal["python", "rust"] = BACKEND
    kind: Literal["positive", "negative", "parity"]
    passed: bool
    findings: tuple[ComparisonFinding, ...] = ()


class ConformanceError(ValueError):
    """Raised when an example or its output location cannot be used."""


def _records(payload: bytes) -> tuple[str, ...]:
    """Split R020's bytes on the U+000A terminator it writes after each."""
    text = payload.decode("utf-8")
    text = text.removesuffix("\n")
    return tuple(text.split("\n")) if text else ()


def _parquet_records(frame: pl.DataFrame) -> tuple[str, ...]:
    """Render one parquet artifact's logical content as canonical records.

    REQ-0742 denies parquet a byte guarantee, so the comparison REQ-0740
    requires runs over what the bytes read back as: the same field names in
    the same order, the same logical types, the same rows in the same order,
    the same nulls, and the same values. One JSON document per record keeps
    every value distinct from its text rendering: a missing value is null
    rather than the empty string, and a float renders through repr, the
    shortest text its bits round-trip through, so bit-identical DOUBLEs
    compare equal and only then. The logical types ride alongside rather
    than inside the records, compared field for field.
    """

    def canonical(value: object) -> JsonValue:
        if value is None:
            return None
        if isinstance(value, float):
            # json.dumps renders floats with repr: shortest round-trip text.
            return value
        if isinstance(value, (datetime.date, datetime.datetime, datetime.time)):
            return value.isoformat()
        if isinstance(value, (bytes, bytearray)):
            return bytes(value).hex()
        if isinstance(value, (str, int, bool)):
            return value
        return str(value)

    header = json.dumps(list(frame.columns), ensure_ascii=True)
    rows = (
        json.dumps([canonical(value) for value in row], ensure_ascii=True)
        for row in frame.iter_rows(named=False)
    )
    return (header, *rows)


def _sorted_context(context: Mapping[str, JsonValue]) -> dict[str, JsonValue]:
    """Order context keys so one run's report is byte-identical to the next."""
    return {key: context[key] for key in sorted(context)}


def _observe_artifact(
    name: str, artifact: Artifact, target: Path
) -> ArtifactObservation:
    """Publish one artifact to a permitted target and record what it became."""
    payload = render_artifact(artifact)
    publish_artifact(ArtifactTarget(target), artifact)
    return ArtifactObservation(
        name=name,
        profile=artifact.profile,
        columns=tuple(column.name for column in artifact.columns),
        types=tuple(column.type for column in artifact.columns),
        row_count=artifact.frame.height,
        records=(
            _records(payload)
            if artifact.profile == "csv"
            else _parquet_records(artifact.frame)
        ),
        byte_length=len(payload),
        content=payload.decode("utf-8") if artifact.profile == "csv" else "",
    )


def _observe_diagnostic(
    diagnostic: ValidationDiagnostic | ExecutionDiagnostic,
) -> DiagnosticObservation:
    return DiagnosticObservation(
        phase=diagnostic.phase,
        condition=diagnostic.condition,
        spec_paths=tuple(diagnostic.spec_paths),
        requirement=diagnostic.requirement,
        context=_sorted_context(diagnostic.context),
    )


def _isolated_destination(output_dir: Path, example: Path) -> Path:
    """Refuse an output location inside the example it would overwrite."""
    destination = output_dir.resolve()
    if destination == example or example in destination.parents:
        raise ConformanceError(
            "a conformance run writes outside the example directory; "
            f"{destination} sits inside {example}"
        )
    return destination


def _report(name: str, outcome: Outcome, **observations: object) -> ExampleReport:
    complete = {
        "nodes": (),
        "tables": (),
        "verifications": (),
        "callbacks": (),
        "source_reads": (),
        **observations,
    }
    return ExampleReport(
        runtime_version=platform.python_version(),
        engine_version=complete.pop("engine_version", __version__),
        example=name,
        outcome=outcome,
        **complete,
    )


def _named_specifications(document: object) -> set[str]:
    """Return the file names one specification names as a parent or producer."""
    if not isinstance(document, dict):
        return set()
    parents = document.get("parents", ())
    if isinstance(parents, str):
        parents = (parents,)
    named = {
        Path(parent).name for parent in parents if isinstance(parent, str) and parent
    }
    inputs = document.get("input", {})
    if isinstance(inputs, dict):
        named.update(
            Path(source["schema"]).name
            for source in inputs.values()
            if isinstance(source, dict)
            and isinstance(source.get("schema"), str)
            and source["schema"]
        )
    return named


def entry_specification(example: Path) -> Path:
    """Return the specification an example is entered through.

    A benchmark states one specification as `spec.yaml`. One that keeps
    several side by side names none of them that: inheritance levels, or a
    producer whose artifact another reads through `schema`. The one no other
    names as a parent or a producer is the entry.
    """
    single = example / SPEC_NAME
    if single.is_file():
        return single
    levels = sorted(example.glob("spec_*.yaml"))
    named: set[str] = set()
    for path in levels:
        named.update(_named_specifications(read_yaml_document(path)))
    entries = [path for path in levels if path.name not in named]
    if len(entries) != 1:
        raise ConformanceError(f"example has no single entry specification: {example}")
    return entries[0]


def _execute(
    name: str,
    entry: Path,
    schema_root: Path,
    destination: Path,
    observer: RunObservations | None = None,
) -> ExampleReport:
    try:
        prepared = prepare_workflow(entry, schema_root=schema_root)
        workflow, resources = prepared.workflow, prepared.resources
    except SpecificationError as error:
        # Validation fails before any source is read, so there is no handler
        # activity to report alongside it.
        return _report(
            name,
            "failure",
            diagnostics=tuple(_observe_diagnostic(item) for item in error.diagnostics),
        )

    observer = observer or RunObservations(entry)
    execution = execute_workflow(
        workflow,
        ObservedResources(resources, observer, entry.parent),
        dispatcher=None,
        hooks=observer.hooks(),
        event=observer.event,
    )
    observations = {
        "nodes": tuple(
            NodeObservation(
                specification=observer.specification_name(path),
                outcome=node_result.status,
                diagnostics=tuple(
                    _observe_diagnostic(item)
                    for item in getattr(node_result, "diagnostics", ())
                ),
                unsupported=tuple(
                    UnsupportedObservation(
                        operation=item.operation, spec_path=item.spec_path
                    )
                    for item in getattr(node_result, "features", ())
                ),
                handler_counts=tuple(
                    HandlerObservation(
                        spec_path=item.spec_path, handler=item.handler, count=item.count
                    )
                    for item in node_result.handler_counts
                ),
            )
            for path, node_result in execution.results.items()
        ),
        "tables": observer.tables(execution),
        "verifications": tuple(observer.verifications),
        "callbacks": tuple(observer.callbacks),
        "source_reads": tuple(observer.source_reads),
    }
    result = execution.result
    handler_counts = tuple(
        HandlerObservation(
            spec_path=count.spec_path,
            handler=count.handler,
            count=count.count,
        )
        for count in result.handler_counts
    )

    entry_node = next(
        node for node in workflow.nodes if node.entry_path == workflow.entry_path
    )
    output = entry_node.resolved.specification.output

    if isinstance(result, ExecutionFailure):
        # A producer may fail before the entry runs; its declaration owns the log.
        failed_path = next(
            path for path, item in execution.results.items() if item is result
        )
        output = next(
            node.resolved.specification.output
            for node in workflow.nodes
            if node.entry_path == failed_path
        )
        # REQ-1181: a failed run publishes no primary artifact and no
        # warning log, and replaces the verification log alone when the
        # run declared one and reached execution.
        failed: list[ArtifactObservation] = []
        if result.verification_log is not None and output.verification_log is not None:
            failed.append(
                _observe_artifact(
                    Path(output.verification_log).stem,
                    result.verification_log,
                    destination / Path(output.verification_log).name,
                )
            )
        return _report(
            name,
            "failure",
            diagnostics=tuple(_observe_diagnostic(item) for item in result.diagnostics),
            artifacts=tuple(failed),
            handler_counts=handler_counts,
            **observations,
        )
    if isinstance(result, ExecutionUnsupported):
        return _report(
            name,
            "unsupported",
            unsupported=tuple(
                UnsupportedObservation(
                    operation=feature.operation,
                    spec_path=feature.spec_path,
                )
                for feature in result.features
            ),
            handler_counts=handler_counts,
            **observations,
        )

    assert isinstance(result, ExecutionSuccess)
    published: list[ArtifactObservation] = []
    for node in workflow.nodes:
        # A producer kept beside the entry is part of the example, so its
        # artifact is published and compared like the entry's. A producer
        # under `input/` records where an input came from and stays an input.
        produced = execution.results.get(node.entry_path)
        if (
            node is not entry_node
            and node.entry_path.parent == workflow.entry_path.parent
            and isinstance(produced, ExecutionSuccess)
        ):
            published.extend(
                _published(node.resolved.specification.output, produced, destination)
            )
    published.extend(_published(output, result, destination))
    return _report(
        name,
        "success",
        artifacts=tuple(published),
        handler_counts=handler_counts,
        **observations,
    )


def _published(
    output: Output, result: ExecutionSuccess, destination: Path
) -> list[ArtifactObservation]:
    """Publish one successful specification's artifacts in REQ-1181 order."""
    published = []
    if result.verification_log is not None and output.verification_log is not None:
        # REQ-1181: a run declaring the verification log publishes it first.
        published.append(
            _observe_artifact(
                Path(output.verification_log).stem,
                result.verification_log,
                destination / Path(output.verification_log).name,
            )
        )
    if result.warning_log is not None and output.warning_log is not None:
        # REQ-0757: the warning log is published before the primary artifact.
        published.append(
            _observe_artifact(
                Path(output.warning_log).stem,
                result.warning_log,
                destination / Path(output.warning_log).name,
            )
        )
    published.append(
        _observe_artifact(
            Path(output.path).stem,
            result.artifact,
            destination / Path(output.path).name,
        )
    )
    return published


def execute_example(
    example: str | Path,
    *,
    schema_root: str | Path,
    output_dir: str | Path,
    backend: Literal["python", "rust"] = "python",
) -> ExampleReport:
    """Run one example and report what the engine observed doing it.

    Only the specification and the sources it declares are opened. No
    `expected/` artifact is read here, so a report states what the engine
    produced rather than what it was supposed to produce; `compare_example`
    is the half that knows the committed answer.

    Artifacts are published under `output_dir`, which must sit outside the
    example, so a run cannot overwrite the fixture it is being judged
    against.
    """
    if backend not in {"python", "rust"}:
        raise ConformanceError("backend must be python or rust")
    example_path = Path(example).resolve()
    entry = entry_specification(example_path)

    destination = _isolated_destination(Path(output_dir), example_path)
    destination.mkdir(parents=True, exist_ok=True)
    observer = RunObservations(entry)
    try:
        if backend == "rust":
            from yamaa.adapters.native_conformance import execute_native_example

            return execute_native_example(
                example_path.name, entry, Path(schema_root).resolve(), destination
            )
        return _execute(
            example_path.name,
            entry,
            Path(schema_root).resolve(),
            destination,
            observer=observer,
        )
    except ConformanceError:
        raise
    except Exception as failure:  # noqa: BLE001 - an engine crash is a result
        # An infrastructure failure is visible rather than silent, and it is
        # never a semantic failure: `compare_example` fails every example
        # that lands here. The text is for a human; nothing compares it.
        return _report(
            example_path.name,
            "error",
            backend=backend,
            engine_version=__version__ if backend == "python" else "unavailable",
            callbacks=tuple(observer.callbacks),
            verifications=tuple(observer.verifications),
            source_reads=tuple(observer.source_reads),
            error=f"{type(failure).__name__}: {failure}",
        )


def _finding(
    kind: str, detail: str, expected: object, actual: object
) -> ComparisonFinding:
    return ComparisonFinding(
        kind=kind,
        detail=detail,
        expected=expected,  # type: ignore[arg-type]
        actual=actual,  # type: ignore[arg-type]
    )


def expected_kind(example: str | Path) -> Literal["positive", "negative"]:
    """Say which committed artifact an example is judged against."""
    contract = Path(example) / EXPECTED_DIR / ERROR_CONTRACT
    return "negative" if contract.is_file() else "positive"


def _record_findings(
    observation: ArtifactObservation,
    committed: tuple[str, ...],
) -> list[ComparisonFinding]:
    """Say where one artifact's records first differ from the committed ones."""
    produced = observation.records
    findings: list[ComparisonFinding] = []
    if committed and produced and committed[0] != produced[0]:
        findings.append(
            _finding(
                "artifact.columns",
                f"{observation.name}: header record differs",
                committed[0],
                produced[0],
            )
        )
    if len(committed) != len(produced):
        findings.append(
            _finding(
                "artifact.row_count",
                f"{observation.name}: record count differs",
                max(len(committed) - 1, 0),
                max(len(produced) - 1, 0),
            )
        )
    for index, (want, got) in enumerate(zip(committed[1:], produced[1:]), start=1):
        if want != got:
            findings.append(
                _finding(
                    "artifact.record",
                    f"{observation.name}: record {index} differs",
                    want,
                    got,
                )
            )
    return findings


def _artifact_findings(
    observation: ArtifactObservation,
    payload: bytes,
) -> tuple[ComparisonFinding, ...]:
    """Compare one artifact, then say where it first differs.

    A CSV artifact compares byte for byte under the csv profile's byte
    guarantee; when the records agree but the bytes do not, the bytes decide.
    A parquet artifact has no byte guarantee (REQ-0742), so its comparison is
    the logical one REQ-0740 requires: the committed bytes are read back
    through the closed parquet profile and compared on field names in order,
    logical types, row order, nulls, and values, never as bytes.
    """
    if observation.profile == "parquet":
        typed = parse_parquet(payload)
        findings: list[ComparisonFinding] = []
        committed_types = tuple(column.type for column in typed.columns)
        if committed_types != observation.types:
            findings.append(
                _finding(
                    "artifact.types",
                    f"{observation.name}: logical types differ",
                    list(committed_types),
                    list(observation.types),
                )
            )
        findings.extend(_record_findings(observation, _parquet_records(typed.frame)))
        return tuple(findings)
    if observation.content.encode("utf-8") == payload:
        return ()

    findings = _record_findings(observation, _records(payload))
    if not findings:
        # The records agree yet the bytes do not: a terminator, an encoding,
        # or a newline inside a quoted field. The bytes decide.
        findings.append(
            _finding(
                "artifact.bytes",
                f"{observation.name}: rendered bytes differ",
                len(payload),
                observation.byte_length,
            )
        )
    return tuple(findings)


def _positive_findings(
    report: ExampleReport,
    example: Path,
) -> tuple[ComparisonFinding, ...]:
    if report.outcome != "success":
        return (
            _finding(
                "outcome",
                f"{report.example}: a positive example must execute",
                "success",
                report.outcome,
            ),
        )

    committed = {
        path.stem: path
        for path in sorted(
            itertools.chain(
                (example / EXPECTED_DIR).glob("*.csv"),
                (example / EXPECTED_DIR).glob("*.parquet"),
            )
        )
    }
    produced = {item.name: item for item in report.artifacts}
    findings: list[ComparisonFinding] = []
    for name in sorted(set(committed) | set(produced)):
        if name not in produced:
            findings.append(
                _finding("artifact.missing", f"{name}: not produced", name, None)
            )
        elif name not in committed:
            findings.append(
                _finding("artifact.unexpected", f"{name}: not committed", None, name)
            )
        else:
            findings.extend(
                _artifact_findings(produced[name], committed[name].read_bytes())
            )
    return tuple(findings)


def _negative_findings(
    report: ExampleReport,
    example: Path,
) -> tuple[ComparisonFinding, ...]:
    contract = read_yaml_document(example / EXPECTED_DIR / ERROR_CONTRACT)
    if not isinstance(contract, dict):
        raise ConformanceError(f"{example.name}: {ERROR_CONTRACT} is not a mapping")

    # Unsupported execution and an engine crash are not the semantic failure
    # a negative example commits, so neither one passes here.
    if report.outcome != "failure":
        return (
            _finding(
                "outcome",
                f"{report.example}: a negative example must fail semantically",
                "failure",
                report.outcome,
            ),
        )

    observed = report.diagnostics[0]
    findings: list[ComparisonFinding] = []
    for field in ("phase", "condition"):
        want = contract[field]
        got = getattr(observed, field)
        if want != got:
            findings.append(
                _finding(f"diagnostic.{field}", f"{report.example}: {field}", want, got)
            )

    paths = tuple(contract["spec_paths"])
    if paths != observed.spec_paths:
        findings.append(
            _finding(
                "diagnostic.spec_paths",
                f"{report.example}: spec_paths",
                list(paths),
                list(observed.spec_paths),
            )
        )

    if "requirement" in contract and contract["requirement"] != observed.requirement:
        findings.append(
            _finding(
                "diagnostic.requirement",
                f"{report.example}: requirement",
                contract["requirement"],
                observed.requirement,
            )
        )

    # The contract states the context a portable failure must carry. A
    # runtime may observe more; it may not observe a different value.
    for key in sorted(contract.get("context") or {}):
        want = contract["context"][key]
        if key not in observed.context:
            findings.append(
                _finding(
                    "diagnostic.context",
                    f"{report.example}: context.{key} absent",
                    want,
                    None,
                )
            )
        elif observed.context[key] != want:
            findings.append(
                _finding(
                    "diagnostic.context",
                    f"{report.example}: context.{key}",
                    want,
                    observed.context[key],
                )
            )
    return tuple(findings)


def _handler_findings(
    report: ExampleReport,
    expected: Sequence[HandlerObservation],
) -> tuple[ComparisonFinding, ...]:
    produced = {
        (item.spec_path, item.handler): item.count for item in report.handler_counts
    }
    committed = {(item.spec_path, item.handler): item.count for item in expected}
    findings: list[ComparisonFinding] = []
    for path, handler in sorted(set(committed) | set(produced)):
        key = (path, handler)
        detail = f"{report.example}: {path} {handler}"
        if key not in produced:
            findings.append(
                _finding(
                    "handler.missing", f"{detail} not reported", committed[key], None
                )
            )
        elif key not in committed:
            findings.append(
                _finding(
                    "handler.unexpected", f"{detail} not committed", None, produced[key]
                )
            )
        elif committed[key] != produced[key]:
            findings.append(
                _finding("handler.count", detail, committed[key], produced[key])
            )
    return tuple(findings)


def compare_example(
    report: ExampleReport,
    example: str | Path,
    *,
    expected_handler_counts: Sequence[HandlerObservation] | None = None,
) -> ComparisonVerdict:
    """Judge one finished report against the artifacts its example committed.

    This is the only half that reads `expected/`, and it reads a report
    rather than an engine. Nothing here normalizes: column order, record
    order, a missing value, and a quoted empty string are compared as
    rendered, and the artifact verdict is the complete bytes.

    REQ-0361 requires a run to report every declared handler path. The counts
    themselves become a comparison only when a caller states them, because
    no example commits them yet; #101's cross-runtime comparator is where R
    and Python counts meet.
    """
    example_path = Path(example).resolve()
    kind = expected_kind(example_path)
    findings = (
        _negative_findings(report, example_path)
        if kind == "negative"
        else _positive_findings(report, example_path)
    )
    if expected_handler_counts is not None:
        findings = findings + _handler_findings(report, expected_handler_counts)
    return ComparisonVerdict(
        example=report.example,
        runtime=report.runtime,
        backend=report.backend,
        kind=kind,
        passed=not findings,
        findings=findings,
    )


def _portable_report(report: ExampleReport) -> dict[str, JsonValue]:
    payload = report.model_dump(
        mode="json",
        exclude={
            "report_version",
            "runtime",
            "runtime_version",
            "backend",
            "engine_version",
            "error",
        },
    )
    for artifact in payload["artifacts"]:
        if artifact["profile"] == "parquet":
            artifact.pop("byte_length")
    # Host-language exception spelling is not part of a portable condition.
    diagnostics = list(payload["diagnostics"])
    diagnostics.extend(
        item for node in payload["nodes"] for item in node["diagnostics"]
    )
    for diagnostic in diagnostics:
        if diagnostic["condition"] == "function_call_failed":
            for key in ("call", "host_error", "host_message"):
                diagnostic["context"].pop(key, None)
    return payload


def compare_reports(
    reference: ExampleReport, candidate: ExampleReport
) -> ComparisonVerdict:
    """Compare independent runs without changing goldens or invoking either engine.

    Unsupported and infrastructure-error outcomes never establish parity. Float
    observations are exact IEEE-754 encodings; no tolerance hides differences.
    Version validation is repeated because model_copy can bypass model validation.
    """
    reference = ExampleReport.model_validate_json(reference.model_dump_json())
    candidate = ExampleReport.model_validate_json(candidate.model_dump_json())
    findings = []
    for label, report in (("reference", reference), ("candidate", candidate)):
        if report.outcome in ("unsupported", "error"):
            findings.append(
                _finding("outcome", label, "success or failure", report.outcome)
            )

    def compare(path, expected, actual):
        if type(expected) is not type(actual):
            findings.append(_finding(path, "different types", expected, actual))
        elif isinstance(expected, dict):
            for key in sorted(expected.keys() | actual.keys()):
                if key not in expected or key not in actual:
                    findings.append(
                        _finding(
                            path + "." + key,
                            "missing field",
                            expected.get(key),
                            actual.get(key),
                        )
                    )
                else:
                    compare(path + "." + key, expected[key], actual[key])
        elif isinstance(expected, list):
            if len(expected) != len(actual):
                findings.append(
                    _finding(
                        path + ".count", "different lengths", len(expected), len(actual)
                    )
                )
            for index, (left, right) in enumerate(zip(expected, actual)):
                compare(f"{path}[{index}]", left, right)
        elif expected != actual:
            findings.append(_finding(path, "different values", expected, actual))

    compare("report", _portable_report(reference), _portable_report(candidate))
    return ComparisonVerdict(
        example=candidate.example,
        runtime=candidate.runtime,
        backend=candidate.backend,
        kind="parity",
        passed=not findings,
        findings=tuple(findings),
    )


def read_report(path: str | Path) -> ExampleReport:
    """Read this exact protocol version; never silently upgrade older observations."""
    return ExampleReport.model_validate_json(Path(path).read_text(encoding="utf-8"))


def write_report(report: ExampleReport, report_dir: Path) -> Path:
    """Write one report where a runner collects it, deterministically."""
    report_dir.mkdir(parents=True, exist_ok=True)
    path = report_dir / f"{report.example}.{report.runtime}.{report.backend}.json"
    payload = json.dumps(report.model_dump(mode="json"), indent=2)
    path.write_text(f"{payload}\n", encoding="utf-8")
    return path


def _describe(verdict: ComparisonVerdict | None) -> str:
    if verdict is None:
        return "reported"
    return "pass" if verdict.passed else "FAIL"


def main(argv: Sequence[str] | None = None) -> int:
    """Execute the named examples, write a report each, and judge them."""
    parser = argparse.ArgumentParser(
        prog="python -m yamaa.adapters.conformance",
        description=(
            "Execute committed examples through the Python engine, write one "
            "report each, and compare them with the committed artifacts."
        ),
    )
    parser.add_argument("examples", nargs="+", help="example directory names")
    parser.add_argument("--backend", choices=("python", "rust"), default="python")
    parser.add_argument(
        "--run-dir",
        required=True,
        type=Path,
        help="where artifacts and reports are written; outside the examples",
    )
    parser.add_argument(
        "--examples-root",
        type=Path,
        default=Path("benchmarks"),
        help="directory holding the committed examples",
    )
    parser.add_argument(
        "--schema-root",
        type=Path,
        default=None,
        help=(
            "directory holding schema.yaml; defaults to the bundle beside "
            "the examples root"
        ),
    )
    parser.add_argument(
        "--reference-reports",
        type=Path,
        help="also compare with exactly one same-example report per example in this directory",
    )
    parser.add_argument(
        "--no-compare",
        action="store_true",
        help="write reports without judging them against expected/",
    )
    args = parser.parse_args(argv)

    examples_root = args.examples_root.resolve()
    # The examples and the schema they are written against come from one
    # checkout, so an unnamed schema root follows the examples root rather
    # than the working directory a runner happened to start in.
    schema_root = (
        examples_root.parent / "yaml"
        if args.schema_root is None
        else args.schema_root.resolve()
    )
    report_dir = args.run_dir / "reports"
    if (
        args.reference_reports is not None
        and args.reference_reports.resolve() == report_dir.resolve()
    ):
        parser.error("reference reports must be separate from this run's reports")
    failed = False

    for name in args.examples:
        example = examples_root / name
        report = execute_example(
            example,
            schema_root=schema_root,
            output_dir=args.run_dir / "artifacts" / name,
            backend=args.backend,
        )
        path = write_report(report, report_dir)
        verdict = None if args.no_compare else compare_example(report, example)
        if verdict is not None and not verdict.passed:
            failed = True
        if args.reference_reports is not None:
            references = sorted(args.reference_reports.glob(f"{name}.*.json"))
            if len(references) != 1:
                parser.error(
                    f"expected exactly one reference report for {name}, found {len(references)}"
                )
            parity = compare_reports(read_report(references[0]), report)
            if not parity.passed:
                failed = True
                print(f"{name}: backend comparison FAIL")
                for finding in parity.findings:
                    print(f"    {finding.kind}: {finding.detail}")
        if report.outcome == "error":
            failed = True
        print(f"{name}  {RUNTIME}  {report.outcome}  {_describe(verdict)}  {path}")
        if report.error is not None:
            print(f"    error: {report.error}")
        for finding in verdict.findings if verdict else ():
            print(f"    {finding.kind}: {finding.detail}")
            print(f"      committed: {finding.expected!r}")
            print(f"      produced:  {finding.actual!r}")

    return 1 if failed else 0


if __name__ == "__main__":  # pragma: no cover - module entry point
    sys.exit(main())
