"""R003 intermediates: select one record once, then read it many times.

An intermediate states its match once and gives the chosen record a name, so the
columns that read it are plainly reading one record. Everything about
reaching that record -- filtering, equality matching, range narrowing, and
ordered selection -- is one explicit declared-key mechanism, so a named
intermediate and an implicit join cannot disagree.
"""

from __future__ import annotations

import math
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from functools import partial
from typing import Literal, NamedTuple

from pydantic import JsonValue, ValidationError

from yamaa.expressions.core import (
    AbsentValue,
    CallableResolver,
    FailedResolution,
    MappingResolver,
    Resolution,
    ResolvedValue,
    Resolver,
    expression_condition,
    normalize_runtime_value,
)
from yamaa.expressions.dispatch import evaluate_expression
from yamaa.expressions.predicates import (
    PredicateAst,
    PredicateError,
    PredicateValue,
    TruthValue,
    evaluate_predicate,
    parse_predicate_cached,
    predicate_identifiers,
)
from yamaa.expressions.windows import (
    WINDOW_OPERATIONS,
    Partition,
    evaluate_window,
    window_spec,
)
from yamaa.models import (
    MISSING,
    ColumnType,
    ConditionResult,
    DateTimeValue,
    DateValue,
    EvaluationResult,
    HandlerName,
    RuntimeCondition,
    RuntimeValue,
    ValueResult,
    runtime_type_name,
)
from yamaa.planning import MatchValueExpression, PlannedIntermediate
from yamaa.runtime.joins import (
    ImplicitSelection,
    IndexedRecord,
    OrderError,
    PartitionKey,
    RelationIndex,
    compare_values,
    eligible_records,
    json_value,
    order_records,
    partition_key,
    partition_records,
    select_record,
)
from yamaa.specification.models import (
    Expression,
    HandledExpression,
    OrderTerm,
    key_pairs,
)
from yamaa.verification.diagnostics import VerificationFailure


@dataclass(frozen=True, slots=True)
class IntermediateOutcome:
    """What one current row got from an intermediate.

    A selected record and a decided absence stay distinct: REQ-0124 keeps a
    matched record whose value is missing different from a match that never
    happened, which answers with the declared `missing` literal instead.
    """

    record: IndexedRecord | None = None
    absent: JsonValue = None
    condition: ConditionResult | None = None
    spec_path: str | None = None
    handled_by: HandlerName | None = None


def _condition(
    condition: str,
    requirement: str,
    context: Mapping[str, JsonValue],
    *,
    phase: Literal["validation", "join"] = "join",
) -> ConditionResult:
    return ConditionResult(
        condition=RuntimeCondition(
            phase=phase,
            condition=condition,
            context=dict(context),
            requirement=requirement,
        )
    )


def types_comparable(left: ColumnType, right: ColumnType) -> bool:
    """Return whether two declared types may be compared without conversion.

    REQ-0121 lets `int` and `float` compare through the Numeric values contract's
    promotion and requires every other type to match exactly, so no operand is
    converted implicitly to make a range comparison work.
    """
    return left == right or {left, right} <= {"int", "float"}


class _DerivedRecordResolver:
    """Resolve derivation references against one intermediate record.

    REQ-1185 scopes every reference to the intermediate's own dataset: a bare
    name reads the record's stored field, and a qualified name must name the
    dataset. The planner rejects anything else before a record is read, so
    an absent name here is a defect, not a miss.
    """

    def __init__(self, dataset: str, values: Mapping[str, RuntimeValue]) -> None:
        self._dataset = dataset
        self._values = values

    def resolve(self, variable: str) -> Resolution:
        if "." in variable:
            qualifier, _, field = variable.partition(".")
            name = field if qualifier == self._dataset else None
        else:
            name = variable
        if name is None or name not in self._values:
            return AbsentValue(variable=variable)
        return ResolvedValue(value=self._values[name])


def _window_order_terms(declared: object) -> list[tuple[OrderTerm, str]]:
    """Bind each declared window order term to the readable name it sorts by.

    Mirrors rows._order_terms: the readable record view carries both the
    bare and the dataset-qualified spelling, so a term binds to the
    variable exactly as the window declared it.
    """
    if not isinstance(declared, Sequence) or isinstance(declared, str):
        return []
    terms: list[tuple[OrderTerm, str]] = []
    for entry in declared:
        if isinstance(entry, str):
            term = OrderTerm(variable=entry)
        elif isinstance(entry, Mapping):
            try:
                term = OrderTerm.model_validate(dict(entry), strict=True)
            except ValidationError:
                continue
        else:
            continue
        terms.append((term, term.variable))
    return terms


def _readable_window_record(
    dataset: str, values: Mapping[str, RuntimeValue]
) -> dict[str, RuntimeValue]:
    """Return every name one donor record answers to inside a window.

    REQ-1185 lets a window field read a stored field or an earlier derived
    name, bare or dataset-qualified, so the view carries both spellings of
    each value.
    """
    readable = dict(values)
    for name, value in values.items():
        readable[f"{dataset}.{name}"] = value
    return readable


_PreparedPartitions = tuple[
    dict[PartitionKey, tuple[IndexedRecord, ...]],
    dict[PartitionKey, tuple[bool, ...]],
    list[dict[str, RuntimeValue]],
]
"""One built window partition: grouped records, per-row eligibility, readable views."""


def _freeze(value: object) -> object:
    """Freeze a parsed payload into a hashable cache key.

    The payloads are parsed spec mappings (strings, numbers, booleans,
    None, lists, dicts); freezing compares the canonical form directly.
    """
    if isinstance(value, Mapping):
        return tuple(sorted((name, _freeze(item)) for name, item in value.items()))
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    return value


def _prepare_window_partitions(
    dataset: str,
    values_list: Sequence[Mapping[str, RuntimeValue]],
    window: Mapping[str, object],
    exclude: tuple[str, ...] = (),
) -> _PreparedPartitions | ConditionResult:
    """Partition the donor records once for a window derivation.

    Mirrors RowResolver._locate: group the readable records by the window's
    group_by, order each group by its order_by, and mark the rows its
    filter keeps eligible (REQ-0294). The records carry every derivation
    declared before the window; `exclude` strips the in-progress
    derivation's name so a nested window never sees a partially computed
    column.
    """
    excluded = frozenset(exclude)
    views = [
        _readable_window_record(
            dataset,
            {name: value for name, value in values.items() if name not in excluded},
        )
        for values in values_list
    ]
    fields = _names(window.get("group_by")) or ()
    if views:
        unavailable = [name for name in fields if name not in views[0]]
        if unavailable:
            return _condition(
                "unknown_field",
                "REQ-1185",
                {"identifier": unavailable[0]},
                phase="validation",
            )
    indexed = [
        IndexedRecord(position=index, values=view) for index, view in enumerate(views)
    ]
    grouped = partition_records(indexed, fields)
    terms = _window_order_terms(window.get("order_by"))
    ordered: dict[PartitionKey, tuple[IndexedRecord, ...]] = {}
    for key, members in grouped.items():
        if terms:
            try:
                members = tuple(order_records(members, terms))
            except OrderError as error:
                return _condition(
                    "incompatible_input_type",
                    "REQ-0324",
                    {"source": error.variable, "types": sorted(set(error.types))},
                    phase="validation",
                )
        ordered[key] = members
    eligibilities: dict[PartitionKey, tuple[bool, ...]] = {}
    for key, members in ordered.items():
        eligible = _window_eligibility(window, members)
        if isinstance(eligible, ConditionResult):
            return eligible
        eligibilities[key] = eligible
    return ordered, eligibilities, views


def _window_eligibility(
    window: Mapping[str, object], members: Sequence[IndexedRecord]
) -> tuple[bool, ...] | ConditionResult:
    """Say which partition rows the window's filter retained (REQ-0294)."""
    predicate_text = window.get("filter")
    if predicate_text is None:
        return tuple(True for _ in members)
    if not isinstance(predicate_text, str):
        return _condition(
            "invalid_predicate",
            "REQ-0188",
            {"predicate": predicate_text},
            phase="validation",
        )
    try:
        ast = parse_predicate_cached(predicate_text)
    except PredicateError as error:
        return _condition(
            "invalid_predicate",
            error.requirement,
            {"predicate": predicate_text, "position": error.position},
            phase="validation",
        )
    kept: list[bool] = []
    for member in members:
        result = evaluate_predicate(ast, MappingResolver(member.values))
        if isinstance(result, ConditionResult):
            return result
        assert isinstance(result, PredicateValue)
        kept.append(result.value is TruthValue.TRUE)
    return tuple(kept)


def _window_value_for(
    operation: str,
    payload: Mapping[str, object],
    window: Mapping[str, object],
    grouped: Mapping[PartitionKey, tuple[IndexedRecord, ...]],
    eligibilities: Mapping[PartitionKey, tuple[bool, ...]],
    views: Sequence[Mapping[str, RuntimeValue]],
    index: int,
) -> EvaluationResult:
    """Answer one window derivation for the record at `index`."""
    fields = _names(window.get("group_by")) or ()
    key = partition_key(views[index], fields)
    members = grouped.get(key)
    if members is None:
        return _condition(
            "unknown_field",
            "REQ-1185",
            {"identifier": "the current row is absent from its partition"},
            phase="validation",
        )
    current = next(
        (
            position
            for position, member in enumerate(members)
            if member.position == index
        ),
        None,
    )
    if current is None:
        return _condition(
            "unknown_field",
            "REQ-1185",
            {"identifier": "the current row is absent from its partition"},
            phase="validation",
        )
    partition = Partition(
        rows=tuple(member.values for member in members),
        current=current,
        eligible=eligibilities[key],
    )
    return evaluate_window(operation, payload, partition)


_IntermediateReader = Callable[[str, str, Resolver], Resolution | None]
"""Answer `<intermediate>.<field>` for one donor record, or `None` when the
qualifier names no declared intermediate (REQ-1263)."""


class _IntermediateDerivationResolver(_DerivedRecordResolver):
    """Resolve derivation references across the intermediate's donor records.

    Scalar reads answer from the current record's values. The window
    operations partition the donor records the way RowResolver._window
    partitions constructed rows: the records carry every derivation
    declared before the window, so a window field may read a stored field
    or an earlier derived name, bare or dataset-qualified. Any other
    relational operation keeps the historical `resolver unsupported`
    answer.

    A window operation nested in a scalar derivation reuses one prepared
    partition per window spec for the derivation's whole per-record loop:
    the readable records (stored fields plus earlier derived names) are
    identical for every record, so rebuilding per record is pure waste.
    `exclude` names the in-progress derivation, which the planner keeps
    out of its own scope. `read` answers a REQ-1263 read of another
    intermediate for this record. `current` carries only the qualified
    driver fields planned for the enclosing lookup (REQ-1185).
    """

    def __init__(
        self,
        dataset: str,
        values_list: list[dict[str, RuntimeValue]],
        index: int,
        partition_cache: dict[tuple[str, object], _PreparedPartitions] | None = None,
        exclude: str | None = None,
        read: _IntermediateReader | None = None,
        current: Mapping[str, RuntimeValue] | None = None,
    ) -> None:
        super().__init__(dataset, values_list[index])
        self._values_list = values_list
        self._index = index
        self._partition_cache = partition_cache
        self._exclude = (exclude,) if exclude is not None else ()
        self._read = read
        self._current = current or {}

    def resolve(self, variable: str) -> Resolution:
        qualifier, separator, field = variable.partition(".")
        if separator and qualifier != self._dataset and variable in self._current:
            return ResolvedValue(value=self._current[variable])
        if separator and qualifier != self._dataset and self._read is not None:
            # REQ-1263: a name qualified by another intermediate reads the
            # record that intermediate selects for this donor record.
            resolution = self._read(qualifier, field, self)
            if resolution is not None:
                return resolution
        return super().resolve(variable)

    def resolve_relation(
        self, operation: str, payload: Mapping[str, object]
    ) -> EvaluationResult:
        if operation not in WINDOW_OPERATIONS:
            return expression_condition(
                "validation",
                "invalid_field_type",
                {"operation": operation, "reason": "resolver unsupported"},
            )
        window = window_spec(payload)
        # Dispatch hands us a fresh dict copy per call, so the cache key
        # freezes the payload's canonical form instead of its identity.
        key = (operation, _freeze(payload))
        prepared = (
            self._partition_cache.get(key)
            if self._partition_cache is not None
            else None
        )
        if prepared is None:
            built = _prepare_window_partitions(
                self._dataset, self._values_list, window, exclude=self._exclude
            )
            if isinstance(built, ConditionResult):
                return built
            prepared = built
            if self._partition_cache is not None:
                self._partition_cache[key] = prepared
        grouped, eligibilities, views = prepared
        return _window_value_for(
            operation, payload, window, grouped, eligibilities, views, self._index
        )


class _LookupPredicateResolver(_DerivedRecordResolver):
    """Bind donor-qualified fields and explicitly planned driver references."""

    def __init__(
        self,
        dataset: str,
        values: Mapping[str, RuntimeValue],
        current: Mapping[str, RuntimeValue],
    ) -> None:
        super().__init__(dataset, values)
        self._current = current

    def resolve(self, variable: str) -> Resolution:
        if variable.split(".", 1)[0] == self._dataset or (
            self._dataset == "SELF" and "." not in variable
        ):
            return super().resolve(variable)
        if variable in self._current:
            return ResolvedValue(value=self._current[variable])
        return AbsentValue(variable=variable)


class _DonorPredicateResolver:
    """Resolve a source-only filter against one augmented donor record."""

    def __init__(self, dataset: str, values: Mapping[str, RuntimeValue]) -> None:
        self._dataset = dataset
        self._values = values

    def resolve(self, variable: str) -> Resolution:
        qualifier, separator, field = variable.partition(".")
        if not separator and self._dataset == "SELF":
            field = qualifier
            qualifier = "SELF"
            separator = "."
        if not separator or qualifier != self._dataset or field not in self._values:
            return FailedResolution(
                condition=RuntimeCondition(
                    phase="validation",
                    condition="unknown_field",
                    context={"identifier": variable},
                )
            )
        return ResolvedValue(value=self._values[field])


class _DerivationFailure(NamedTuple):
    """A derivation that raised an expression condition on a record.

    REQ-1185 surfaces the condition at the derivation's own path instead of
    treating the record as a miss. A failed REQ-1263 read of another
    intermediate keeps that intermediate's own path, exactly as a row
    reading it would report.
    """

    name: str
    condition: ConditionResult
    spec_path: str | None = None

    def path(self, plan: PlannedIntermediate) -> str:
        return self.spec_path or f"{plan.path}.derivations.{self.name}"


def _filter_records(
    records: Sequence[IndexedRecord],
    predicate: dict[str, object] | None,
    dataset: str,
) -> list[IndexedRecord] | ConditionResult:
    """Keep donor records whose source-only predicate answers true."""
    if predicate is None:
        return list(records)
    kept: list[IndexedRecord] = []
    for record in records:
        result = evaluate_predicate(
            predicate, _DonorPredicateResolver(dataset, record.values)
        )
        if isinstance(result, ConditionResult):
            return result
        assert isinstance(result, PredicateValue)
        if result.value is TruthValue.TRUE:
            kept.append(record)
    return kept


class IntermediateSelector:
    """Select at most one record per current row for each declared intermediate."""

    def __init__(
        self,
        plans: Sequence[PlannedIntermediate],
        relations: Mapping[str, RelationIndex],
        evaluate: Callable[[Expression, Resolver], EvaluationResult] | None = None,
    ) -> None:
        self.plans = {plan.identifier: plan for plan in plans}
        self._relations = relations
        self._eligible: dict[
            str, tuple[IndexedRecord, ...] | ConditionResult | _DerivationFailure
        ] = {}
        self._derived: dict[str, tuple[IndexedRecord, ...] | _DerivationFailure] = {}
        self._match_index: dict[
            str, dict[tuple[RuntimeValue, ...], tuple[IndexedRecord, ...]]
        ] = {}
        self._evaluate = evaluate or evaluate_expression
        self._self_records: tuple[IndexedRecord, ...] = ()
        self.uses_self = any(plan.dataset == "SELF" for plan in plans)

    def add_self_records(self, rows: Sequence[Mapping[str, RuntimeValue]]) -> None:
        """Expose completed row templates to subsequent SELF selections."""
        start = len(self._self_records)
        self._self_records += tuple(
            IndexedRecord(position=start + index, values=dict(values))
            for index, values in enumerate(rows)
        )
        for identifier, plan in self.plans.items():
            if plan.dataset == "SELF":
                self._eligible.pop(identifier, None)
                self._derived.pop(identifier, None)
                self._match_index.pop(identifier, None)

    def declares(self, identifier: str) -> bool:
        return identifier in self.plans

    def driver_records(
        self, identifier: str
    ) -> tuple[IndexedRecord, ...] | IntermediateOutcome:
        """Return a source-only intermediate's records for row construction."""
        plan = self.plans[identifier]
        eligible = self._filtered(plan)
        if isinstance(eligible, ConditionResult):
            return IntermediateOutcome(
                condition=eligible, spec_path=f"{plan.path}.filter"
            )
        if isinstance(eligible, _DerivationFailure):
            return IntermediateOutcome(
                condition=eligible.condition,
                spec_path=eligible.path(plan),
            )
        return eligible

    def _filtered(
        self,
        plan: PlannedIntermediate,
        current: Mapping[str, RuntimeValue] | None = None,
    ) -> tuple[IndexedRecord, ...] | ConditionResult | _DerivationFailure:
        """Cache source-only filtering over augmented donor records.

        A target-dependent result must never enter this run-wide cache.
        """
        if plan.derivation_references:
            driver_values = {
                name: (current or {}).get(name, MISSING)
                for name, _ in plan.derivation_references
            }
            records = self._augment_all(plan, self._source_records(plan), driver_values)
            if isinstance(records, _DerivationFailure):
                return records
            predicate = None if plan.filter_variables else plan.filter_predicate
            kept = _filter_records(records, predicate, plan.dataset)
            return kept if isinstance(kept, ConditionResult) else tuple(kept)
        cached = self._eligible.get(plan.identifier)
        if cached is None:
            records = self._records(plan)
            if isinstance(records, _DerivationFailure):
                self._eligible[plan.identifier] = records
                return records
            predicate = None if plan.filter_variables else plan.filter_predicate
            kept = _filter_records(records, predicate, plan.dataset)
            cached = kept if isinstance(kept, ConditionResult) else tuple(kept)
            self._eligible[plan.identifier] = cached
        return cached

    def _records(
        self, plan: PlannedIntermediate
    ) -> tuple[IndexedRecord, ...] | _DerivationFailure:
        """Return the donor records with derivations computed.

        REQ-1185 computes each derivation once per record and caches the
        augmented records before filtering, matching, and selection.
        Derivations evaluate in declaration order: a window derivation
        partitions the donor records as augmented by every derivation
        declared before it, so later derivations read its per-record
        result.
        """
        source = self._source_records(plan)
        if not plan.derived:
            return tuple(source)
        cached = self._derived.get(plan.identifier)
        if cached is None:
            cached = self._augment_all(plan, source)
            self._derived[plan.identifier] = cached
        return cached

    def _source_records(self, plan: PlannedIntermediate) -> tuple[IndexedRecord, ...]:
        return (
            self._self_records
            if plan.dataset == "SELF"
            else self._relations[plan.dataset].records
        )

    def _augment_all(
        self,
        plan: PlannedIntermediate,
        source: Sequence[IndexedRecord],
        current: Mapping[str, RuntimeValue] | None = None,
    ) -> tuple[IndexedRecord, ...] | _DerivationFailure:
        """Compute every derivation in declaration order.

        REQ-1185 surfaces a derivation's expression condition: a record the
        derivation cannot compute is a data error, not a miss. A derivation
        that yields missing leaves the record augmented with missing, which
        simply does not match.
        """
        values_list = [dict(record.values) for record in source]
        # REQ-1263: one selection per donor record and read intermediate,
        # shared by every derivation of that record that reads it.
        selections: list[dict[str, IntermediateOutcome]] = [{} for _ in source]
        for name, declaration in plan.derived:
            if declaration.value.operation in WINDOW_OPERATIONS:
                failure = self._augment_window(plan, name, declaration, values_list)
            else:
                failure = self._augment_scalar(
                    plan, name, declaration, values_list, selections, current
                )
            if failure is not None:
                return failure
        return tuple(
            IndexedRecord(position=record.position, values=values)
            for record, values in zip(source, values_list, strict=True)
        )

    def _augment_scalar(
        self,
        plan: PlannedIntermediate,
        name: str,
        declaration: HandledExpression,
        values_list: list[dict[str, RuntimeValue]],
        selections: list[dict[str, IntermediateOutcome]],
        current: Mapping[str, RuntimeValue] | None = None,
    ) -> _DerivationFailure | None:
        """Compute one scalar derivation for every donor record.

        A window operation nested in the derivation partitions the donor
        records once for the whole loop: the planner rejects references to
        the derivation itself and to later ones, so the readable records
        are identical for every record.
        """
        partition_cache: dict[tuple[str, object], _PreparedPartitions] = {}
        for index, values in enumerate(values_list):
            failed_reads: list[tuple[RuntimeCondition, str]] = []
            resolver = _IntermediateDerivationResolver(
                plan.dataset,
                values_list,
                index,
                partition_cache=partition_cache,
                exclude=name,
                current=current,
                read=partial(
                    self._read_for_record,
                    selected=selections[index],
                    failed=failed_reads,
                ),
            )
            result = self._evaluate(declaration.value, resolver)
            if isinstance(result, ConditionResult):
                spec_path = next(
                    (
                        path
                        for condition, path in failed_reads
                        if condition is result.condition
                    ),
                    None,
                )
                return _DerivationFailure(name, result, spec_path)
            values[name] = result.value
        return None

    def _read_for_record(
        self,
        identifier: str,
        field: str,
        resolver: Resolver,
        *,
        selected: dict[str, IntermediateOutcome],
        failed: list[tuple[RuntimeCondition, str]],
    ) -> Resolution | None:
        """Read another intermediate's column for one donor record (REQ-1263).

        The other intermediate's match values, range value, and correlated
        filter fields resolve against the donor record through `resolver`,
        which the planner has confined to the record's stored fields and
        earlier derivations. The selection is cached in `selected` so every
        derivation of the record shares it; a failed selection is recorded
        in `failed` with the other intermediate's path.
        """
        plan = self.plans.get(identifier)
        if plan is None:
            return None
        outcome = selected.get(identifier)
        if outcome is None:
            current: dict[str, RuntimeValue] = {}
            for name in plan.dependencies:
                resolved = resolver.resolve(name)
                if isinstance(resolved, FailedResolution):
                    return resolved
                current[name] = (
                    resolved.value if isinstance(resolved, ResolvedValue) else MISSING
                )
            outcome = self.select(identifier, current, resolver=resolver)
            selected[identifier] = outcome
        if outcome.condition is not None:
            assert outcome.spec_path is not None
            failed.append((outcome.condition.condition, outcome.spec_path))
            return FailedResolution(condition=outcome.condition.condition)
        if outcome.record is None:
            # REQ-0124: a decided absence answers the declared `missing`
            # literal, distinct from a selected record's missing value.
            return ResolvedValue(
                value=absent_value(outcome.absent), handled_by=outcome.handled_by
            )
        return ResolvedValue(
            value=outcome.record.values[field], handled_by=outcome.handled_by
        )

    def _augment_window(
        self,
        plan: PlannedIntermediate,
        name: str,
        declaration: HandledExpression,
        values_list: list[dict[str, RuntimeValue]],
    ) -> _DerivationFailure | None:
        """Compute one window derivation across the donor records.

        The partition is built once at the derivation's declaration
        position; every record then reads its own answer from it.
        """
        operation = declaration.value.operation
        payload = declaration.value.root[operation]
        if not isinstance(payload, Mapping):
            return _DerivationFailure(
                name,
                expression_condition(
                    "validation",
                    "invalid_field_type",
                    {"operation": operation, "expected": "a mapping"},
                    requirement="REQ-0321",
                ),
            )
        window = window_spec(payload)
        prepared = _prepare_window_partitions(plan.dataset, values_list, window)
        if isinstance(prepared, ConditionResult):
            return _DerivationFailure(name, prepared)
        grouped, eligibilities, views = prepared
        for index in range(len(values_list)):
            result = _window_value_for(
                operation, payload, window, grouped, eligibilities, views, index
            )
            if isinstance(result, ConditionResult):
                return _DerivationFailure(name, result)
            values_list[index][name] = result.value
        return None

    def select(
        self,
        identifier: str,
        current: Mapping[str, RuntimeValue],
        *,
        resolver: Resolver | None = None,
    ) -> IntermediateOutcome:
        """Choose this row's record, using its resolver for relational key expressions."""
        plan = self.plans[identifier]
        eligible = self._filtered(plan, current)
        if isinstance(eligible, ConditionResult):
            return IntermediateOutcome(
                condition=eligible, spec_path=f"{plan.path}.filter"
            )
        if isinstance(eligible, _DerivationFailure):
            return IntermediateOutcome(
                condition=eligible.condition,
                spec_path=eligible.path(plan),
            )
        if plan.match_expressions:
            # REQ-1259: an expression match value evaluates against the
            # current row. A missing result matches nothing, exactly like a
            # missing variable.
            resolved_current = dict(current)
            expression_resolver = (
                resolver if resolver is not None else MappingResolver(current)
            )
            for keyed in plan.match_expressions:
                result = self._evaluate(keyed.expression, expression_resolver)
                if isinstance(result, ConditionResult):
                    return IntermediateOutcome(
                        condition=result,
                        spec_path=f"{plan.path}.key.{keyed.column}",
                    )
                if not isinstance(result, ValueResult):
                    return IntermediateOutcome(
                        condition=_condition(
                            "invalid_field_type",
                            "REQ-0321",
                            {
                                "operation": "lookup",
                                "reason": (
                                    "a key match value that did not evaluate to a value"
                                ),
                            },
                            phase="validation",
                        ),
                        spec_path=f"{plan.path}.key.{keyed.column}",
                    )
                resolved_current[keyed.name] = result.value
            current = resolved_current
        return _select_eligible(
            plan,
            eligible,
            current,
            index=_build_match_index(eligible, plan.match_fields)
            if plan.derivation_references
            else self._match_index_for(plan, eligible),
        )

    def verify_uniqueness(
        self, *, self_only: bool = False
    ) -> tuple[VerificationFailure, ...]:
        """Evaluate every declared intermediate uniqueness check (REQ-1245).

        Each check runs over the source-only filtered donor records with
        derivations computed. Input checks precede row construction; SELF
        checks follow each completed template.
        A filter or derivation that failed to materialize fails the run
        here too: the verification is load-bearing for a declared
        intermediate, so its failure cannot wait for a selection that may
        never happen.
        """
        failures: list[VerificationFailure] = []
        for plan in self.plans.values():
            if (plan.dataset == "SELF") != self_only:
                continue
            if not plan.unique_checks:
                continue
            records = self._filtered(plan)
            if isinstance(records, ConditionResult):
                failures.append(
                    _materialization_failure(
                        plan, records.condition, f"{plan.path}.filter"
                    )
                )
                continue
            if isinstance(records, _DerivationFailure):
                failures.append(
                    _materialization_failure(
                        plan,
                        records.condition.condition,
                        records.path(plan),
                    )
                )
                continue
            for check in plan.unique_checks:
                duplicates = _duplicate_groups(records, check.columns)
                if duplicates:
                    context = {
                        "intermediate": plan.identifier,
                        "dataset": plan.dataset,
                        "columns": list(check.columns),
                        "duplicate_count": len(duplicates),
                    }
                    if check.verification_id is not None:
                        context["verification_id"] = check.verification_id
                    failures.append(
                        VerificationFailure(
                            phase="verification",
                            condition="duplicate_intermediate_records",
                            spec_paths=(check.spec_path,),
                            requirement="REQ-1245",
                            context=context,
                            offending_keys=tuple(
                                {
                                    field: json_value(record.values[field])
                                    for field in check.columns
                                }
                                for record in duplicates
                            ),
                        )
                    )
        return tuple(failures)

    def _match_index_for(
        self,
        plan: PlannedIntermediate,
        eligible: Sequence[IndexedRecord],
    ) -> dict[tuple[RuntimeValue, ...], tuple[IndexedRecord, ...]]:
        """Return the plan's match-key index, building it once per run.

        REQ-0134 matches on equality of every source/key pair; the index
        answers that equality with one hash lookup per row instead of one
        scan of the eligible records per row. Buckets keep eligible order,
        so narrowing, `keep` selection, and multiple-match reporting see
        the same record sequence the scan produced.
        """
        cached = self._match_index.get(plan.identifier)
        if cached is None:
            cached = _build_match_index(eligible, plan.match_fields)
            self._match_index[plan.identifier] = cached
        return cached


def _build_match_index(
    eligible: Sequence[IndexedRecord],
    fields: Sequence[str],
) -> dict[tuple[RuntimeValue, ...], tuple[IndexedRecord, ...]]:
    """Bucket the eligible records by their match key, keeping eligible order."""
    buckets: dict[tuple[RuntimeValue, ...], list[IndexedRecord]] = {}
    for record in eligible:
        key = _match_key(tuple(record.values[field] for field in fields))
        if key is None:
            continue
        buckets.setdefault(key, []).append(record)
    return {key: tuple(records) for key, records in buckets.items()}


def _implicit_selection(
    relation: RelationIndex,
    filter_text: str | None,
    predicate: PredicateAst | None,
    fields: Sequence[str],
) -> ImplicitSelection | ConditionResult:
    """Return an implicit join's eligible records and match index, once per run.

    REQ-0150: the eligible records depend only on the relation and a
    source-only filter, so every row of the run shares them and the index
    over them, exactly as a named intermediate does (REQ-0134). Without it
    each read would scan every record of the relation.
    """
    identity = (filter_text if predicate is not None else None, tuple(fields))
    cached = relation.implicit_selections.get(identity)
    if cached is None:
        eligible = eligible_records(relation.records, predicate, relation)
        cached = (
            eligible
            if isinstance(eligible, ConditionResult)
            else (tuple(eligible), _build_match_index(eligible, fields))
        )
        relation.implicit_selections[identity] = cached
    return cached


def _match_key(
    values: Sequence[RuntimeValue],
) -> tuple[RuntimeValue, ...] | None:
    """Return the hash key for one side of a match, or `None` when it cannot match.

    The key preserves `_equal` exactly: missing matches nothing, `bool`
    never compares (R007 orders only str/int/float/date/datetime, and
    `values_comparable` refuses every other pairing), and a non-finite
    float cannot reach the runtime as a value. `int`/`float` share Python
    equality, so `1` and `1.0` key together exactly as `compare_values`
    equates them; `DateValue`/`DateTimeValue` hash by the `ordering_key`
    `compare_values` orders by.
    """
    for value in values:
        if value is MISSING or type(value) is bool:
            return None
        if type(value) is float and not math.isfinite(value):
            return None
        if not isinstance(value, (str, int, float, DateValue, DateTimeValue)):
            return None
    return tuple(values)


def _select_eligible(
    plan: PlannedIntermediate,
    eligible: Sequence[IndexedRecord],
    current: Mapping[str, RuntimeValue],
    *,
    index: Mapping[tuple[RuntimeValue, ...], Sequence[IndexedRecord]] | None = None,
) -> IntermediateOutcome:
    """Match, narrow, and choose one record from the eligible records.

    Named intermediates and implicit joins share these steps: the named
    selector caches the eligible records per intermediate, and an implicit
    join caches them on its relation per filter and matched fields.
    """
    values = [current.get(name, MISSING) for name in plan.match_variables]
    if any(value is MISSING for value in values):
        # A missing match value is not an identity any record shares,
        # so the intermediate yields nothing before any record is read.
        return _absent(plan, values)
    if (
        plan.between_value is not None
        and current.get(plan.between_value, MISSING) is MISSING
    ):
        # A missing range value is incomplete, not unmatched: it yields
        # nothing before any record is read.
        return _absent(plan, values)
    if index is not None:
        key = _match_key(tuple(values))
        matched = list(index.get(key, ())) if key is not None else []
    else:
        matched = [
            record
            for record in eligible
            if all(
                _equal(record.values[field], value)
                for field, value in zip(plan.match_fields, values, strict=True)
            )
        ]

    if plan.filter_variables:
        filtered: list[IndexedRecord] = []
        for record in matched:
            result = evaluate_predicate(
                plan.filter_predicate,
                _LookupPredicateResolver(plan.dataset, record.values, current),
            )
            if isinstance(result, ConditionResult):
                return IntermediateOutcome(
                    condition=result, spec_path=f"{plan.path}.filter"
                )
            assert isinstance(result, PredicateValue)
            if result.value is TruthValue.TRUE:
                filtered.append(record)
        matched = filtered

    narrowed = _narrowed(plan, matched, current)
    if isinstance(narrowed, IntermediateOutcome):
        return narrowed

    if not narrowed:
        return _absent(plan, values)
    if len(narrowed) == 1:
        return IntermediateOutcome(record=narrowed[0])
    if plan.keep is None:
        # REQ-0127: more than one surviving record with nothing to choose
        # by is the unhandled multiple match the rule refuses.
        return IntermediateOutcome(
            condition=_condition(
                "multiple_matches",
                "REQ-0127",
                {
                    "intermediate": plan.identifier,
                    "dataset": plan.dataset,
                    **_matched_key(plan, values),
                    "match_count": len(narrowed),
                },
            ),
            spec_path=plan.path,
        )
    chosen = select_record(narrowed, plan.order_terms, plan.keep)
    if isinstance(chosen, ConditionResult):
        return IntermediateOutcome(condition=chosen, spec_path=f"{plan.path}.order_by")
    handled_by: HandlerName | None = None
    if len(narrowed) > 1:
        # The declared keep actually chose among surviving records: R008
        # counts the selection where it happened.
        handled_by = "multiple_matches"
    return IntermediateOutcome(record=chosen, handled_by=handled_by)


def _absent(
    plan: PlannedIntermediate,
    values: Sequence[RuntimeValue],
) -> IntermediateOutcome:
    """Answer an intermediate that yields nothing under REQ-0129."""
    if plan.no_match_declared:
        return IntermediateOutcome(absent=plan.no_match, handled_by="no_match")
    if plan.implicit_join:
        # REQ-0111: the implicit join registers no handler and answers
        # absence as a missing result.
        return IntermediateOutcome(absent=None)
    # REQ-0124 and REQ-0344: an omitted `no_match` makes absence fatal.
    return IntermediateOutcome(
        condition=ConditionResult(
            condition=RuntimeCondition(
                phase="join",
                condition="unmatched_key",
                context={
                    "intermediate": plan.identifier,
                    "dataset": plan.dataset,
                    **_matched_key(plan, values),
                },
                applicable_handler="no_match",
                requirement="REQ-0124",
            )
        ),
        spec_path=plan.path,
    )


def _narrowed(
    plan: PlannedIntermediate,
    matched: Sequence[IndexedRecord],
    current: Mapping[str, RuntimeValue],
) -> list[IndexedRecord] | IntermediateOutcome:
    """Keep the equality-matched records the declared range admits."""
    if plan.between_value is None:
        return list(matched)
    value = current.get(plan.between_value, MISSING)
    kept: list[IndexedRecord] = []
    for record in matched:
        admitted = True
        edges: dict[str, RuntimeValue] = {}
        for side, bound in (
            ("lower", plan.between_lower),
            ("upper", plan.between_upper),
        ):
            if bound is None:
                continue
            edge = record.values[bound]
            # REQ-0128: both endpoints are inclusive, and a record missing a
            # stated bound is ineligible rather than open.
            if edge is MISSING:
                admitted = False
                break
            edges[side] = edge
        if admitted:
            try:
                if "lower" in edges and compare_values(edges["lower"], value) > 0:
                    admitted = False
                if (
                    admitted
                    and "upper" in edges
                    and compare_values(value, edges["upper"]) > 0
                ):
                    admitted = False
            except TypeError:
                return IntermediateOutcome(
                    condition=_condition(
                        "incomparable_range_types",
                        "REQ-0121",
                        {
                            "intermediate": plan.identifier,
                            "value_type": runtime_type_name(value),
                            **{
                                f"{side}_type": runtime_type_name(edges[side])
                                for side in ("lower", "upper")
                                if side in edges
                            },
                        },
                        phase="validation",
                    ),
                    spec_path=f"{plan.path}.between",
                )
        if admitted:
            kept.append(record)
    return kept


def _matched_key(
    plan: PlannedIntermediate,
    values: Sequence[RuntimeValue],
) -> dict[str, JsonValue]:
    """Return the fields the intermediate matched on and the values it matched with.

    REQ-0143 keeps one vocabulary for every intermediate failure, so an unmatched
    key and an unhandled multiple match report the match the same way and
    leave `keys` to the output row the failure belongs to.
    """
    return {
        "key": list(plan.match_fields),
        "intermediate_key": {
            field: json_value(value)
            for field, value in zip(plan.match_fields, values, strict=True)
        },
    }


def _equal(left: RuntimeValue, right: RuntimeValue) -> bool:
    """Compare two match values under the equality their type owns.

    R019 equality for strings is Python's, and a missing right-side value
    matches nothing because absence is not an identity.
    """
    if left is MISSING or right is MISSING:
        return False
    try:
        return compare_values(left, right) == 0
    except TypeError:
        return False


def _uniqueness_key(values: Sequence[RuntimeValue]) -> tuple[object, ...]:
    """Return the grouping key for one record's uniqueness columns.

    Mirrors the output `unique` check's comparable form: missing reads as
    `None`, and dates group by their text form. `int`/`float` share Python
    equality, so `1` and `1.0` group together exactly as matching equates
    them.
    """
    key: list[object] = []
    for value in values:
        if value is MISSING:
            key.append(None)
        elif isinstance(value, (DateValue, DateTimeValue)):
            key.append(value.to_text())
        else:
            key.append(value)
    return tuple(key)


def _materialization_failure(
    plan: PlannedIntermediate,
    failed: RuntimeCondition,
    spec_path: str,
) -> VerificationFailure:
    """Report a verified intermediate whose records never materialized.

    REQ-1245 makes the verification load-bearing: a declared intermediate
    whose filter or derivation failed cannot wait for a selection that may
    never happen, so the original condition surfaces here with the same
    spec path `select` would have reported it at.
    """
    return VerificationFailure(
        phase="verification",
        condition=failed.condition,
        spec_paths=(spec_path,),
        requirement=failed.requirement or "REQ-1245",
        context={"intermediate": plan.identifier, **failed.context},
    )


def _duplicate_groups(
    records: Sequence[IndexedRecord], columns: Sequence[str]
) -> list[IndexedRecord]:
    """Return one representative record per repeated key combination."""
    seen: dict[tuple[object, ...], IndexedRecord] = {}
    duplicates: dict[tuple[object, ...], IndexedRecord] = {}
    for record in records:
        key = _uniqueness_key(tuple(record.values[field] for field in columns))
        if key in seen:
            duplicates.setdefault(key, seen[key])
        else:
            seen[key] = record
    return list(duplicates.values())


def absent_value(absent: JsonValue) -> RuntimeValue:
    """Return the runtime value an intermediate's decided absence carries."""
    normalized = normalize_runtime_value(absent)
    if isinstance(normalized, ValueResult):
        return normalized.value
    return MISSING


def _names(value: object) -> tuple[str, ...] | None:
    if isinstance(value, str):
        return (value,)
    if isinstance(value, Sequence) and all(isinstance(item, str) for item in value):
        return tuple(value)  # type: ignore[arg-type]
    return None


def _order_terms(
    payload: Mapping[str, object], dataset: str
) -> tuple[tuple[OrderTerm, str], ...] | None:
    """Build the (term, field) pairs an implicit join orders by."""
    raw = payload.get("order_by")
    if raw is None:
        return None
    if not isinstance(raw, Sequence) or isinstance(raw, str):
        return None
    terms: list[tuple[OrderTerm, str]] = []
    for item in raw:
        if isinstance(item, str):
            term = OrderTerm(variable=item)
        elif isinstance(item, Mapping):
            try:
                term = OrderTerm.model_validate(dict(item))
            except ValidationError:
                return None
        else:
            return None
        qualifier, _, field = term.variable.partition(".")
        if qualifier != dataset:
            return None
        terms.append((term, field))
    return tuple(terms)


def evaluate_intermediate(
    payload: Mapping[str, object],
    relation: RelationIndex,
    resolve: Callable[[str], Resolution],
    evaluate: Callable[[Expression, Resolver], EvaluationResult] | None = None,
    *,
    resolver: Resolver | None = None,
) -> EvaluationResult:
    """Evaluate one implicit join's read against its dataset.

    The planner validates the declaration; this answers the row. `resolve`
    reads one current-row variable the way the derivation's own resolver
    does, so a source may name an output column or a driver-qualified
    dataset column exactly as the specification wrote it. `resolver` also
    supplies the row's relation when a key expression is relational. `evaluate`
    is the configured expression dispatcher; it defaults to the module-level one.
    """
    pairs = key_pairs(payload.get("key"))
    value_field = payload.get("value")
    dataset = relation.dataset
    if pairs is None or not pairs[0] or not isinstance(value_field, str):
        return ConditionResult(
            condition=RuntimeCondition(
                phase="validation",
                condition="invalid_field_type",
                context={
                    "operation": "lookup",
                    "expected": "key and value",
                },
                requirement="REQ-0321",
            )
        )
    keys, entries = pairs
    if not relation.has(value_field) or any(not relation.has(key) for key in keys):
        return ConditionResult(
            condition=RuntimeCondition(
                phase="validation",
                condition="unknown_field",
                context={"identifier": f"{dataset}.{value_field}"},
            )
        )

    current: dict[str, RuntimeValue] = {}
    match_variables: list[str] = []
    match_expressions: list[MatchValueExpression] = []
    key_resolver = resolver if resolver is not None else CallableResolver(resolve)
    evaluate_expression_with = evaluate or evaluate_expression
    for key, entry in zip(keys, entries, strict=True):
        if isinstance(entry, str):
            match_variables.append(entry)
            continue
        # REQ-1259: an expression match value evaluates against the current
        # row through the lookup's own resolver. A missing result matches
        # nothing.
        expression = (
            entry
            if isinstance(entry, Expression)
            else Expression.model_validate(dict(entry))  # type: ignore[call-overload]
        )
        result = evaluate_expression_with(expression, key_resolver)
        if isinstance(result, ConditionResult):
            return result
        if not isinstance(result, ValueResult):
            return _condition(
                "invalid_field_type",
                "REQ-0321",
                {
                    "operation": "lookup",
                    "reason": "a key match value that did not evaluate to a value",
                },
                phase="validation",
            )
        name = f"key[{key}]"
        match_variables.append(name)
        match_expressions.append(
            MatchValueExpression(
                column=key, name=name, expression=expression, variables=()
            )
        )
        current[name] = result.value
    names = [entry for entry in entries if isinstance(entry, str)]
    between = payload.get("between")
    between_value: str | None = None
    between_lower: str | None = None
    between_upper: str | None = None
    if between is not None:
        # The named form requires `value` plus at least one bound (REQ-1049); a
        # payload that reached here without them narrows by a bound it
        # cannot read, so answer the declaration rather than raising on
        # the missing one.
        raw = between if isinstance(between, Mapping) else {}
        value_raw = raw.get("value")
        lower_raw = raw.get("lower")
        upper_raw = raw.get("upper")
        if not (
            isinstance(value_raw, str)
            and (lower_raw is not None or upper_raw is not None)
            and all(
                isinstance(bound, str)
                for bound in (lower_raw, upper_raw)
                if bound is not None
            )
        ):
            return ConditionResult(
                condition=RuntimeCondition(
                    phase="validation",
                    condition="invalid_field_type",
                    context={
                        "operation": "lookup",
                        "expected": "between value with at least one bound",
                    },
                    requirement="REQ-0321",
                )
            )
        between_value = value_raw
        between_lower = lower_raw
        between_upper = upper_raw
        names.append(between_value)
    predicate = None
    filter_text = payload.get("filter")
    if isinstance(filter_text, str):
        try:
            predicate = parse_predicate_cached(filter_text)
        except PredicateError:
            return ConditionResult(
                condition=RuntimeCondition(
                    phase="validation",
                    condition="invalid_field_type",
                    context={"identifier": filter_text},
                )
            )
    filter_variables = tuple(
        name
        for name in predicate_identifiers(predicate or {})
        if name.split(".", 1)[0] != dataset
    )
    names.extend(filter_variables)
    for name in names:
        resolution = resolve(name)
        if isinstance(resolution, ResolvedValue):
            current[name] = resolution.value
        elif isinstance(resolution, FailedResolution):
            return ConditionResult(condition=resolution.condition)
        else:
            current[name] = MISSING

    terms = _order_terms(payload, dataset)
    keep = payload.get("keep")
    keep_value = keep if keep in ("first", "last") else None

    plan = PlannedIntermediate(
        identifier=f"intermediate({dataset})",
        dataset=dataset,
        path="lookup",
        match_variables=tuple(match_variables),
        match_expressions=tuple(match_expressions),
        match_fields=tuple(keys),
        filter_predicate=predicate,
        order_terms=terms or (),
        keep=keep_value,
        between_value=between_value,
        between_lower=between_lower,
        between_upper=between_upper,
        implicit_join=True,
    )
    selection = _implicit_selection(
        relation,
        filter_text if isinstance(filter_text, str) else None,
        None if filter_variables else predicate,
        keys,
    )
    if isinstance(selection, ConditionResult):
        return selection
    eligible, index = selection
    outcome = _select_eligible(plan, eligible, current, index=index)
    if outcome.condition is not None:
        return outcome.condition
    if outcome.record is not None:
        resolved = normalize_runtime_value(outcome.record.values[value_field])
        if isinstance(resolved, ValueResult) and outcome.handled_by is not None:
            return resolved.model_copy(update={"handled_by": outcome.handled_by})
        return resolved
    return ValueResult(
        value=absent_value(outcome.absent), handled_by=outcome.handled_by
    )


__all__ = [
    "IntermediateOutcome",
    "IntermediateSelector",
    "absent_value",
    "evaluate_intermediate",
    "types_comparable",
]
