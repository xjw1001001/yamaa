//! Captured raw YAML entry point. Hosts supply bytes and source identities only.
//! Filesystem authority, include discovery and publication remain explicit host ports.
use crate::yaml_decode::{decode_yaml, DecodeFailure, DecodeLimits, DecodedYaml, SourcePosition};
use std::sync::Arc;
use yamaa_core::schema::{
    BundleError, BundleLimits, NormalizationBudget, NormalizationError, NormalizationLimits,
    NormalizedDocument, SchemaDiagnostic, SchemaModule, SchemaOrigin, SchemaStructure,
    SpecificationDocument, ValidationError, WindowReference,
};
#[path = "specification_inheritance.rs"]
mod inheritance;
pub use inheritance::{CapturedParent, InheritanceError, InheritancePort, SourceFailure};

/// The engine-owned identity and byte snapshot shared with metadata preparation.
pub use yamaa_engine::project_preparation::Source;
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub captured_bytes: usize,
    pub identity_bytes: usize,
    pub decode: DecodeLimits,
    pub bundle: BundleLimits,
    pub normalization: NormalizationLimits,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            captured_bytes: 16_777_216,
            identity_bytes: 65_536,
            decode: Default::default(),
            bundle: Default::default(),
            normalization: Default::default(),
        }
    }
}
#[derive(Debug)]
pub enum Error {
    Limit(&'static str),
    Decode {
        identity: String,
        error: DecodeFailure,
    },
    Bundle(BundleError),
    Normalize(NormalizationError),
    Validation(ValidationError),
    Findings(Box<CapturedFindings>),
    /// This entry point cannot silently treat an inherited layer as standalone.
    InheritanceRequired,
    /// A versioned root must retain its schema-version admission gate.
    VersionedRootRequired,
    /// Only admitted named classes can be selected from the captured closure.
    UnknownClass(String),
}

/// A failed semantic pass retains the exact source, schema and context arena.
/// Node references belong to the pass input, which may differ from the raw entry.
#[derive(Debug)]
pub struct CapturedFindings {
    schema: Arc<CapturedSchema>,
    source: Source,
    document: Option<yamaa_core::schema::Document>,
    findings: Vec<SchemaDiagnostic>,
}
impl CapturedFindings {
    pub fn schema(&self) -> &CapturedSchema {
        &self.schema
    }
    pub fn source(&self) -> &Source {
        &self.source
    }
    pub fn document(&self) -> Option<&yamaa_core::schema::Document> {
        self.document.as_ref()
    }
    pub fn findings(&self) -> &[SchemaDiagnostic] {
        &self.findings
    }
}

/// One immutable admitted schema closure, reusable across separate specification runs.
#[derive(Debug)]
pub struct CapturedSchema {
    sources: Vec<Source>,
    locations: Vec<Vec<SourcePosition>>,
    structure: SchemaStructure,
    limits: Limits,
}

/// An owned structural root. It grants no specification, code or data authority.
#[derive(Debug)]
pub struct CapturedDocument {
    schema: Arc<CapturedSchema>,
    class_name: String,
    source: Source,
    raw: DecodedYaml,
    normalized: NormalizedDocument,
}
impl CapturedDocument {
    pub fn class_name(&self) -> &str {
        &self.class_name
    }
    pub fn schema(&self) -> &Arc<CapturedSchema> {
        &self.schema
    }
    pub fn source(&self) -> &Source {
        &self.source
    }
    pub fn raw(&self) -> &DecodedYaml {
        &self.raw
    }
    pub fn normalized(&self) -> &NormalizedDocument {
        &self.normalized
    }
}
impl CapturedSchema {
    /// Decode the complete host-captured closure using the shared YAML semantics.
    /// Cumulative byte/count admission happens before any source is decoded.
    pub fn admit(sources: Vec<Source>, entry: usize, limits: Limits) -> Result<Arc<Self>, Error> {
        Self::admit_with_root(sources, entry, "root_class", limits)
    }
    /// Capture a closed schema root without interpreting it as a specification.
    pub fn admit_root(
        sources: Vec<Source>,
        entry: usize,
        root_class: &str,
        limits: Limits,
    ) -> Result<Arc<Self>, Error> {
        if root_class.len() > limits.identity_bytes {
            return Err(Error::Limit("root_class"));
        }
        Self::admit_with_root(sources, entry, root_class, limits)
    }
    fn admit_with_root(
        sources: Vec<Source>,
        entry: usize,
        root_class: &str,
        limits: Limits,
    ) -> Result<Arc<Self>, Error> {
        if sources.len() > limits.bundle.modules {
            return Err(Error::Limit("schema_modules"));
        }
        let mut bytes = 0usize;
        let mut identities = 0usize;
        for source in &sources {
            bytes = bytes
                .checked_add(source.bytes.len())
                .filter(|&n| n <= limits.captured_bytes)
                .ok_or(Error::Limit("captured_bytes"))?;
            identities = identities
                .checked_add(source.identity.len())
                .filter(|&n| n <= limits.identity_bytes)
                .ok_or(Error::Limit("identity_bytes"))?;
        }
        let mut locations = Vec::with_capacity(sources.len());
        let modules = sources
            .iter()
            .map(|source| {
                let decoded =
                    decode_yaml(&source.bytes, limits.decode).map_err(|error| Error::Decode {
                        identity: source.identity.clone(),
                        error,
                    })?;
                locations.push(decoded.locations);
                Ok(SchemaModule {
                    name: source.identity.clone(),
                    document: decoded.document,
                })
            })
            .collect::<Result<Vec<_>, Error>>()?;
        let structure = SchemaStructure::admit(modules, entry, root_class, limits.bundle)
            .map_err(Error::Bundle)?;
        Ok(Arc::new(Self {
            sources,
            locations,
            structure,
            limits,
        }))
    }
    /// Preserve the exact captured bytes for provenance and direct equality checks.
    pub fn sources(&self) -> &[Source] {
        &self.sources
    }
    pub fn locations(&self) -> &[Vec<SourcePosition>] {
        &self.locations
    }
    pub fn structure(&self) -> &SchemaStructure {
        &self.structure
    }

    /// Validate and normalize a versioned root without windows, inheritance or IO.
    /// Environment-specific admission follows this captured structural gate.
    pub fn prepare_structural(self: &Arc<Self>, source: Source) -> Result<CapturedDocument, Error> {
        let raw = self.decode_entry(&source)?;
        let mut budget = NormalizationBudget::new(self.limits.normalization);
        let normalized = self
            .structure
            .normalize_document(&raw.document, &mut budget)
            .map_err(|error| self.normalization_failure(&source, &raw.document, error))?;
        Ok(CapturedDocument {
            schema: Arc::clone(self),
            class_name: self.structure.root_class().name.clone(),
            source,
            raw,
            normalized,
        })
    }

    /// Normalize a versionless class using the version of its captured schema.
    /// Function definitions and codelist sources never fabricate document versions.
    /// A class declaring schema_version must use prepare_structural instead.
    pub fn prepare_class(self: &Arc<Self>, source: Source) -> Result<CapturedDocument, Error> {
        self.prepare_named_class(source, &self.structure.root_class().name)
    }
    /// Reuse one captured environment schema for independent function/CT sources.
    /// A selected class cannot bypass its schema-version gate.
    pub fn prepare_named_class(
        self: &Arc<Self>,
        source: Source,
        class_name: &str,
    ) -> Result<CapturedDocument, Error> {
        if class_name.len() > self.limits.identity_bytes {
            return Err(Error::Limit("class_name"));
        }
        let class = self
            .structure
            .class_named(class_name)
            .ok_or_else(|| Error::UnknownClass(class_name.into()))?;
        if class
            .fields
            .iter()
            .any(|field| field.name == "schema_version")
        {
            return Err(Error::VersionedRootRequired);
        }
        let raw = self.decode_entry(&source)?;
        let mut budget = NormalizationBudget::new(self.limits.normalization);
        let types = self
            .structure
            .parse_query_types(&[class_name.into()], budget.validation_scope())
            .map_err(Error::Validation)?;
        let normalized = self
            .structure
            .normalize_types(
                &types,
                &raw.document,
                raw.document.root(),
                false,
                &mut budget,
            )
            .map_err(|error| self.normalization_failure(&source, &raw.document, error))?;
        Ok(CapturedDocument {
            schema: Arc::clone(self),
            class_name: class_name.into(),
            source,
            raw,
            normalized,
        })
    }

    /// Structural preparation only: no source data, executable plan or effects.
    /// Presence of `parents`, including null, must use the inheritance lifecycle.
    pub fn prepare_standalone(self: &Arc<Self>, source: Source) -> Result<PreparedDocument, Error> {
        let raw = self.decode_entry(&source)?;
        self.prepare_standalone_decoded(source, raw)
    }
    fn decode_entry(&self, source: &Source) -> Result<DecodedYaml, Error> {
        if source.bytes.len() > self.limits.captured_bytes {
            return Err(Error::Limit("captured_bytes"));
        }
        if source.identity.len() > self.limits.identity_bytes {
            return Err(Error::Limit("identity_bytes"));
        }
        decode_yaml(&source.bytes, self.limits.decode).map_err(|error| Error::Decode {
            identity: source.identity.clone(),
            error,
        })
    }
    fn prepare_standalone_decoded(
        self: &Arc<Self>,
        source: Source,
        raw: DecodedYaml,
    ) -> Result<PreparedDocument, Error> {
        if raw.document.field(raw.document.root(), "parents").is_some() {
            return Err(Error::InheritanceRequired);
        }
        let mut budget = NormalizationBudget::new(self.limits.normalization);
        let normalized = self
            .structure
            .normalize_document(&raw.document, &mut budget)
            .map_err(|error| self.normalization_failure(&source, &raw.document, error))?;
        let expanded = self
            .structure
            .expand_named_windows(&normalized.document, true, &mut budget)
            .map_err(|error| self.normalization_failure(&source, &normalized.document, error))?;
        let origins = expanded
            .origins
            .iter()
            .map(|&id| normalized.origins[id])
            .collect();
        let model = SpecificationDocument::admit(expanded.document, budget.validation_scope())
            .map_err(Error::Validation)?
            .map_err(|findings| {
                Error::Findings(Box::new(CapturedFindings {
                    schema: Arc::clone(self),
                    source: source.clone(),
                    document: None,
                    findings,
                }))
            })?;
        Ok(PreparedDocument {
            schema: Arc::clone(self),
            source,
            raw,
            content: PreparedContent::Standalone {
                model,
                origins,
                windows: expanded.references,
            },
            parents: Vec::new(),
        })
    }

    fn normalization_failure(
        self: &Arc<Self>,
        source: &Source,
        document: &yamaa_core::schema::Document,
        error: NormalizationError,
    ) -> Error {
        match error {
            NormalizationError::Invalid(findings) => Error::Findings(Box::new(CapturedFindings {
                schema: Arc::clone(self),
                source: source.clone(),
                document: Some(document.clone()),
                findings,
            })),
            error => Error::Normalize(error),
        }
    }

    /// Select the shared preparation lifecycle from one decoded raw entry.
    /// Hosts never inspect YAML or retry standalone errors as inheritance.
    pub fn prepare_document<P: InheritancePort>(
        self: &Arc<Self>,
        source: Source,
        display_path: String,
        port: &mut P,
    ) -> Result<PreparedDocument, InheritanceError<P::Error>> {
        let raw = self
            .decode_entry(&source)
            .map_err(InheritanceError::Entry)?;
        if raw.document.field(raw.document.root(), "parents").is_some() {
            self.prepare_inherited_decoded(source, display_path, raw, port)
        } else {
            self.prepare_standalone_decoded(source, raw)
                .map_err(InheritanceError::Entry)
        }
    }
}

/// Retains every final occurrence's raw/schema-default origin and schema snapshot.
/// Construction is private; structural admission is never execution qualification.
#[derive(Debug)]
pub struct PreparedDocument {
    schema: Arc<CapturedSchema>,
    source: Source,
    raw: DecodedYaml,
    content: PreparedContent,
    parents: Vec<CapturedParent>,
}
#[derive(Debug)]
enum PreparedContent {
    Standalone {
        model: SpecificationDocument,
        origins: Vec<SchemaOrigin>,
        windows: Vec<WindowReference>,
    },
    Inherited(Box<yamaa_engine::inheritance_preparation::PreparedInheritance>),
}
impl PreparedDocument {
    pub fn schema(&self) -> &CapturedSchema {
        &self.schema
    }
    pub fn source(&self) -> &Source {
        &self.source
    }
    pub fn raw(&self) -> &DecodedYaml {
        &self.raw
    }
    pub fn model(&self) -> &SpecificationDocument {
        match &self.content {
            PreparedContent::Standalone { model, .. } => model,
            PreparedContent::Inherited(prepared) => prepared.model(),
        }
    }
    pub fn origins(&self) -> &[SchemaOrigin] {
        match &self.content {
            PreparedContent::Standalone { origins, .. } => origins,
            PreparedContent::Inherited(prepared) => prepared.origins(),
        }
    }
    pub fn windows(&self) -> &[WindowReference] {
        match &self.content {
            PreparedContent::Standalone { windows, .. } => windows,
            PreparedContent::Inherited(prepared) => prepared.windows(),
        }
    }
    /// Input occurrences in final origins address this retained document.
    pub fn normalization_input(&self) -> &yamaa_core::schema::Document {
        match &self.content {
            PreparedContent::Standalone { .. } => &self.raw.document,
            PreparedContent::Inherited(prepared) => prepared.normalization_input(),
        }
    }
    pub fn inheritance(
        &self,
    ) -> Option<&yamaa_engine::inheritance_preparation::PreparedInheritance> {
        match &self.content {
            PreparedContent::Standalone { .. } => None,
            PreparedContent::Inherited(prepared) => Some(prepared),
        }
    }
    /// Raw parent snapshots remain in first-capture order, separately from postorder layers.
    pub fn parents(&self) -> &[CapturedParent] {
        &self.parents
    }
    /// Borrow the contributing original layer for a diagnostic field. Logical
    /// descendants retain their nearest composed ancestor's source. A missing
    /// inheritance origin remains unavailable rather than inventing one.
    pub fn declaring_source(&self, path: &str) -> Option<&str> {
        match self.inheritance() {
            None => Some(&self.source.identity),
            Some(inherited) => {
                let origin = inherited
                    .provenance()
                    .iter()
                    .filter(|origin| {
                        path == origin.path
                            || path
                                .strip_prefix(&origin.path)
                                .is_some_and(|suffix| suffix.starts_with(['.', '[']))
                    })
                    .max_by_key(|origin| origin.path.len())?;
                Some(&inherited.layers().get(origin.layer)?.source.identity)
            }
        }
    }

    /// Resolve an input's authored path against held source provenance. Composition
    /// may have rebased the executable path; diagnostics must not disclose that
    /// spelling instead of the value written by the contributing layer.
    pub fn written_source_path(&self, dataset: &str) -> Option<&str> {
        self.written_input_origin(dataset, "path")
            .map(|p| p.written)
    }
    /// Retain the layer that authored each producer link independently from the
    /// layer that authored its artifact path. No source is reopened or resolved.
    pub fn written_input_origin(
        &self,
        dataset: &str,
        field: &str,
    ) -> Option<yamaa_core::producer_admission::WrittenPath<'_>> {
        if !["path", "schema"].contains(&field) {
            return None;
        }
        use yamaa_core::schema::DocumentNode;
        let (identity, raw) = self.authored_document(&format!("input.{dataset}.{field}"))?;
        let input = raw.field(raw.root(), "input")?;
        let source = raw.field(input, dataset)?;
        let node = match raw.nodes().get(source)? {
            DocumentNode::Text(_) if field == "path" => source,
            _ => raw.field(source, field)?,
        };
        match raw.nodes().get(node)? {
            DocumentNode::Text(path) => Some(yamaa_core::producer_admission::WrittenPath {
                declaring_source: identity,
                written: path,
            }),
            _ => None,
        }
    }
    /// The producer's diagnostic path also belongs to its contributing layer.
    pub fn written_output_origin(&self) -> Option<yamaa_core::producer_admission::WrittenPath<'_>> {
        self.written_output_field_origin("path")
    }
    /// Every governed output field retains its original atomic output layer.
    pub(crate) fn written_output_field_origin(
        &self,
        field: &str,
    ) -> Option<yamaa_core::producer_admission::WrittenPath<'_>> {
        if !["path", "verification_log", "warning_log"].contains(&field) {
            return None;
        }
        // Output is an atomic top-level field in shared layer composition.
        let (identity, raw) = self.authored_document("output")?;
        let output = raw.field(raw.root(), "output")?;
        let node = raw.field(output, field)?;
        match &raw.nodes()[node] {
            yamaa_core::schema::DocumentNode::Text(path) => {
                Some(yamaa_core::producer_admission::WrittenPath {
                    declaring_source: identity,
                    written: path,
                })
            }
            _ => None,
        }
    }
    fn authored_document(&self, path: &str) -> Option<(&str, &yamaa_core::schema::Document)> {
        if let Some(inherited) = self.inheritance() {
            let origin = inherited.provenance().iter().find(|p| p.path == path)?;
            let identity = &inherited.layers().get(origin.layer)?.source.identity;
            if identity == &self.source.identity {
                Some((identity.as_str(), &self.raw.document))
            } else {
                Some((
                    identity.as_str(),
                    &self
                        .parents
                        .iter()
                        .find(|p| &p.source().identity == identity)?
                        .raw()
                        .document,
                ))
            }
        } else {
            Some((self.source.identity.as_str(), &self.raw.document))
        }
    }
}
