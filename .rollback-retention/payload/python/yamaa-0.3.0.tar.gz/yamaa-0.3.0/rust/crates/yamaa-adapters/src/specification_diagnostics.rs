//! Portable compiler/ingestion diagnostics. This layer only represents findings;
//! it does not select a phase, bind a name, evaluate a formula or read a table.
use crate::{
    csv_source::{self, TextTableError},
    specification_run::Error,
};
use serde_json::{json, Value};
use yamaa_engine::specification::{
    BindError, BindFinding, PreflightFinding, PrepareError, SourceDeclaration,
};

fn diagnostic(
    phase: &str,
    condition: &str,
    requirement: Option<&str>,
    paths: Vec<String>,
    context: Value,
) -> Value {
    json!({"phase":phase,"condition":condition,"requirement":requirement,"spec_paths":paths,"context":context})
}
pub(crate) fn binding(error: &BindError, source: &SourceDeclaration) -> Option<Vec<Value>> {
    let BindError::Invalid(findings) = error else {
        return None;
    };
    let mut diagnostics = Vec::new();
    for finding in findings {
        diagnostics.extend(binding_finding(finding, source)?);
    }
    Some(diagnostics)
}
fn binding_finding(error: &BindFinding, source: &SourceDeclaration) -> Option<Vec<Value>> {
    error
        .diagnostics(source)?
        .into_iter()
        .map(portable_diagnostic)
        .collect()
}
/// Represent the core-owned finding without assigning semantic vocabulary here.
fn preparing(error: &PreflightFinding) -> Option<Value> {
    portable_diagnostic(error.diagnostic())
}

/// The original-document report shape retains ordinary JSON context values.
/// Geometry is retained by the core diagnostic and projected by the report contract.
pub(crate) fn portable_diagnostic(finding: yamaa_core::diagnostic::Diagnostic) -> Option<Value> {
    portable_definition(finding.definition(), finding.spec_paths, finding.context)
}
/// Submission findings retain their core-owned definition until their causes
/// join the closed cause registry; serialization assigns no semantic vocabulary.
pub(crate) fn portable_definition(
    definition: yamaa_core::diagnostic::Definition,
    paths: Vec<String>,
    context: yamaa_core::diagnostic::Context,
) -> Option<Value> {
    fn value(cell: yamaa_core::diagnostic::ContextValue) -> Option<Value> {
        use yamaa_core::{diagnostic::ContextValue as C, value::Value as S};
        Some(match cell {
            C::Sequence(values) => {
                Value::Array(values.into_iter().map(value).collect::<Option<_>>()?)
            }
            C::Integer(integer) => Value::Number(integer.parse().ok()?),
            C::Scalar(scalar) => match scalar {
                S::Missing => Value::Null,
                S::Str(v) => json!(v),
                S::Int(v) => json!(v),
                S::Float(v) => json!(v.get()),
                S::Bool(v) => json!(v),
                S::Date(v) => json!(v.to_string()),
                S::DateTime(v) => json!(v.to_string()),
            },
        })
    }
    let context = context
        .into_iter()
        .map(|(name, v)| Some((name, value(v)?)))
        .collect::<Option<serde_json::Map<_, _>>>()?;
    Some(diagnostic(
        definition.phase,
        definition.condition,
        definition.requirement,
        paths,
        context.into(),
    ))
}
/// Return semantic findings only. Policy/transport/internal errors deliberately
/// have no fabricated language condition and must remain host boundary failures.
/// Unbounded owned compatibility; new callers use findings_with_limit to distinguish
/// explicit projection refusal from an opaque boundary error before removal.
pub fn findings(error: &Error, source: Option<&SourceDeclaration>) -> Option<Vec<Value>> {
    match error {
        Error::Sources(errors) => {
            let mut result = Vec::new();
            for (source, error) in errors {
                result.extend(findings(error, Some(source))?);
            }
            Some(result)
        }
        Error::Prepare(PrepareError::Invalid(errors)) => errors.iter().map(preparing).collect(),
        Error::Bind(error) => binding(error, source?),
        Error::ParquetSource(error) => {
            let source = source?;
            Some(vec![portable_diagnostic(
                error.diagnostic(&source.name, &source.path)?,
            )?])
        }
        Error::TypedSource(crate::typed_csv::Error::Typing(error)) => {
            Some(vec![portable_diagnostic(error.diagnostic(&source?.name)?)?])
        }
        Error::Source(TextTableError::Csv(error)) => {
            let source = source?;
            Some(vec![portable_diagnostic(
                error.diagnostic(&source.name, &source.path)?,
            )?])
        }
        _ => None,
    }
}
/// Complete ingestion reports are admitted in core before copying codec facts.
/// Other existing preparation/binding projections retain their admission policy.
pub fn findings_with_limit(
    error: &Error,
    source: Option<&SourceDeclaration>,
    maximum: usize,
) -> Result<Option<Vec<Value>>, crate::source_diagnostics::SourceProjectionError> {
    match error {
        Error::Sources(_) | Error::ParquetSource(_) | Error::TypedSource(_) | Error::Source(_) => {
            Ok(
                crate::source_diagnostics::findings_with_limit(error, source, maximum)?.and_then(
                    |findings| {
                        findings
                            .into_iter()
                            .map(portable_diagnostic)
                            .collect::<Option<Vec<_>>>()
                    },
                ),
            )
        }
        Error::Prepare(PrepareError::Invalid(errors)) => Ok(errors.iter().map(preparing).collect()),
        Error::Bind(error) => Ok(source.and_then(|source| binding(error, source))),
        _ => Ok(None),
    }
}

/// Experimental host boundary reply. Semantic findings stay separate from
/// unsupported vocabulary and resource/internal rejection; no Debug text leaks.
/// This envelope is not the final whole-run conformance report.
pub fn failure(error: &Error, source: Option<&SourceDeclaration>) -> String {
    let projected =
        findings_with_limit(error, source, yamaa_core::diagnostic::MAX_PROJECTION_BYTES);
    let outcome = if let Err(error) = projected {
        let code = match error {
            crate::source_diagnostics::SourceProjectionError::TraversalLimit => {
                "diagnostic_traversal_limit"
            }
            crate::source_diagnostics::SourceProjectionError::Context(
                yamaa_core::diagnostic::ProjectionError::Limit,
            ) => "diagnostic_context_limit",
            crate::source_diagnostics::SourceProjectionError::Context(
                yamaa_core::diagnostic::ProjectionError::InvalidContext,
            ) => "diagnostic_context",
        };
        json!({"status":"rejected","stage":"ingest","code":code})
    } else if let Ok(Some(diagnostics)) = projected {
        json!({"status":"invalid","diagnostics":diagnostics})
    } else if let Error::Prepare(PrepareError::Unsupported(features)) = error {
        json!({"status":"unsupported","features":features.iter().map(|f| json!({"operation":f.operation,"spec_path":f.path})).collect::<Vec<_>>()})
    } else {
        let (stage, code) = match error {
            Error::Prepare(PrepareError::Limit(_)) => ("prepare", "compiler_limit"),
            Error::Prepare(PrepareError::Numeric { .. }) => ("prepare", "numeric_policy"),
            Error::Prepare(PrepareError::OutputSchema(_)) => ("prepare", "output_schema"),
            Error::Prepare(_) => ("prepare", "internal"),
            Error::Source(TextTableError::Csv(csv_source::Error::Limit { .. })) => {
                ("ingest", "csv_limit")
            }
            Error::Source(TextTableError::Table(crate::arrow_table::TableError::Limit {
                ..
            })) => ("ingest", "table_limit"),
            Error::Source(_) => ("ingest", "internal"),
            Error::TypedSource(_) => ("ingest", "source_boundary"),
            Error::ParquetSource(crate::parquet_source::Error::Limit) => {
                ("ingest", "parquet_limit")
            }
            Error::ParquetSource(crate::parquet_source::Error::Unavailable { .. }) => {
                ("ingest", "parquet_codec_unavailable")
            }
            Error::ParquetSource(_) => ("ingest", "parquet_boundary"),
            Error::Bind(BindError::Catalog(_)) => ("bind", "reference_catalog"),
            Error::Bind(BindError::DependencyPolicy(_)) => ("bind", "dependency_policy"),
            Error::Bind(BindError::SourceCount) => ("bind", "source_count"),
            Error::Bind(BindError::PredicateDiagnosticLimit) => {
                ("bind", "predicate_diagnostic_limit")
            }
            Error::Bind(_) => ("bind", "internal"),
            Error::Execution(error) if error.is_internal() => ("execute", "internal"),
            Error::Execution(_) => ("execute", "execution_boundary"),
            Error::Sources(_) => ("ingest", "source_collection_boundary"),
        };
        json!({"status":"rejected","stage":stage,"code":code})
    };
    json!({"protocol":"specification/prototype","outcome":outcome}).to_string()
}

fn capture_response(outcome: Value) -> String {
    crate::yaml_transport::encode_outcome("specification/prototype", outcome, 16_777_216)
        .unwrap_or_else(|_| json!({"protocol":"specification/prototype","outcome":{"status":"rejected","stage":"capture","code":"diagnostic_context_limit"}}).to_string())
}
/// Preparation exposes semantic context, never an arbitrary dump of source bytes.
/// Findings resolve against the retained schema/pass input or the shared YAML decoder.
pub fn capture_failure(error: &crate::specification_source::Error) -> String {
    use crate::specification_source::Error;
    if let Error::Decode { identity, error } = error {
        if let Some(mut diagnostics) = crate::yaml_transport::semantic_diagnostics(error) {
            for finding in &mut diagnostics {
                finding["phase"] = json!("validation");
                finding["requirement"] = Value::Null;
                if finding["condition"] == "non_ascii_source" {
                    finding["context"]["path"] = json!(identity);
                }
            }
            return capture_response(json!({"status":"invalid","diagnostics":diagnostics}));
        }
    }
    if let Error::Findings(captured) = error {
        return match captured_schema::findings(captured) {
            Ok(diagnostics) => {
                capture_response(json!({"status":"invalid","diagnostics":diagnostics}))
            }
            Err(error) => {
                let code = match error {
                    captured_schema::Error::Limit => "diagnostic_context_limit",
                    captured_schema::Error::InvalidContext => "diagnostic_context",
                };
                capture_response(json!({"status":"rejected","stage":"capture","code":code}))
            }
        };
    }
    let code = match error {
        Error::Limit(_) => "capture_limit",
        Error::Decode { .. } => "yaml_decode",
        Error::Bundle(_) => "schema_bundle",
        Error::Normalize(_) => "normalization",
        Error::Validation(_) => "validation_policy",
        Error::Findings(_) => unreachable!("handled captured findings"),
        Error::InheritanceRequired => "inheritance_required",
        Error::VersionedRootRequired => "versioned_root_required",
        Error::UnknownClass(_) => "unknown_class",
    };
    capture_response(json!({"status":"rejected","stage":"capture","code":code}))
}

pub(crate) fn type_name(kind: yamaa_core::value::ColumnType) -> &'static str {
    use yamaa_core::value::ColumnType::*;
    match kind {
        Str => "str",
        Int => "int",
        Float => "float",
        Date => "date",
        DateTime => "datetime",
    }
}

#[path = "specification_inheritance_diagnostics.rs"]
mod inherited;
pub use inherited::failure as inheritance_failure;
pub use inherited::failure_ref as inheritance_failure_ref;

#[path = "specification_schema_diagnostics.rs"]
mod captured_schema;

pub(crate) use captured_schema::{Budget as CapturedBudget, Error as CapturedProjectionError};
/// Reuse the same held schema/input resolver with an aggregate caller-owned budget.
pub(crate) fn captured_findings(
    captured: &crate::specification_source::CapturedFindings,
    source_context: &[(&str, &str)],
    budget: &mut CapturedBudget,
) -> Result<Vec<Value>, CapturedProjectionError> {
    captured_schema::schema_findings_with_budget(
        captured.schema().structure(),
        captured.document(),
        captured.findings(),
        source_context,
        budget,
    )
}
