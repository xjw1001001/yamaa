"""Replay exact prior-release fixtures after a fresh retained-wheel reinstall."""

import argparse
import gc
import importlib.metadata
import json
import platform
import shutil
import sys
import tarfile
import zipfile
from pathlib import Path, PurePosixPath

KIT = Path(__file__).resolve().parent
PROOF = KIT / "reinstall-proof"
SOURCE = "845a91ff9ba4ab6599efbd79fafe1c4e1dd14255"
WHEEL = "yamaa-0.3.0-cp312-abi3-linux_x86_64.whl"
CASES = {
    "schema-lookup": "adsl.csv",
    "adam-adlb-ordered-sum": "adlb.csv",
    "schema-window-functions": "advs.csv",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--form", choices=("wheel", "source"), default="wheel")
    args = parser.parse_args()
    proof = KIT / ("reinstall-proof" if args.form == "wheel" else "source-reinstall-proof")
    wheel_path = KIT / WHEEL if args.form == "wheel" else KIT / "source-rebuild" / WHEEL
    environment_name = "python-rollback-rehearsal-env" if args.form == "wheel" else "python-rollback-source-env"
    # No study bytes are extracted or read before the installed version check.
    distribution = importlib.metadata.distribution("yamaa")
    assert distribution.version == "0.3.0", distribution.version
    assert platform.python_version() == "3.12.14", platform.python_version()
    assert Path(sys.prefix).name == environment_name
    assert platform.system() == "Linux" and platform.machine() == "x86_64"
    installed = Path(distribution.locate_file("")).resolve()
    assert installed.is_relative_to(Path(sys.prefix).resolve())
    members = 0
    if args.form == "source":
        direct = json.loads(distribution.read_text("direct_url.json"))
        assert direct["url"] == (KIT / "yamaa-0.3.0.tar.gz").as_uri()
    with zipfile.ZipFile(wheel_path) as wheel:
        for member in wheel.infolist():
            if member.is_dir() or member.filename.endswith("/RECORD"):
                continue
            name = PurePosixPath(member.filename)
            assert not name.is_absolute() and ".." not in name.parts
            assert distribution.locate_file(member.filename).read_bytes() == wheel.read(member)
            members += 1
    assert members > 10
    proof.mkdir(exist_ok=False)
    version = {
        "source_tag": "yamaa-py-0.3.0",
        "source_revision": SOURCE,
        "association": "source-built prior-release package; no published binary asset",
        "installed_form": args.form,
        "runtime_version": platform.python_version(),
        "package_version": distribution.version,
        "package_location": str(installed / "yamaa"),
        "wheel_name": WHEEL,
        "wheel_bytes": wheel_path.stat().st_size,
        "installed_wheel_members_compared": members,
        "version_checked_before_study_data": True,
        "system": platform.system(),
        "machine": platform.machine(),
    }
    if args.form == "source":
        version["source_distribution"] = "yamaa-0.3.0.tar.gz"
        version["source_distribution_bytes"] = (KIT / "yamaa-0.3.0.tar.gz").stat().st_size
        version["build_toolchain"] = "Rust 1.90.0; maturin 1.9.6; locked Cargo; optimized release"
        version["build_log"] = "source-rebuild.log"
    (proof / "version-before-study-data.json").write_text(json.dumps(version, indent=2) + "\n")
    prior = proof / "prior-inputs"
    with tarfile.open(KIT / "yamaa-reference-845a91ff.tar.gz") as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            if len(parts) < 2:
                continue
            path = PurePosixPath(*parts[1:])
            selected = path.parts[0] == "yaml" or (
                len(path.parts) > 1 and path.parts[0] == "benchmarks" and path.parts[1] in CASES
            ) or path.as_posix() == "python/uv.lock"
            if not selected or member.isdir():
                continue
            assert member.isfile() and not path.is_absolute() and ".." not in path.parts
            target = prior / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.extractfile(member).read())
    assert (prior / "python/uv.lock").read_bytes() == (KIT / "uv.lock").read_bytes()
    import yamaa

    assert yamaa.__version__ == "0.3.0"
    assert Path(yamaa.__file__).resolve().is_relative_to(installed)
    reports = []
    for name, output_name in CASES.items():
        authored = prior / "benchmarks" / name
        expected = (authored / "expected" / output_name).read_bytes()
        case = proof / "execution" / name
        shutil.copytree(authored, case, ignore=shutil.ignore_patterns("expected"))
        built = yamaa.yamaa_domain(case / "spec.yaml", schema_root=prior / "yaml")
        assert built.output is not None and built.issues.is_empty(), built.issues
        output_before = built.output
        (proof / name).mkdir()
        output_before.write_ipc(proof / name / "output-before-save.arrow")
        built.issues.write_ipc(proof / name / "issues.arrow")
        # The old result owns its successful table after inputs/specification vanish.
        shutil.rmtree(case)
        gc.collect()
        destinations = [proof / name / ("first-" + output_name), proof / name / ("second-" + output_name)]
        for destination in destinations:
            assert built.save(destination) == destination.resolve()
            assert destination.read_bytes() == expected
        assert built.output.equals(output_before)
        (proof / name / "committed-expected.csv").write_bytes(expected)
        reports.append({
            "case": name,
            "truth_source_revision": SOURCE,
            "truth_path": f"benchmarks/{name}/expected/{output_name}",
            "result": "pass",
            "rows": output_before.height,
            "columns": list(output_before.columns),
            "expected_bytes": len(expected),
            "saves": 2,
            "input_and_spec_removed_before_saves": True,
            "output_unchanged_after_saves": True,
        })
    receipt = {**version, "rehearsal": "pass", "cases": reports,
               "scope": "fresh Linux x86_64 CPython 3.12.14 retained prior " + args.form + " reinstall",
               "remaining_scope": ["other platform/interpreter/form tuples", "full producer graph Save baseline", "durable retrievable published pin", "transition approval"]}
    (proof / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(f"Prior Python 0.3.0 fresh {args.form} reinstall passed {len(reports)} committed cases and six post-input-removal Saves.")


if __name__ == "__main__":
    main()
