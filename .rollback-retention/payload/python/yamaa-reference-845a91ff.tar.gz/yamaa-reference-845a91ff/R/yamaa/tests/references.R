library(yamaa)
read_truth <- function(name) read.delim(system.file(name, package = "yamaa"),
  sep = "\t", quote = "", comment.char = "", colClasses = "character",
  fileEncoding = "UTF-8", check.names = FALSE)
truth <- rbind(read_truth("reference_binding.tsv"), read_truth("reference_scope.tsv"),
  read_truth("reference_intermediate.tsv"), read_truth("reference_keys.tsv"),
  read_truth("reference_match_values.tsv"), read_truth("reference_relations.tsv"))
stopifnot(identical(reference_capabilities(),
  '{"protocol":"reference-analysis/1","features":["binding","output_validation","qualified_validation","intermediate_validation","key_relations","match_value_typing","relation_binding"]}'))
for (i in seq_len(nrow(truth))) {
  for (attempt in 1:2) stopifnot(identical(analyze_references(truth$request[i]), truth$expected[i]))
}
for (request in list(NA_character_, character(), c("a", "b"), 1, NULL,
  '{"protocol":"reference-analysis/1","catalog":{"outputs":[{"name":"X","type":"bool"}],"datasets":[]},"queries":[]}',
  '{"protocol":"reference-analysis/1","catalog":{"outputs":[{"name":"X","type":"int"},{"name":"X","type":"str"}],"datasets":[]},"queries":[]}',
  '{"protocol":"reference-analysis/1","catalog":{"outputs":[],"datasets":[]},"queries":[{"kind":"validate_output","name":"X","expected":null,"available":null,"candidates":[0]}]}')) {
  stopifnot(inherits(tryCatch(analyze_references(request), error = identity), "error"))
}
query <- '{"kind":"bind","name":"X"}'
request <- paste0('{"protocol":"reference-analysis/1","catalog":{"outputs":[],"datasets":[]},"queries":[',
  paste(rep(query, 4097L), collapse = ","), "]}")
stopifnot(identical(analyze_references(request),
  '{"protocol":"reference-analysis/1","outcome":{"status":"limit","resource":"queries","limit":"4096","required":"4097"}}'))
stopifnot(identical(analyze_references(truth$request[1L]), truth$expected[1L]))
stopifnot(identical(engine_info()$execution_supported, FALSE))
