# Classify a Result, Its Shift from Baseline, and Two Criteria

[![Dashboard](https://img.shields.io/badge/Dashboard-view-1f3a5c)](https://elong0527.github.io/yamaa/benchmark/adam-adlb-shift-criteria.html)
[![Lifecycle: draft](https://img.shields.io/badge/Lifecycle-draft-lightgrey)](https://github.com/elong0527/yamaa/blob/main/benchmarks/README.md#lifecycle)

**Goal:** derive `ANRIND`, `BASE`, `BNRIND`, `SHIFT1`, `R2BASE`,
`CRIT1`, `CRIT1FL`, `CRIT2`, and `CRIT2FL`: mark where each analysis
value sits against its normal range, how that mark moved since
baseline, and whether the record met a high-result criterion or a
low-result criterion.

**Input:** laboratory records carrying the analysis value `AVAL`, the
normal range limits `ANRLO` and `ANRHI`, and the baseline flag
`ABLFL` (`Y` on the record taken as the baseline for the subject
and parameter).

**Variables:**

- `ANRIND` is the record's own mark: `LOW` below `ANRLO`, `HIGH`
  above `ANRHI`, and `NORMAL` between them, limits included, so a
  result exactly at a limit reads `NORMAL`; empty when `AVAL`,
  `ANRLO`, or `ANRHI` is missing, since one missing limit makes the
  mark unclassifiable.
- `BASE` repeats the baseline record's `AVAL` on every record of the
  subject and parameter; empty when no record carries the flag.
- `BNRIND` repeats the baseline record's `ANRIND` the same way;
  empty with no flagged baseline, or when the baseline record
  itself could not be marked.
- `SHIFT1` joins the baseline mark and the record's own mark, baseline
  first, so a result that stayed normal reads `NORMAL to NORMAL` and
  one that moved out of range reads `NORMAL to HIGH`; empty when
  either mark is missing - the record's own or the baseline's.
- `R2BASE` divides `AVAL` by `BASE`, so the baseline record itself
  reads 1 when the ratio can be computed; empty when `AVAL` is
  missing, when there is no baseline, and when the baseline is zero
  since the multiple is not defined there.
- `CRIT1` states the criterion the record was assessed against, a
  result greater than three times the upper limit of normal (ULN):
  `Result greater than 3 x ULN`; empty when `AVAL` or `ANRHI` is
  missing, since the comparison cannot be made.
- `CRIT1FL` says whether the record met it, `Y` or `N`; empty where it
  could not be assessed, which differs from assessed and not met.
  A result exactly at three times the limit does not meet it - the
  comparison is strictly greater than.

- `CRIT2` states the second criterion the record was assessed
  against, a result less than the lower limit of normal (LLN):
  `Result less than LLN`; empty when `AVAL` or `ANRLO` is missing,
  since the comparison cannot be made. It is assessed independently
  of the first: a record whose upper limit is missing can still
  meet the low criterion.
- `CRIT2FL` says whether the record met it, `Y` or `N`; empty where
  it could not be assessed. A result exactly at the lower limit
  does not meet it - the comparison is strictly less than.

**Note:** the shift joins the baseline mark with the record's own
mark and the ratio rests on the flagged baseline value, while the
mark and the criteria rest on the record's own value and limits;
each criterion text and its flag always arrive together, as do the mark
and the shift. A record that breaks these pairings stops the run, and
no output is written.

**Standard:** ADaM | **Domain:** ADLB
