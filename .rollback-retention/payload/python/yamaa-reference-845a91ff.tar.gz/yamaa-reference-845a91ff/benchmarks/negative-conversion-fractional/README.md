# Reject Fractional Pulse

[![Dashboard](https://img.shields.io/badge/Dashboard-view-1f3a5c)](https://elong0527.github.io/yamaa/benchmark/negative-conversion-fractional.html)
[![Lifecycle: reviewed](https://img.shields.io/badge/Lifecycle-reviewed-yellow)](https://github.com/elong0527/yamaa/blob/main/benchmarks/README.md#lifecycle)

**Goal:** derive `AVAL` from the collected pulse rate.

**Input:** collected vital signs (VS) records carrying `VSTESTCD`
and `VSSTRESN`; one record carries a fractional pulse rate.

**Variables:**

- `AVAL` would be the collected result from `VSSTRESN`, held as a
  whole number. A fractional result has no whole-number form unless a
  rounding rule is stated, so the run fails and no artifact is accepted.

**Standard:** ADaM | **Domain:** ADVS

## How to fix

If fractional pulse rates are valid for the analysis, preserve the collected
precision by declaring the result as `float`:

```yaml
- name: AVAL
  type: float
  derivation:
    source: VS.VSSTRESN
```

If the result must be an integer, the specification must choose an explicit
rule, such as `round_half_away_from_zero` with `digits: 0`, or `FLOOR`,
`CEIL`, or `TRUNC` in a `compute` expression; conversion will not choose a
rounding rule implicitly.
