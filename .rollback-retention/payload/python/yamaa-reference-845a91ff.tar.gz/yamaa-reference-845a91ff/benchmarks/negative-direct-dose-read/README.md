# Reject Uncomputed Dose

[![Dashboard](https://img.shields.io/badge/Dashboard-view-1f3a5c)](https://elong0527.github.io/yamaa/benchmark/negative-direct-dose-read.html)
[![Lifecycle: reviewed](https://img.shields.io/badge/Lifecycle-reviewed-yellow)](https://github.com/elong0527/yamaa/blob/main/benchmarks/README.md#lifecycle)

**Goal:** double the administered exposure dose in `DOSEDBL` for
each subject.

**Input:** a subject-treatment inventory carrying `EXTRT` with
matching exposure records carrying the exposure sequence number
and `EXDOSE`.

**Variables:**

- `DOSEDBL` would contain twice the exposure dose (`EXDOSE * 2`)
  for the subject. A subject can have several exposure records, so
  a formula naming `EX.EXDOSE` does not say which record it means,
  and choosing one without a stated rule, or totalling them, would
  each give a different result. A formula computes only from values
  the output row already carries, and a value taken from another
  source is bound to one of those first, so the run is rejected
  before any data is read and no artifact is accepted.

**Standard:** ADaM | **Domain:** ADEX

## How to fix

Choose the exposure record explicitly, bind its dose to an output column,
and then compute from the unqualified column. For example, to use the
earliest administration:

```yaml
- name: DOSE
  type: float
  derivation:
    source:
      variable: EX.EXDOSE
      order_by: [EX.EXSEQ]
      keep: first

- name: DOSEDBL
  type: float
  derivation:
    compute:
      expr: "DOSE * 2"
```

Keep `DOSE` internal by omitting it from `output.columns`.

If the intended value is cumulative dose instead, use a qualified
`aggregate` rather than selecting one record.
