# Reject Self-Named Treatment

[![Dashboard](https://img.shields.io/badge/Dashboard-view-1f3a5c)](https://elong0527.github.io/yamaa/benchmark/negative-lookup-id-collision.html)
[![Lifecycle: reviewed](https://img.shields.io/badge/Lifecycle-reviewed-yellow)](https://github.com/elong0527/yamaa/blob/main/benchmarks/README.md#lifecycle)

**Goal:** carry the first treatment received in `TRT01A`, one
record per subject.

**Input:** demographics records plus exposure records carrying the
administration sequence number (`EXSEQ`), the treatment name
(`EXTRT`), and the administration start date (`EXSTDTC`).

**Variables:**

- `TRT01A` would contain the treatment name from the earliest
  exposure record.

**Note:** the chosen record is named `EX`, which already names the
exposure records, so a read of `EX.EXTRT` cannot say whether it
means the treatment of the chosen record or of every exposure
record. The two readings differ whenever a subject has more than one
administration. The name itself is rejected before any data is
read, so no artifact is accepted.

**Standard:** ADaM | **Domain:** ADSL

## How to fix

Give the record lookup a name that is distinct from every dataset and from
the output domain, then read through that name:

```yaml
intermediates:
  - id: FIRSTEX
    dataset: EX
    order_by: [EX.EXSTDTC, EX.EXSEQ]
    keep: first

# ...
derivation:
  source: FIRSTEX.EXTRT
```
