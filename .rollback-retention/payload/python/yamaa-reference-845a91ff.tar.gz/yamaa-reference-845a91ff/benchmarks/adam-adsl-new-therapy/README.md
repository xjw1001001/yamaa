# Derive the new anti-cancer therapy start date

[![Dashboard](https://img.shields.io/badge/Dashboard-view-1f3a5c)](https://elong0527.github.io/yamaa/benchmark/adam-adsl-new-therapy.html)
[![Lifecycle: reviewed](https://img.shields.io/badge/Lifecycle-reviewed-yellow)](https://github.com/elong0527/yamaa/blob/main/benchmarks/README.md#lifecycle)

**Goal:** derive the start date of new anti-cancer therapy given during
the study (`NACTDT`), its study day relative to the start of study
treatment (`NACTDY`), and a flag marking subjects who started such
therapy (`NACTFL`).

**Input:** one subject-level table carrying the treatment start date
`TRTSDT`, alongside concomitant medication records carrying a category
(`CMCAT`) and start date (`CMSTDTC`), plus procedure records carrying a
category (`PRCAT`), subcategory (`PRSCAT`), and start date (`PRSTDTC`).

**Variables:**

- `NACTDT` is the earlier of the first qualifying medication start
  (`CMSTDTC` with `CMCAT` equal to `ON TREATMENT`) and the first
  qualifying procedure start (`PRSTDTC` with `PRCAT` equal to `CANCER
  RELATED` and `PRSCAT` equal to `ON TREATMENT`); it is absent when the
  subject started no qualifying therapy during the study. Therapy
  recorded as `PRIOR TREATMENT` does not qualify, nor do procedures
  given for reasons other than the cancer. A qualifying record with no
  start date is skipped, and one that starts on the treatment start
  date itself counts, with study day 1.
- `NACTDY` is the study day of `NACTDT` counted from `TRTSDT`, with the
  treatment start date itself as day 1; it is absent when `NACTDT` is
  absent.
- `NACTFL` holds `Y` when `NACTDT` is present and is absent
  otherwise.

**Note:** a qualifying therapy must start on or after the treatment start
date: each aggregate only considers records with `CMSTDTC_IMP >= TRTSDT` (or
`PRSTDTC >= TRTSDT`), so a flagged therapy start always falls on or after
the treatment start date by construction.

**Note:** the collected medication start `CMSTDTC` is text and may carry a
partial date. The analysis-ready `CMSTDTC_IMP` completes it under a stated
rule: a year-month start is completed to the 15th of that month, and a full
date passes through unchanged. Subject 107's `2025-04` becomes `2025-04-15`.

**Standard:** ADaM | **Domain:** ADSL
