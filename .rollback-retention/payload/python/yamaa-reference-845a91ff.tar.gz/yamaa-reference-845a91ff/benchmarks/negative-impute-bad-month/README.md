# Reject Impossible Month

[![Dashboard](https://img.shields.io/badge/Dashboard-view-1f3a5c)](https://elong0527.github.io/yamaa/benchmark/negative-impute-bad-month.html)
[![Lifecycle: reviewed](https://img.shields.io/badge/Lifecycle-reviewed-yellow)](https://github.com/elong0527/yamaa/blob/main/benchmarks/README.md#lifecycle)

**Goal:** complete the analysis start date (`ASTDT`) of each
adverse event (AE) from the collected start (`AESTDTC`), supplying
a month and a day wherever the collected text does not already
carry them.

**Input:** collected event records carrying the reported term
(`AETERM`) and the collected start (`AESTDTC`).

**Variables:**

- `ASTDT` would be the analysis start date completed from
  `AESTDTC` to the earliest date the collected text still allows,
  with `15` as the supplied month and `1` as the supplied day. A
  year and month without a day would be completed, a year alone
  would be completed from the supplied month and day, and a fully
  collected date would be used as collected. The value
  `15` is not a calendar month, so the run is rejected before any
  data is read and no artifact is accepted.

**Standard:** ADaM | **Domain:** ADAE

## How to fix

Use a calendar month from 1 through 12. Because this benchmark describes
earliest imputation, January is the consistent correction:

```yaml
date_impute:
  source: AE.AESTDTC
  month: 1
  day: 1
  minimum_source_precision: year
```

A year-and-month value such as `2023-06` then becomes `2023-06-01`, and a
year-only value such as `2023` becomes `2023-01-01`.
