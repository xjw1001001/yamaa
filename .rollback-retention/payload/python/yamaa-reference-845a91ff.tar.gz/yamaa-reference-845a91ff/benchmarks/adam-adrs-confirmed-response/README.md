# Confirmed Response

[![Dashboard](https://img.shields.io/badge/Dashboard-view-1f3a5c)](https://elong0527.github.io/yamaa/benchmark/adam-adrs-confirmed-response.html)
[![Lifecycle: reviewed](https://img.shields.io/badge/Lifecycle-reviewed-yellow)](https://github.com/elong0527/yamaa/blob/main/benchmarks/README.md#lifecycle)

**Goal:** derive the confirmation flag `CONFIRMED` for tumor
response assessments.

**Input:** response assessments within a subject, each with a
sequence number `RSSEQ`, a collection date `RSDTC`, and a
standardized result `RSSTRESC`.

**Variables:**

- `CONFIRMED`: `Y` when the analysis result `AVALC` is progressive
  disease (`PD`), which needs no confirmation, or when a partial
  (`PR`) or complete (`CR`) response is followed at least 28 days
  later by another partial or complete response; `N` when the current
  assessment has no result, or when the next response is too early,
  is not a response, or does not exist. Each assessment is compared
  with the next one in analysis date `ADT` order within a subject.

**Note:** assessments sharing a date are ordered by sequence
number `RSSEQ`: the higher-numbered one is the next assessment for
the lower-numbered one, zero days later, so it never confirms it.

**Standard:** ADaM | **Domain:** ADRS
