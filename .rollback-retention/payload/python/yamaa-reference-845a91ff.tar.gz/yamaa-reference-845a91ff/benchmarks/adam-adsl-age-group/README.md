# Pool Subjects into Age Groups

[![Dashboard](https://img.shields.io/badge/Dashboard-view-1f3a5c)](https://elong0527.github.io/yamaa/benchmark/adam-adsl-age-group.html)
[![Lifecycle: finalized](https://img.shields.io/badge/Lifecycle-finalized-brightgreen)](https://github.com/elong0527/yamaa/blob/main/benchmarks/README.md#lifecycle)

**Goal:** carry each subject's collected age (`AGE`) and age units
(`AGEU`), and derive `AGEGR1` and `AGEGR1N` to pool subjects into age
groups.

**Input:** demographics (DM) records carrying age (`AGE`) and age
units (`AGEU`).

**Variables:**

- `AGEGR1` is the pooled group: `<18` when age is below 18, `18-64`
  when age is 18 through 64 inclusive, and `>64` when age is above
  64; `Missing` when `AGE` is missing.
- `AGEGR1N` is the numeric rank of `AGEGR1`: `1` for `<18`, `2` for
  `18-64`, and `3` for `>64`; empty when `AGE` is missing.

**Note:** both variables share the same bands, so the number always
matches the text for each subject. A subject aged exactly 18 or 64
falls in `18-64`: boundary ages belong to the middle band.

**Standard:** ADaM | **Domain:** ADSL
