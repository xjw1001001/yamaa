#!/usr/bin/env python3
"""Generate self-contained benchmark dashboards from repository fixtures."""

import argparse
import csv
import html
import json
import re
import sys
from pathlib import Path
from string import Template
from urllib.parse import quote, urlsplit

import yaml
from markdown_it import MarkdownIt


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import mapping_doc

ROOT = HERE.parents[2]
BENCHMARKS = ROOT / "benchmarks"
DESTINATION = ROOT / "docs/benchmark"
# The gallery's prose is authored as a documentation page, beside the other
# articles, rather than as a template buried with the generator: whoever
# writes the overview edits it where the rest of the documentation lives. It
# carries substitution placeholders, so MkDocs cannot render it on its own and
# `exclude_docs` in mkdocs.yml keeps it out of the built site; the generated
# docs/benchmark/index.md is the page readers see.
OVERVIEW = ROOT / "docs/articles/benchmark.md"
# The agent evaluation keeps each benchmark's prompts and its reference
# solutions written without yamaa, keyed by benchmark directory name. The
# dashboard shows them as assessment materials beside the comments.
HARBOR = ROOT / "evaluations/harbor"
# Most rules first, as evaluations/harbor/prompts/README.md defines the tiers.
PROMPT_TIERS = (
    ("full", "Full", "every rule an expected cell depends on"),
    ("conventions", "Conventions", "the sponsor's conventions only"),
    ("brief", "Brief", "the opening, columns, and paths only"),
)
SOLUTION_FILES = ("result.R", "result.py", "result.sas")
# The review ask names the README's standard when it is one of these; other
# README standards (CDISC, TEST) read as "CDISC standards".
REVIEW_STANDARDS = ("SDTM", "ADaM")
REPOSITORY = "https://github.com/elong0527/yamaa"
# Comments are giscus threads in the repository's GitHub Discussions, so they
# outlive any deployment. Each benchmark maps to one discussion whose title is
# COMMENT_TERM_PREFIX plus the benchmark directory name; renaming a directory
# starts a new thread. IDs come from https://giscus.app after the repository
# enables Discussions and installs the giscus app.
GISCUS = {
    "repo": "elong0527/yamaa",
    "repo_id": "R_kgDOTXVQTg",
    "category": "Comments",
    "category_id": "DIC_kwDOTXVQTs4DFe_t",
    "theme": "https://elong0527.github.io/yamaa/assets/giscus-yamaa.css?v=3",
}
COMMENT_TERM_PREFIX = "yaml/examples/"
OUTCOMES = (
    (
        "positive",
        "Benchmarks",
        "Each runs to completion and produces the artifact in expected/.",
    ),
    (
        "negative",
        "Anti-pattern",
        "Each must fail, and expected/error.yaml pins the error it raises.",
    ),
)
# The gallery opens with a table saying what each directory-name group is for,
# counted from the directories themselves so the figures cannot drift from the
# suite. A group absent from this map is an error rather than a silent
# omission: adding one costs a single line here and keeps the table a complete
# account of what the suite holds.
GROUP_NOTES = {
    "schema": "Assess yamaa schema",
    "adam": "Assess SDTM to ADaM derivations",
    "bimo": "Assess BIMO clinical site dataset derivations",
    "sdtm": "Assess ODM to SDTM derivations",
    "negative": "Assess yamaa error handling",
}
YAML_TOKEN = re.compile(
    r""""(?:[^"\\]|\\.)*"|'(?:[^']|'')*'|\b(?:null|true|false)\b|\b\d+(?:\.\d+)?\b|[A-Za-z_][\w-]*(?=:)"""
)
SPEC_FILE_PATTERN = re.compile(r"^spec(?:_[a-z][a-z0-9_]*)?\.yaml$")
SPEC_RESOLVED_NAME = "spec_resolved.yaml"
CODE_SUFFIXES = (".py", ".R", ".qmd", ".Rmd")
README_TAXONOMY = re.compile(
    r"^\*\*Standard:\*\*\s*([^|]+?)\s*\|\s*\*\*Domain:\*\*\s*(\S+)\s*$"
)
LIFECYCLE_BADGE = re.compile(r"\[!\[Lifecycle:\s*([A-Za-z]+)\]\(([^)]+)\)\]")
LIFECYCLE_STATES = ("draft", "reviewed", "finalized")
LIFECYCLE_DEFAULT = ("draft", "https://img.shields.io/badge/Lifecycle-draft-lightgrey")


def escape(value):
    return html.escape(str(value), quote=True)


def benchmark_spec_files(benchmark):
    if not benchmark.is_dir():
        return []
    return sorted(
        path
        for path in benchmark.iterdir()
        if path.is_file() and SPEC_FILE_PATTERN.fullmatch(path.name)
    )


def benchmark_has_spec(benchmark):
    return bool(benchmark_spec_files(benchmark))


def linked_specs(spec):
    """Return the files a spec names as parents or as input producers."""
    if not isinstance(spec, dict):
        return []
    parents = spec.get("parents", [])
    if isinstance(parents, str):
        parents = [parents]
    linked = [parent for parent in parents if isinstance(parent, str) and parent]
    inputs = spec.get("input", {})
    if isinstance(inputs, dict):
        linked.extend(
            source["schema"]
            for source in inputs.values()
            if isinstance(source, dict)
            and isinstance(source.get("schema"), str)
            and source["schema"]
        )
    return linked


def sibling_producers(benchmark, spec):
    """Return the spec files beside the entry that it reads through `schema`."""
    inputs = spec.get("input", {}) if isinstance(spec, dict) else {}
    producers = []
    for source in inputs.values() if isinstance(inputs, dict) else ():
        if not isinstance(source, dict) or not isinstance(source.get("schema"), str):
            continue
        candidate = benchmark / source["schema"]
        if candidate in benchmark_spec_files(benchmark):
            producers.append(candidate)
    return producers


def benchmark_entry(benchmark):
    files = benchmark_spec_files(benchmark)
    if (benchmark / "spec.yaml").is_file():
        return benchmark / "spec.yaml", []
    specs = {}
    for path in files:
        try:
            specs[path.resolve()] = yaml.safe_load(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, yaml.YAMLError):
            continue
    named = {Path(link).name for spec in specs.values() for link in linked_specs(spec)}
    entries = [path for path in files if path.name not in named]
    entry = entries[0] if entries else (files[0] if files else None)
    chain = []
    if entry is not None:
        seen = set()

        def visit(path):
            if path in seen:
                return
            seen.add(path)
            for link in linked_specs(specs.get(path)):
                candidate = path.parent / link
                if candidate.is_file() and candidate.resolve() in specs:
                    visit(candidate.resolve())
            if path != (entry.resolve() if entry else None):
                chain.append(path)

        visit(entry.resolve())
    return entry, chain


def readme_lines(text):
    """Return dashboard prose lines without navigation or taxonomy metadata."""
    return [
        line
        for line in text.splitlines()
        if "img.shields.io/badge/Dashboard" not in line
        and "img.shields.io/badge/Lifecycle" not in line
        and not line.strip().startswith("**Lifecycle:**")
        and not README_TAXONOMY.fullmatch(line)
    ]


def readme_lifecycle(text):
    """Extract the lifecycle state and badge URL from raw README text."""
    match = LIFECYCLE_BADGE.search(text)
    if match:
        state, badge_url = match.group(1), match.group(2)
        if state in LIFECYCLE_STATES:
            return state, badge_url
    return LIFECYCLE_DEFAULT


def readme_taxonomy(text):
    for line in text.splitlines():
        match = README_TAXONOMY.fullmatch(line)
        if match:
            return match.group(1).strip(), match.group(2).strip()
    return None


def readme_body_line_count(text):
    lines = readme_lines(text)
    if lines and lines[0].startswith("# "):
        lines = lines[1:]
    return sum(bool(line.strip()) for line in lines)


def render_readme(text, source_url):
    """Render Markdown without executing raw HTML; resolve fixture-relative links."""
    text = "\n".join(readme_lines(text))
    markdown = MarkdownIt("commonmark", {"html": False}).enable("table")
    tokens = markdown.parse(text)
    title = "Benchmark"
    if tokens and tokens[0].type == "heading_open" and tokens[0].tag == "h1":
        title = tokens[1].content
        tokens = tokens[3:]
    return title, render_markdown_tokens(markdown, tokens, source_url)


def render_markdown_tokens(markdown, tokens, source_url):
    """Render parsed Markdown with its links resolved against `source_url`.

    Relative links and images point at the source folder on GitHub, and images
    show as links, so a page never fetches anything when opened from disk.
    """
    for token in tokens:
        for child in token.children or []:
            attribute = (
                "href"
                if child.type == "link_open"
                else "src"
                if child.type == "image"
                else None
            )
            if attribute:
                target = child.attrGet(attribute)
                if (
                    target
                    and not urlsplit(target).scheme
                    and not target.startswith(("#", "//"))
                ):
                    child.attrSet(attribute, source_url + "/" + target)
            # Keep generated pages self-contained: show image references as links.
            if child.type == "image":
                child.type = "html_inline"
                child.content = f'<a href="{escape(child.attrGet("src"))}">{escape(child.content or "Image")}</a>'
    return markdown.renderer.render(tokens, markdown.options, {})


def subject_key(record):
    subject = record.get("USUBJID", "")
    if not subject:
        return ""
    return json.dumps(
        [record.get("STUDYID", ""), subject], ensure_ascii=True, separators=(",", ":")
    )


def fixture_files(directory):
    if not directory.is_dir():
        return []
    return sorted(
        (
            path
            for path in directory.rglob("*")
            if path.is_file()
            and not path.is_symlink()
            and path.resolve().is_relative_to(directory.resolve())
            and not any(
                part.startswith(".") for part in path.relative_to(directory).parts
            )
        ),
        key=lambda path: path.relative_to(directory).as_posix(),
    )


def read_csv(path):
    # Decode for display without changing field values.
    with path.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.reader(stream, strict=True))
    if not rows:
        return [], []
    if any(len(row) != len(rows[0]) for row in rows[1:]):
        raise ValueError("unequal CSV record widths")
    return rows[0], rows[1:]


def render_table(headers, rows, filename, derived, labels):
    cells = []
    for name in headers:
        class_name = ' class="derived"' if name in derived else ""
        title = f' title="{escape(labels[name])}"' if name in labels else ""
        cells.append(f'<th scope="col"{class_name}{title}>{escape(name)}</th>')
    body = []
    for values in rows:
        record = dict(zip(headers, values))
        key = subject_key(record)
        row_cells = []
        for name, value in zip(headers, values):
            class_name = ' class="derived"' if name in derived else ""
            content = escape(value)
            if value == "":
                content = (
                    '<span class="missing" aria-label="Missing value">&mdash;</span>'
                )
            elif name == "USUBJID" and key:
                content = (
                    f'<button type="button" class="subject-button" data-subject="{escape(key)}" '
                    f'aria-pressed="false" aria-label="Highlight subject {escape(value)}">{content}</button>'
                )
            row_cells.append(
                f'<td{class_name} data-value="{escape(value)}">{content}</td>'
            )
        body.append(f'<tr data-subject="{escape(key)}">' + "".join(row_cells) + "</tr>")
    empty = '<p class="no-rows">This file has no data rows.</p>' if not rows else ""
    return (
        f'<div class="table-scroll" tabindex="0" role="region" aria-label="{escape(filename)} table">'
        f'<table class="data-table"><caption class="visually-hidden">{escape(filename)}</caption>'
        "<thead><tr>"
        + "".join(cells)
        + "</tr></thead><tbody>"
        + "".join(body)
        + "</tbody></table></div>"
        + empty
    )


def render_files(paths, group, benchmark, derived, labels):
    panes, widths, subjects = [], [], set()
    row_count = 0
    for index, path in enumerate(paths):
        pane_id = f"{group}-file-{index}"
        filename = path.relative_to(benchmark).as_posix()
        count = ""
        table = None
        width = 1
        if path.suffix.lower() == ".csv":
            try:
                headers, rows = read_csv(path)
                if not headers or len(set(headers)) != len(headers) or "" in headers:
                    raise ValueError("missing or duplicate CSV header")
                table = render_table(headers, rows, filename, derived, labels)
                width = len(headers)
                row_count += len(rows)
                count = f"{len(rows)} row" + ("" if len(rows) == 1 else "s")
                for values in rows:
                    key = subject_key(dict(zip(headers, values)))
                    if key:
                        subjects.add(key)
            except (ValueError, csv.Error, UnicodeError):
                # Malformed inputs are intentional in negative benchmarks.
                # Show their source literally instead of repairing or dropping it.
                count = "raw CSV"
        if table is None:
            try:
                table = f'<pre class="plain-file"><code>{escape(path.read_text(encoding="utf-8"))}</code></pre>'
            except UnicodeError:
                table = '<p class="no-rows">Binary fixture; inspect it in the benchmark source.</p>'
            if count == "raw CSV":
                table = (
                    '<p class="no-rows">Showing raw CSV because the source is not a valid rectangular table.</p>'
                    + table
                )
        widths.append(f"minmax(0, {width}fr)")
        count_html = f'<span class="file-count">{count}</span>' if count else ""
        edit_url = (
            REPOSITORY
            + "/edit/main/benchmarks/"
            + quote(benchmark.name)
            + "/"
            + "/".join(quote(part) for part in filename.split("/"))
        )
        panes.append(
            f'<div id="{pane_id}" class="panel file-pane" role="region" aria-label="{escape(filename)}">'
            f'<div class="file-heading"><span class="file-title"><h3 class="filename">{escape(filename)}</h3>'
            f'<a class="edit-button" href="{edit_url}">Edit</a></span>{count_html}</div>'
            + table
            + "</div>"
        )
    content = (
        "".join(panes) or '<p class="no-rows">No fixture files in this directory.</p>'
    )
    content = f'<div class="files-grid" style="--dataset-columns: {" ".join(widths)}">{content}</div>'
    return content, row_count, subjects


def render_failure_section(error_path, edit_url):
    """Render the expected-failure panel for a benchmark the run must reject.

    The definition list carries only the stable facts; the full assertion,
    including spec paths, lives in the collapsed raw YAML below it.
    """
    raw = error_path.read_text(encoding="utf-8")
    try:
        failure = yaml.safe_load(raw)
    except yaml.YAMLError:
        failure = None
    failure = failure if isinstance(failure, dict) else {}
    facts = []
    for key in ("phase", "condition", "requirement"):
        value = failure.get(key)
        if value:
            facts.append((key, str(value)))
    facts_html = "".join(
        f"<div><dt>{escape(key)}</dt><dd>{escape(value)}</dd></div>"
        for key, value in facts
    )
    section = (
        '<section id="expected-failure" class="panel failure-panel" aria-labelledby="expected-failure-heading">\n'
        '  <header class="panel-header"><span class="panel-title"><h2 id="expected-failure-heading">Expected failure</h2>'
        f'<a class="edit-button" href="{edit_url}">Edit</a></span>'
        '<span class="panel-caption">the run is rejected; no artifact is accepted</span></header>\n'
        '  <div class="source-path"><code>expected/error.yaml</code></div>\n'
        f"  <dl>{facts_html}</dl>\n"
        "  <details><summary>expected/error.yaml</summary>\n"
        f'  <pre class="plain-file"><code>{escape(raw)}</code></pre></details>\n'
        "</section>"
    )
    return failure, section


def highlight_yaml(line):
    result, cursor = [], 0
    for token in YAML_TOKEN.finditer(line):
        result.append(escape(line[cursor : token.start()]))
        value = token.group()
        kind = (
            "string"
            if value[0] in "\"'"
            else "key"
            if line[token.end() :].startswith(":")
            else "literal"
        )
        result.append(f'<span class="yaml-{kind}">{escape(value)}</span>')
        cursor = token.end()
    result.append(escape(line[cursor:]))
    return "".join(result)


def benchmark_category(name, title, spec):
    if name.startswith(("spec-", "schema-")):
        return "Specification", title
    category, separator, heading = title.partition(": ")
    if not separator:
        return str(spec.get("domain", "yamaa benchmark")), title
    return category, heading


def describe_benchmark(benchmark):
    """Return the page title and category without rendering fixtures."""
    source_url = REPOSITORY + "/blob/main/benchmarks/" + quote(benchmark.name)
    readme_path = benchmark / "README.md"
    entry_path, _ = benchmark_entry(benchmark)
    if entry_path is None:
        raise ValueError(f"benchmark has no spec file: {benchmark.name}")
    spec_path = entry_path
    readme_text = readme_path.read_text(encoding="utf-8")
    title, _ = render_readme(readme_text, source_url)
    spec = yaml.safe_load(spec_path.read_text(encoding="utf-8"))
    spec = spec if isinstance(spec, dict) else {}
    category, _ = benchmark_category(benchmark.name, title, spec)
    taxonomy = readme_taxonomy(readme_text)
    if taxonomy and category != "Specification" and sibling_producers(benchmark, spec):
        # An example that builds several domains files under the one its
        # README names, not under whichever domain its entry happens to build.
        category = taxonomy[1]
    return title, category


def page_link(name, label, relation):
    if name is None:
        return f'<span class="is-disabled" aria-disabled="true">{label}</span>'
    return f'<a href="{escape(name)}.html" rel="{relation}">{label}</a>'


def plural(count, noun):
    return f"{count} {noun}" + ("" if count == 1 else "s")


def render_groups(names):
    """Render the table of groups and their purpose that opens the gallery.

    Counts come from the directory names, so the table cannot report a total
    the suite no longer has. A group the notes do not describe raises rather
    than disappearing from the table.
    """
    counts = {}
    for name in names:
        family = name.partition("-")[0]
        if family not in GROUP_NOTES:
            raise ValueError(
                f"benchmark family has no gallery description: {family}-* "
                f"(add it to GROUP_NOTES in generate.py)"
            )
        counts[family] = counts.get(family, 0) + 1
    rows = "".join(
        f"| `{family}-*` | {counts[family]} | {escape(GROUP_NOTES[family])} |\n"
        for family in GROUP_NOTES
        if family in counts
    )
    return "| Group | Count | Purpose |\n|---|---|---|\n" + rows.rstrip("\n")


def curated_links(template_text):
    """Return the benchmark names the overview hand-picks.

    The overview names a reading path. Those links outlive the directories
    they point at unless something checks them, so `main` compares them
    against the suite and a rename breaks the build instead of shipping a
    dead link.
    """
    return sorted(set(re.findall(r"\]\(([a-z0-9-]+)\.html\)", template_text)))


def render_index(entries):
    """Render the gallery page linking every generated dashboard.

    The page is Markdown, so MkDocs renders it inside the documentation site
    with the same header, navigation, search, and palette as every other page;
    only the dashboards themselves stay self-contained. Headings are Markdown
    so they reach the table of contents, and the lists are written as HTML so
    a title is escaped exactly once and the stylesheet can lay them out.

    A specification the design must refuse is a different contract from one
    that must produce an artifact, so the two are listed apart rather than
    interleaved by domain. A `negative-` directory name is what marks the
    second group, the same test the repository validator applies.

    The overview above the listing is authored at `docs/articles/benchmark.md`
    and reaches the reader on the same page as the benchmarks it describes.
    Its totals are substituted from the directories rather than typed, and its
    curated links are checked against the suite, so neither can go stale.
    """
    outcomes = {key: {} for key, _, _ in OUTCOMES}
    for name, title, category in entries:
        outcome = "negative" if name.startswith("negative-") else "positive"
        outcomes[outcome].setdefault(category, []).append((name, title))
    blocks, jumps = [], []
    for key, heading, note in OUTCOMES:
        groups = outcomes[key]
        if not groups:
            continue
        total = sum(len(items) for items in groups.values())
        jumps.append(f'<a href="#{key}">{escape(heading)} ({total})</a>')
        sections = [
            f"## {escape(heading)} {{: #{key} }}\n\n"
            f'<p class="benchmark-note">{plural(total, "benchmark")}. '
            f"{escape(note)}</p>"
        ]
        for category in sorted(groups):
            items = "".join(
                f'<li><a href="{escape(name)}.html">{escape(title)}</a></li>\n'
                for name, title in sorted(groups[category])
            )
            sections.append(
                f"### {escape(category)}\n\n"
                f'<p class="benchmark-count">'
                f"{plural(len(groups[category]), 'benchmark')}</p>\n\n"
                f'<ul class="benchmark-grid">\n{items}</ul>'
            )
        blocks.append("\n\n".join(sections))
    names = [name for name, _, _ in entries]
    template = Template(OVERVIEW.read_text(encoding="utf-8"))
    result = template.substitute(
        total=plural(len(entries), "benchmark"),
        source_url=REPOSITORY + "/tree/main/benchmarks",
        groups=render_groups(names),
        summary="".join(jumps),
        sections="\n\n".join(blocks) + "\n",
    )
    return result.encode("ascii", "xmlcharrefreplace")


def render_spec_pane(filename, text, slug, single, edit_url=None):
    lines = text.splitlines()
    code_lines = []
    for number, line in enumerate(lines, 1):
        line_id = f"yaml-line-{number}" if single else f"{slug}-line-{number}"
        code_lines.append(
            f'<span class="code-line" id="{line_id}"><span class="line-number" aria-hidden="true">{number}</span>'
            f'<span class="code-source">{highlight_yaml(line)}</span></span>'
        )
    if single:
        return "".join(code_lines), len(lines)
    edit = f'<a class="edit-button" href="{edit_url}">Edit</a>' if edit_url else ""
    edit_data = f' data-edit-url="{escape(edit_url)}"' if edit_url else ""
    pane = (
        f'<div class="spec-pane" id="pane-{slug}" data-filename="{escape(filename)}" '
        f'data-lines="{len(lines)}"{edit_data}>'
        f'<div class="file-heading"><span class="file-title"><h3 class="filename">{escape(filename)}</h3>{edit}</span>'
        f'<span class="file-count">{len(lines)} lines</span></div>'
        f"<pre><code>{''.join(code_lines)}</code></pre></div>"
    )
    return pane, len(lines)


def benchmark_code_files(benchmark):
    return sorted(
        path
        for path in benchmark.iterdir()
        if path.is_file() and path.suffix in CODE_SUFFIXES
    )


def slugify(text):
    """An HTML id fragment: lower case, other characters run together as one hyphen."""
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def render_file_document(document_id, title, line_count, body, edit_url=None):
    """One file in a material pane: its name, Edit link, and line count over its body."""
    edit = f'<a class="edit-button" href="{edit_url}">Edit</a>' if edit_url else ""
    return (
        f'<div class="material-document material-file" id="{document_id}" data-filename="{escape(title)}">'
        f'<div class="file-heading"><span class="file-title"><h4 class="filename">{escape(title)}</h4>{edit}</span>'
        f'<span class="file-count">{plural(line_count, "line")}</span></div>{body}</div>'
    )


def render_code_document(path, slug, title, edit_url=None):
    """A code file with numbered lines, each one linkable as #code-<slug>-line-<n>."""
    lines = path.read_text(encoding="utf-8").splitlines()
    code_lines = "".join(
        f'<span class="code-line" id="code-{slug}-line-{number}"><span class="line-number" aria-hidden="true">{number}</span>'
        f'<span class="code-source">{escape(line)}</span></span>'
        for number, line in enumerate(lines, 1)
    )
    body = (
        f'<div class="code-scroll" tabindex="0" aria-label="{escape(title)}">'
        f"<pre><code>{code_lines}</code></pre></div>"
    )
    return render_file_document(f"code-pane-{slug}", title, len(lines), body, edit_url)


def render_prompt_document(path, tier, title, edit_url, source_url):
    """A prompt reads as the request it is; the Edit link opens the raw file.

    It renders under the README's rules: no raw HTML, links resolved against
    the prompt's folder, and images shown as links.
    """
    text = path.read_text(encoding="utf-8")
    markdown = MarkdownIt("commonmark", {"html": False}).enable("table")
    body = render_markdown_tokens(markdown, markdown.parse(text), source_url)
    return render_file_document(
        f"prompt-pane-{tier}",
        title,
        len(text.splitlines()),
        f'<div class="prose prompt-prose">{body}</div>',
        edit_url,
    )


def render_material_pane(key, title, provenance, picker_label, documents):
    """One tab's pane: a toolbar naming where it comes from over its documents.

    `documents` is a list of (picker label, document id, document HTML); a
    picker appears when there is more than one to choose from.
    """
    picker = ""
    if len(documents) > 1:
        options = "".join(
            f'<option value="{document_id}">{escape(label)}</option>'
            for label, document_id, _ in documents
        )
        picker = (
            f'<label class="material-picker"><span>{escape(picker_label)}</span>'
            f'<select id="{key}-select" data-documents>{options}</select></label>'
        )
    return (
        f'<div role="tabpanel" id="{key}" class="material-pane" aria-labelledby="tab-{key}">'
        f'<div class="material-toolbar"><h3 class="material-title">{escape(title)}</h3>{picker}'
        f'<p class="material-provenance">{provenance}</p></div>'
        + "".join(document for _, _, document in documents)
        + "</div>"
    )


def render_materials(benchmark, spec, define, code_files, edit_base):
    """Tabs and panes for the assessment materials shown beside Comments.

    None of them is under review: the mapping spec is generated from the YAML,
    the yamaa code only runs it, and the prompts and the solutions written
    without yamaa exist to run and score agent evaluations. A material a
    benchmark lacks has no tab.
    """
    materials = []
    sheets = mapping_doc.render_mapping_sheets(spec, define)
    if sheets:
        materials.append(
            (
                "mapping-spec",
                "Mapping spec",
                "Generated from the benchmark YAML; do not edit by hand",
                "Sheet",
                [
                    (
                        label,
                        f"mapping-sheet-{sheet_id}",
                        f'<div class="material-document" id="mapping-sheet-{sheet_id}">{table}</div>',
                    )
                    for sheet_id, label, table in sheets
                ],
            )
        )
    name = quote(benchmark.name)
    prompts = HARBOR / "prompts" / benchmark.name
    tiers = [tier for tier in PROMPT_TIERS if (prompts / f"{tier[0]}.md").is_file()]
    if tiers:
        materials.append(
            (
                "prompt",
                "Agent prompt",
                (
                    "The request an agent receives with the input files; each "
                    f'<a href="{REPOSITORY}/blob/main/evaluations/harbor/prompts/README.md">tier</a> '
                    "states no more than the one above"
                ),
                "Tier",
                [
                    (
                        f"{label} \u2014 {keeps}",
                        f"prompt-pane-{tier}",
                        render_prompt_document(
                            prompts / f"{tier}.md",
                            tier,
                            f"prompts/{benchmark.name}/{tier}.md",
                            f"{REPOSITORY}/edit/main/evaluations/harbor/prompts/{name}/{tier}.md",
                            f"{REPOSITORY}/blob/main/evaluations/harbor/prompts/{name}",
                        ),
                    )
                    for tier, label, keeps in tiers
                ],
            )
        )
    if code_files:
        materials.append(
            (
                "code",
                "yamaa code",
                "Runs the yamaa specification; its result must match the expected output",
                "File",
                [
                    (
                        path.name,
                        f"code-pane-{slugify(path.name)}",
                        render_code_document(
                            path,
                            slugify(path.name),
                            path.name,
                            f"{edit_base}/{quote(path.name)}" if edit_base else None,
                        ),
                    )
                    for path in code_files
                ],
            )
        )
    solutions = HARBOR / "solutions" / benchmark.name
    solution_files = [
        solutions / filename
        for filename in SOLUTION_FILES
        if (solutions / filename).is_file()
    ]
    if solution_files:
        materials.append(
            (
                "solution",
                "Solution without yamaa",
                (
                    "Written from the full prompt and the inputs alone; CI checks it "
                    "reproduces the expected output"
                ),
                "File",
                [
                    (
                        path.name,
                        f"code-pane-solution-{slugify(path.name)}",
                        render_code_document(
                            path,
                            "solution-" + slugify(path.name),
                            f"solutions/{benchmark.name}/{path.name}",
                            f"{REPOSITORY}/edit/main/evaluations/harbor/solutions/{name}/{quote(path.name)}",
                        ),
                    )
                    for path in solution_files
                ],
            )
        )
    tabs = "".join(
        f'<button type="button" role="tab" id="tab-{key}" aria-controls="{key}" '
        'aria-selected="false" aria-describedby="not-under-review" '
        f'class="material-tab reference-tab">{escape(title)}</button>'
        for key, title, _, _, _ in materials
    )
    panes = "".join(render_material_pane(*material) for material in materials)
    return tabs, panes


def render_benchmark(benchmark, previous=None, next=None):
    """One benchmark's self-contained dashboard page, as ASCII bytes."""
    source_url = REPOSITORY + "/blob/main/benchmarks/" + quote(benchmark.name)
    edit_base = REPOSITORY + "/edit/main/benchmarks/" + quote(benchmark.name)
    readme_edit_url = edit_base + "/README.md"
    readme_path = benchmark / "README.md"
    spec_path, chain = benchmark_entry(benchmark)
    if spec_path is None:
        raise ValueError(f"benchmark has no spec file: {benchmark.name}")
    spec_edit_url = edit_base + "/" + quote(spec_path.name)
    readme_text = readme_path.read_text(encoding="utf-8")
    lifecycle_state, lifecycle_url = readme_lifecycle(readme_text)
    lifecycle_href = REPOSITORY + "/blob/main/benchmarks/README.md#lifecycle"
    lifecycle_badge = (
        f'<a class="lifecycle-badge" href="{escape(lifecycle_href)}">'
        f'<img src="{escape(lifecycle_url)}" alt="Lifecycle: {escape(lifecycle_state)}"></a>'
    )
    title, readme = render_readme(readme_text, source_url)
    spec_text = spec_path.read_text(encoding="utf-8")
    # Parse metadata for labels and visual emphasis only; this does not execute the spec.
    spec = yaml.safe_load(spec_text)
    spec = spec if isinstance(spec, dict) else {}
    # A producer kept beside the entry publishes an expected artifact of its
    # own, so its columns label that artifact the way the entry's label theirs.
    column_specs = [spec]
    for producer in sibling_producers(benchmark, spec):
        document = yaml.safe_load(producer.read_text(encoding="utf-8"))
        column_specs.append(document if isinstance(document, dict) else {})
    labels = {}
    derived = set()
    for owner in reversed(column_specs):
        columns = [item for item in owner.get("columns", []) if isinstance(item, dict)]
        labels.update(
            (item["name"], item["label"])
            for item in columns
            if "name" in item and "label" in item
        )
        for item in columns:
            name = item.get("name")
            expression = item.get("derivation", {})
            expression = expression if isinstance(expression, dict) else {}
            source = expression.get("source")
            if isinstance(source, dict):
                source = source.get("variable")
            if name and source != f"{owner.get('base')}.{name}":
                derived.add(name)
    inputs = fixture_files(benchmark / "input")
    error_path = benchmark / "expected" / "error.yaml"
    is_failure = error_path.is_file()
    outputs = [
        path
        for path in fixture_files(benchmark / "expected")
        if path.name != SPEC_RESOLVED_NAME
        and (not is_failure or path.name != "error.yaml")
    ]
    input_files, _, input_subjects = render_files(inputs, "input", benchmark, set(), {})
    output_files, output_rows, output_subjects = render_files(
        outputs, "output", benchmark, derived, labels
    )
    subjects = sorted(input_subjects | output_subjects)
    subject_ids = [json.loads(key)[1] for key in subjects]
    subject_options = []
    for key in subjects:
        study, subject = json.loads(key)
        label = f"{study} / {subject}" if subject_ids.count(subject) > 1 else subject
        subject_options.append(
            f'<option value="{escape(key)}">{escape(label)}</option>'
        )
    category, heading = benchmark_category(benchmark.name, title, spec)
    taxonomy = readme_taxonomy(readme_text)
    if taxonomy and not benchmark.name.startswith("spec-"):
        category = ".".join(taxonomy)
    heading = heading[:1].upper() + heading[1:]
    has_csv = any(path.suffix == ".csv" for path in outputs)
    if is_failure:
        failure, failure_section = render_failure_section(
            error_path, edit_base + "/expected/error.yaml"
        )
        datasets_heading = "Unexpected Output"
        description = escape(
            title + ": README, inputs, expected failure, and YAML specification."
        )
        metrics = [
            ("Rejected", "result", "result-rejected"),
            (len(inputs), "input files", ""),
            (len(subjects), "subjects", ""),
        ]
        if has_csv:
            metrics.append((output_rows, "rows presented", ""))
            output_caption = (
                f"{output_rows} row presented to the failing check"
                if output_rows == 1
                else f"{output_rows} rows presented to the failing check"
            ) + " - not an accepted artifact"
        else:
            output_caption = "No artifact is produced"
    else:
        failure_section = ""
        datasets_heading = "Expected output"
        description = escape(
            title + ": README, inputs, expected output, and YAML specification."
        )
        metrics = [(len(inputs), "input files", ""), (len(subjects), "subjects", "")]
        if has_csv:
            metrics.append((output_rows, "expected rows", ""))
            output_caption = (
                f"{output_rows} expected row"
                if output_rows == 1
                else f"{output_rows} expected rows"
            )
        else:
            metrics.append((len(outputs), "expected files", ""))
            output_caption = "Expected artifacts"

    # What reviewers are asked to challenge, the task included: the summary,
    # the inputs, and the expected result. Everything in the tabs beside
    # Comments is background for assessment.
    if is_failure:
        questions = (
            (
                "#readme",
                "Task",
                (
                    "Is this a specification error a study team could realistically "
                    "make, and should the build stop on it rather than continue?"
                ),
            ),
            (
                "#inputs",
                "Inputs",
                "Do they trigger the failure for the reason the summary gives?",
            ),
            (
                "#expected-failure",
                "Expected failure",
                (
                    "Is this the right error, raised at the right point, and would it "
                    "tell the programmer what to fix?"
                ),
            ),
        )
    else:
        standard = taxonomy[0] if taxonomy else None
        standard = (
            f"CDISC {standard}" if standard in REVIEW_STANDARDS else "CDISC standards"
        )
        questions = (
            (
                "#readme",
                "Task",
                (
                    "Would a real study need this derivation, specified this way? Does "
                    f"it follow {standard}: variable names, controlled terms, record "
                    "structure? Flag any rule that is ambiguous or that a sponsor would "
                    "handle differently."
                ),
            ),
            (
                "#inputs",
                "Inputs",
                (
                    "Do they look like data collected in a real trial, and do they "
                    "include the situations you would expect to meet in one?"
                ),
            ),
            (
                "#outputs",
                "Expected output",
                (
                    "Would independent QC programming reproduce every value from these "
                    "inputs and rules?"
                ),
            ),
        )
    review_ask = (
        "<p>As a clinical trial statistician or programmer, challenge anything in "
        'this benchmark: describe a problem in <a href="#comments">Comments</a>, '
        "or propose a fix with the <strong>Edit</strong> button on any source "
        "file.</p><ol>"
        + "".join(
            f'<li><a href="{anchor}"><strong>{label}:</strong></a> {question}</li>'
            for anchor, label, question in questions
        )
        + '</ol><p class="review-ask-note">The other tabs beside Comments are '
        "background for assessment, not under review.</p>"
    )

    def metric_cell(count, label, cls):
        klass = f' class="{cls}"' if cls else ""
        return f"<div{klass}><dt>{label}</dt><dd>{count}</dd></div>"

    metrics_html = "".join(metric_cell(*item) for item in metrics)
    resolved_path = benchmark / "expected" / SPEC_RESOLVED_NAME
    if not chain and not resolved_path.is_file():
        spec_code, spec_line_count = render_spec_pane(
            spec_path.name, spec_text, "yaml", True
        )
        spec_caption = "1 spec file"
        spec_file_header = (
            '<div class="file-heading spec-file-heading"><span class="file-title">'
            f'<h3 class="filename">{escape(spec_path.name)}</h3>'
            f'<a class="edit-button" href="{spec_edit_url}">Edit</a></span>'
            f'<span class="file-count">{spec_line_count} lines</span></div>'
        )
    else:
        panes = []
        sources = list(chain) + [spec_path]
        if resolved_path.is_file():
            sources.append(resolved_path)
        for path in sources:
            try:
                relpath = path.relative_to(benchmark).as_posix()
            except ValueError:
                relpath = None
            text = path.read_text(encoding="utf-8")
            filename = path.name
            file_edit = (
                edit_base + "/" + "/".join(quote(part) for part in relpath.split("/"))
                if relpath
                else None
            )
            pane, count = render_spec_pane(
                filename, text, Path(filename).stem, False, file_edit
            )
            panes.append(pane)
            spec_line_count = count
        spec_caption = f"{len(sources)} spec files"
        panes.append(
            f"<script>{(HERE / 'spec-panes.js').read_text(encoding='utf-8')}</script>"
        )
        spec_code = "".join(panes)
        spec_file_header = ""
    code_files = benchmark_code_files(benchmark)
    define_path = benchmark / "define.yaml"
    define = (
        yaml.safe_load(define_path.read_text(encoding="utf-8"))
        if define_path.is_file()
        else None
    )
    material_tabs, material_panes = render_materials(
        benchmark, spec, define, code_files, edit_base
    )
    template = Template((HERE / "dashboard.html").read_text(encoding="utf-8"))
    result = template.substitute(
        benchmark_name=escape(benchmark.name),
        page_title=escape(title),
        heading=escape(heading),
        category=escape(category),
        description=description,
        lifecycle_badge=lifecycle_badge,
        failure_section=failure_section,
        datasets_heading=datasets_heading,
        readme_edit_url=readme_edit_url,
        spec_file_header=spec_file_header,
        source_url=REPOSITORY + "/tree/main/benchmarks/" + quote(benchmark.name),
        prev_link=page_link(previous, "Previous benchmark", "prev"),
        next_link=page_link(next, "Next benchmark", "next"),
        metrics=metrics_html,
        subject_options="".join(subject_options),
        readme=readme,
        prose_class="prose prose-short"
        if readme_body_line_count(readme_text) <= 10
        else "prose",
        input_files=input_files,
        input_caption=f"{len(inputs)} source file" + ("" if len(inputs) == 1 else "s"),
        output_files=output_files,
        output_caption=output_caption,
        spec_caption=spec_caption,
        spec_code=spec_code,
        review_ask=review_ask,
        material_tabs=material_tabs,
        material_panes=material_panes,
        panel_script=(HERE / "panel-tabs.js").read_text(encoding="utf-8"),
        giscus_repo=escape(GISCUS["repo"]),
        giscus_repo_id=escape(GISCUS["repo_id"]),
        giscus_category=escape(GISCUS["category"]),
        giscus_category_id=escape(GISCUS["category_id"]),
        giscus_theme=escape(GISCUS["theme"]),
        comment_term=escape(COMMENT_TERM_PREFIX + benchmark.name),
        discussions_url=REPOSITORY + "/discussions",
        styles=(HERE / "dashboard.css").read_text(encoding="utf-8"),
        script=(HERE / "dashboard.js").read_text(encoding="utf-8"),
    )
    # Stable bytes across machines, locales, time zones, and checkout locations.
    # Character references also keep generated pages compatible with repository ASCII lint.
    return result.encode("ascii", "xmlcharrefreplace")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "benchmarks",
        nargs="*",
        help="Benchmark directory names; defaults to existing generated dashboards",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Generate every benchmark containing README.md and a spec file",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Fail if a selected dashboard is missing or differs; write nothing",
    )
    parser.add_argument(
        "--quiet", action="store_true", help="Suppress successful generation messages"
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DESTINATION,
        help="Destination directory (default: docs/benchmark)",
    )
    args = parser.parse_args()
    if args.all and args.benchmarks:
        parser.error("choose --all or explicit benchmark names")
    names = args.benchmarks
    if args.all:
        names = [
            path.name
            for path in sorted(BENCHMARKS.iterdir())
            if benchmark_has_spec(path) and (path / "README.md").is_file()
        ]
    elif not names:
        names = [path.stem for path in sorted(args.output_dir.glob("*.html"))]
    if not names:
        parser.error("specify a benchmark name or --all")
    ordered = sorted(set(names))
    complete = sorted(
        path.name
        for path in BENCHMARKS.iterdir()
        if benchmark_has_spec(path) and (path / "README.md").is_file()
    )
    overview_text = OVERVIEW.read_text(encoding="utf-8")
    dangling = [
        target for target in curated_links(overview_text) if target not in set(complete)
    ]
    if dangling:
        parser.error(
            "docs/articles/benchmark.md links to benchmarks that do not exist: "
            + ", ".join(dangling)
        )
    neighbors = {
        name: (
            complete[index - 1] if index else None,
            complete[index + 1] if index + 1 < len(complete) else None,
        )
        for index, name in enumerate(complete)
        if name in set(ordered)
    }
    write_index = args.all or (
        not args.benchmarks and (args.output_dir / "index.md").is_file()
    )
    failures = []
    entries = []
    for name in ordered:
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
            parser.error(f"invalid benchmark name: {name}")
        benchmark = BENCHMARKS / name
        if not (benchmark / "README.md").is_file() or not benchmark_has_spec(benchmark):
            parser.error(f"benchmark must contain README.md and a spec file: {name}")
        try:
            previous, following = neighbors.get(name, (None, None))
            rendered = render_benchmark(benchmark, previous, following)
        except (OSError, ValueError, yaml.YAMLError) as error:
            print(f"Cannot generate {name}: {error}", file=sys.stderr)
            failures.append(name)
            continue
        entries.append((name,) + describe_benchmark(benchmark))
        destination = args.output_dir / f"{name}.html"
        if args.check:
            if not destination.is_file() or destination.read_bytes() != rendered:
                failures.append(name)
                print(f"Stale or missing: {destination}", file=sys.stderr)
            elif not args.quiet:
                print(f"Current: {name}")
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(rendered)
            if not args.quiet:
                print(f"Generated: {destination}")
    if write_index:
        index = render_index(entries)
        destination = args.output_dir / "index.md"
        if args.check:
            if not destination.is_file() or destination.read_bytes() != index:
                failures.append("index")
                print(f"Stale or missing: {destination}", file=sys.stderr)
            elif not args.quiet:
                print("Current: index")
        else:
            destination.write_bytes(index)
            if not args.quiet:
                print(f"Generated: {destination}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
